import React, { useState } from 'react';

interface SpiderWebDecorationProps {
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'center' | 'none';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  opacity?: string;
  animate?: boolean;
  dark?: boolean;
  className?: string;
}

export const SpiderWebDecoration: React.FC<SpiderWebDecorationProps> = ({
  position = 'top-right',
  size = 'md',
  opacity = 'opacity-[0.07]',
  animate = true,
  dark = false,
  className = '',
}) => {
  const [imageError, setImageError] = useState(false);

  const positionClasses = {
    'top-left': 'absolute -top-4 -left-4',
    'top-right': 'absolute -top-4 -right-4',
    'bottom-left': 'absolute -bottom-4 -left-4',
    'bottom-right': 'absolute -bottom-4 -right-4',
    center: 'absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2',
    none: 'relative',
  }[position];

  const sizeClasses = {
    xs: 'w-16 h-16 sm:w-20 sm:h-20',
    sm: 'w-24 h-24 sm:w-32 sm:h-32',
    md: 'w-36 h-36 sm:w-48 sm:h-48 md:w-60 md:h-60',
    lg: 'w-52 h-52 sm:w-72 sm:h-72 md:w-96 md:h-96',
    xl: 'w-72 h-72 sm:w-96 sm:h-96 md:w-[480px] md:h-[480px]',
  }[size];

  const rotationClasses = {
    'top-left': 'rotate-0',
    'top-right': 'rotate-90',
    'bottom-right': 'rotate-180',
    'bottom-left': '-rotate-90',
    center: 'rotate-0',
    none: 'rotate-0',
  }[position];

  return (
    <div
      aria-hidden="true"
      className={`${positionClasses} ${sizeClasses} ${rotationClasses} pointer-events-none select-none z-0 overflow-hidden ${
        animate ? 'animate-spider-shimmer' : ''
      } ${className}`}
    >
      {!imageError ? (
        <img
          src="/images/web1.png"
          alt=""
          className={`w-full h-full object-contain ${opacity} ${
            dark ? 'invert brightness-200' : 'mix-blend-multiply'
          }`}
          onError={() => setImageError(true)}
          loading="lazy"
        />
      ) : (
        /* Resilient inline SVG Spider-Web Fallback */
        <svg
          viewBox="0 0 100 100"
          className={`w-full h-full ${opacity} ${
            dark ? 'text-white' : 'text-slate-800'
          }`}
          fill="none"
          stroke="currentColor"
          strokeWidth="0.75"
        >
          {/* Radial Spokes */}
          <line x1="0" y1="0" x2="100" y2="100" />
          <line x1="0" y1="0" x2="100" y2="50" />
          <line x1="0" y1="0" x2="50" y2="100" />
          <line x1="0" y1="0" x2="100" y2="25" />
          <line x1="0" y1="0" x2="25" y2="100" />
          <line x1="0" y1="0" x2="100" y2="0" />
          <line x1="0" y1="0" x2="0" y2="100" />

          {/* Web Spiral Arcs */}
          <path d="M 0,20 Q 10,10 20,0" />
          <path d="M 0,35 Q 20,20 35,0" />
          <path d="M 0,50 Q 30,30 50,0" />
          <path d="M 0,65 Q 40,40 65,0" />
          <path d="M 0,80 Q 50,50 80,0" />
          <path d="M 0,95 Q 60,60 95,0" />
          <path d="M 20,100 Q 60,60 100,20" />
          <path d="M 35,100 Q 70,70 100,35" />
          <path d="M 50,100 Q 80,80 100,50" />
        </svg>
      )}
    </div>
  );
};

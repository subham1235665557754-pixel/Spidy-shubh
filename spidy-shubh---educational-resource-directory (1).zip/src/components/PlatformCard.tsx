import React from 'react';
import { Platform } from '../types/index';
import { Bookmark, ExternalLink, ChevronRight, Star, CheckCircle2 } from 'lucide-react';
import { PlatformLogo } from './PlatformLogo';
import { SpiderWebDecoration } from './SpiderWebDecoration';

interface PlatformCardProps {
  platform: Platform;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onSelectPlatform: (platform: Platform) => void;
}

export const PlatformCard: React.FC<PlatformCardProps> = ({
  platform,
  isBookmarked,
  onToggleBookmark,
  onSelectPlatform,
}) => {
  const getInitials = (name: string) => {
    return name
      .replace(/[()]/g, '')
      .split(' ')
      .map((n) => n[0])
      .slice(0, 2)
      .join('');
  };

  return (
    <div className="group relative rounded-2xl bg-white border border-slate-200/90 hover:border-red-400 p-5 transition-all duration-200 flex flex-col justify-between shadow-2xs hover:shadow-md hover:-translate-y-0.5 overflow-hidden animate-card-fade-up">
      {/* Subtle Corner Web Decoration behind card */}
      <SpiderWebDecoration
        position="top-right"
        size="xs"
        opacity="opacity-[0.04] group-hover:opacity-[0.10]"
        animate={false}
        className="transition-opacity duration-300 -top-2 -right-2"
      />

      <div className="relative z-10">
        {/* Top Header: Logo + Title + Bookmark */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            {/* Platform Logo */}
            <PlatformLogo
              src={platform.logo}
              name={platform.name}
              brandColor={platform.brandColor}
              size="md"
            />

            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-heading text-lg font-bold text-slate-900 group-hover:text-red-600 transition-colors leading-tight">
                  {platform.name}
                </h3>
                <span title="Verified Educational Hub">
                  <CheckCircle2 className="w-3.5 h-3.5 text-red-600 fill-red-100 shrink-0" />
                </span>
              </div>
              <p className="text-xs text-slate-500 line-clamp-1 italic mt-0.5">
                "{platform.tagline}"
              </p>
            </div>
          </div>

          {/* Bookmark Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleBookmark(platform.id);
            }}
            className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
              isBookmarked
                ? 'bg-red-50 border-red-300 text-red-600'
                : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-red-600 hover:border-slate-300'
            }`}
            title={isBookmarked ? 'Remove bookmark' : 'Bookmark platform'}
            aria-label="Bookmark platform"
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-red-600' : ''}`} />
          </button>
        </div>

        {/* Platform Description */}
        <p className="text-xs text-slate-600 line-clamp-2 mb-4 leading-relaxed font-normal">
          {platform.description}
        </p>

        {/* Clean Unboxed Metadata: Exams & Stats */}
        <div className="pt-3 border-t border-slate-100 mb-4 space-y-1.5">
          <div className="flex items-center flex-wrap gap-1.5 text-xs text-slate-500">
            <span className="text-slate-400 font-medium">Exams:</span>
            {platform.exams.slice(0, 3).map((exam, idx) => (
              <React.Fragment key={exam}>
                <span className="text-slate-800 font-medium">{exam}</span>
                {idx < Math.min(platform.exams.length, 3) - 1 && (
                  <span className="text-slate-300" aria-hidden="true">·</span>
                )}
              </React.Fragment>
            ))}
            {platform.exams.length > 3 && (
              <span className="text-red-600 text-[11px] font-bold">
                +{platform.exams.length - 3} more
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="flex items-center gap-1 text-amber-600 font-bold">
              <Star className="w-3 h-3 fill-amber-400" />
              <span>{platform.rating}</span>
            </span>
            <span className="text-slate-300" aria-hidden="true">·</span>
            <span className="text-red-600 font-bold">
              {platform.portalCount} {platform.portalCount === 1 ? 'Portal' : 'Portals'}
            </span>
            <span className="text-slate-300" aria-hidden="true">·</span>
            <span className="text-slate-700 font-medium">{platform.verifiedBatchCount} Batches</span>
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex items-center gap-2 pt-1 relative z-10">
        <button
          onClick={() => onSelectPlatform(platform)}
          className="spidy-btn flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold uppercase tracking-wider bg-slate-900 hover:bg-red-600 text-white transition-all cursor-pointer shadow-2xs"
        >
          <span>Explore Batches</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>

        <a
          href={platform.officialWebsite}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 border border-slate-200 transition-colors cursor-pointer"
          title={`Visit official ${platform.name} website`}
        >
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};

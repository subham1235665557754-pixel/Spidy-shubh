import React, { useEffect } from 'react';
import {
  X,
  Home,
  BookOpen,
  Layers,
  Bookmark,
  User,
  Info,
  Send,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { SpiderLogo } from './SpiderLogo';
import { SpiderWebDecoration } from './SpiderWebDecoration';

interface SideNavDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateHome: () => void;
  onNavigateResources: () => void;
  onNavigateCategories: () => void;
  onOpenBookmarks: () => void;
  onOpenProfile: () => void;
  onOpenAbout: () => void;
  bookmarkCount: number;
}

export const SideNavDrawer: React.FC<SideNavDrawerProps> = ({
  isOpen,
  onClose,
  onNavigateHome,
  onNavigateResources,
  onNavigateCategories,
  onOpenBookmarks,
  onOpenProfile,
  onOpenAbout,
  bookmarkCount,
}) => {
  // Close drawer on escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Prevent background scroll when drawer is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Side Drawer Panel */}
      <div
        className="fixed inset-y-0 right-0 max-w-full flex pl-10"
        role="dialog"
        aria-modal="true"
        aria-label="Navigation drawer"
      >
        <div className="relative w-screen max-w-sm bg-white shadow-2xl flex flex-col justify-between overflow-hidden border-l border-slate-200">
          {/* Subtle Spider-Web Background Watermark */}
          <SpiderWebDecoration
            position="bottom-right"
            size="md"
            opacity="opacity-[0.06]"
            animate={false}
            className="bottom-0 right-0 pointer-events-none select-none"
          />

          {/* Drawer Header */}
          <div className="relative p-5 border-b border-slate-200/90 bg-slate-50/80 flex items-center justify-between z-10">
            <div className="flex items-center gap-2.5">
              <SpiderLogo size="sm" />
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:text-red-600 hover:bg-white border border-transparent hover:border-slate-200 transition-all cursor-pointer"
              aria-label="Close menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links List */}
          <nav className="flex-1 px-4 py-5 overflow-y-auto space-y-1.5 z-10">
            {/* 1. Home */}
            <button
              onClick={() => {
                onClose();
                onNavigateHome();
              }}
              className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-red-50/80 group transition-colors text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-red-100 text-slate-700 group-hover:text-red-600 flex items-center justify-center transition-colors">
                  <Home className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-slate-900 group-hover:text-red-600 transition-colors block">
                    Home
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Hero & Central Portal</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition-colors" />
            </button>

            {/* 2. Resources */}
            <button
              onClick={() => {
                onClose();
                onNavigateResources();
              }}
              className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-red-50/80 group transition-colors text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-red-100 text-slate-700 group-hover:text-red-600 flex items-center justify-center transition-colors">
                  <BookOpen className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-slate-900 group-hover:text-red-600 transition-colors block">
                    Resources
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Batches, Notes & Formulae</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition-colors" />
            </button>

            {/* 3. Categories */}
            <button
              onClick={() => {
                onClose();
                onNavigateCategories();
              }}
              className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-red-50/80 group transition-colors text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-red-100 text-slate-700 group-hover:text-red-600 flex items-center justify-center transition-colors">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-slate-900 group-hover:text-red-600 transition-colors block">
                    Categories
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">46 Exam Hubs (A to Z)</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition-colors" />
            </button>

            {/* 4. Saved Batches */}
            <button
              onClick={() => {
                onClose();
                onOpenBookmarks();
              }}
              className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-red-50/80 group transition-colors text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-red-100 text-slate-700 group-hover:text-red-600 flex items-center justify-center transition-colors">
                  <Bookmark className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-slate-900 group-hover:text-red-600 transition-colors block">
                    Saved Batches
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Bookmarked Portals</span>
                </div>
              </div>
              {bookmarkCount > 0 ? (
                <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-600 font-bold text-xs">
                  {bookmarkCount}
                </span>
              ) : (
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition-colors" />
              )}
            </button>

            {/* 5. Student Profile */}
            <button
              onClick={() => {
                onClose();
                onOpenProfile();
              }}
              className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-red-50/80 group transition-colors text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-red-100 text-slate-700 group-hover:text-red-600 flex items-center justify-center transition-colors">
                  <User className="w-4 h-4 text-red-600" />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-slate-900 group-hover:text-red-600 transition-colors block">
                    Student Profile
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Preferences & History</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition-colors" />
            </button>

            {/* 6. About Multiverse */}
            <button
              onClick={() => {
                onClose();
                onOpenAbout();
              }}
              className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-red-50/80 group transition-colors text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-red-100 text-slate-700 group-hover:text-red-600 flex items-center justify-center transition-colors">
                  <Info className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-slate-900 group-hover:text-red-600 transition-colors block">
                    About Multiverse
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Mission & Guidelines</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition-colors" />
            </button>
          </nav>

          {/* Drawer Footer with strictly verified Telegram channel */}
          <div className="p-4 border-t border-slate-200 bg-slate-50/90 space-y-3 z-10">
            {/* 7. Join Telegram Community (strictly to https://t.me/Voidxevra) */}
            <a
              href="https://t.me/Voidxevra"
              target="_blank"
              rel="noopener noreferrer"
              className="spidy-btn w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md transition-all"
            >
              <Send className="w-4 h-4 fill-white" />
              <span>Join Telegram Community</span>
            </a>

            <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium pt-1">
              <span className="inline-flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-red-500" />
                <span>SPIDY SHUBH</span>
              </span>
              <span>Student Resource Multiverse</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

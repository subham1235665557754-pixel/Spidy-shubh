import React, { useState } from 'react';
import { SpiderLogo } from './SpiderLogo';
import { User, Menu, Send, Bookmark, Layers, Compass } from 'lucide-react';
import { SideNavDrawer } from './SideNavDrawer';

interface NavbarProps {
  bookmarkCount: number;
  onOpenBookmarks: () => void;
  onOpenSuggestion: () => void;
  onOpenAbout: () => void;
  onOpenProfile: () => void;
  currentPage: 'home' | 'profile';
  onGoHome: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  bookmarkCount,
  onOpenBookmarks,
  onOpenSuggestion,
  onOpenAbout,
  onOpenProfile,
  currentPage,
  onGoHome,
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleNavClick = (sectionId?: string) => {
    if (currentPage !== 'home') {
      onGoHome();
    }
    if (sectionId) {
      setTimeout(() => {
        const el = document.querySelector(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 50);
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-2xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-15 sm:h-16 flex items-center justify-between gap-3">
          {/* Left: Brand Logo */}
          <button
            onClick={onGoHome}
            className="flex items-center gap-2 group transition-transform active:scale-95 text-left cursor-pointer"
          >
            <SpiderLogo size="sm" />
          </button>

          {/* Center Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-5 text-xs sm:text-sm font-semibold text-slate-600">
            <button
              onClick={() => handleNavClick('#resources')}
              className="hover:text-red-600 transition-colors cursor-pointer py-1 flex items-center gap-1.5"
            >
              <Compass className="w-4 h-4" />
              <span>Explore Batches</span>
            </button>
            <button
              onClick={() => handleNavClick('#categories')}
              className="hover:text-red-600 transition-colors cursor-pointer py-1 flex items-center gap-1.5"
            >
              <Layers className="w-4 h-4" />
              <span>46 Categories</span>
            </button>
            <button
              onClick={onOpenBookmarks}
              className="hover:text-red-600 transition-colors cursor-pointer py-1 flex items-center gap-1.5"
            >
              <Bookmark className="w-4 h-4" />
              <span>Saved Batches</span>
              {bookmarkCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-red-100 text-red-600 font-bold text-[10px]">
                  {bookmarkCount}
                </span>
              )}
            </button>
            <button
              onClick={() => handleNavClick('#faq')}
              className="hover:text-red-600 transition-colors cursor-pointer py-1"
            >
              FAQ
            </button>
          </nav>

          {/* Right: Telegram + Profile Icon + Hamburger Menu */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Telegram Channel Button */}
            <a
              href="https://t.me/Voidxevra"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-700 text-white shadow-2xs transition-colors shrink-0"
              title="Join Telegram Community (@Voidxevra)"
            >
              <Send className="w-3.5 h-3.5 fill-white shrink-0" />
              <span className="hidden xs:inline">Telegram</span>
            </a>

            {/* Profile Icon Button */}
            <button
              onClick={onOpenProfile}
              className={`flex items-center justify-center p-2 sm:px-2.5 sm:py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                currentPage === 'profile'
                  ? 'bg-slate-900 border-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 border-slate-200 text-slate-800 hover:bg-slate-200/80 hover:border-slate-300'
              }`}
              title="Student Profile & Preferences"
              aria-label="Student Profile"
            >
              <User className="w-4 h-4 text-red-600 sm:mr-1 shrink-0" />
              <span className="hidden sm:inline">Profile</span>
            </button>

            {/* Hamburger Menu Toggle Button -> Opens SideNavDrawer */}
            <button
              onClick={() => setDrawerOpen(true)}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
              aria-label="Open side navigation drawer"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Side Navigation Drawer */}
      <SideNavDrawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onNavigateHome={() => {
          handleNavClick();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateResources={() => handleNavClick('#resources')}
        onNavigateCategories={() => handleNavClick('#categories')}
        onOpenBookmarks={onOpenBookmarks}
        onOpenProfile={onOpenProfile}
        onOpenAbout={onOpenAbout}
        bookmarkCount={bookmarkCount}
      />
    </>
  );
};

import React from 'react';

interface AlphabetFilterProps {
  selectedLetter: string;
  onSelectLetter: (letter: string) => void;
  availableLetters: string[];
}

export const AlphabetFilter: React.FC<AlphabetFilterProps> = ({
  selectedLetter,
  onSelectLetter,
  availableLetters,
}) => {
  const letters = ['ALL', ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')];

  return (
    <div className="w-full overflow-x-auto pb-2 scrollbar-none">
      <div className="flex items-center gap-1 min-w-max p-1 bg-white rounded-2xl border border-slate-200 shadow-2xs">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 select-none">
          A–Z:
        </span>
        {letters.map((char) => {
          const isAll = char === 'ALL';
          const isAvailable = isAll || availableLetters.includes(char);
          const isSelected = selectedLetter === char;

          return (
            <button
              key={char}
              disabled={!isAvailable}
              onClick={() => onSelectLetter(char)}
              className={`min-w-7 h-7 px-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center ${
                isSelected
                  ? 'bg-red-600 text-white shadow-xs font-bold'
                  : isAvailable
                  ? 'text-slate-700 hover:text-red-600 hover:bg-slate-100'
                  : 'text-slate-300 cursor-not-allowed opacity-40'
              }`}
              title={isAvailable ? `Filter by ${char}` : `No platforms starting with ${char}`}
            >
              {char}
            </button>
          );
        })}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { X, Send, Mail, CheckCircle2, Copy, Check } from 'lucide-react';
import { SpiderLogo } from './SpiderLogo';

interface InfoModalProps {
  type: 'about' | 'contact' | 'privacy' | 'disclaimer' | null;
  onClose: () => void;
}

export const InfoModals: React.FC<InfoModalProps> = ({ type, onClose }) => {
  const [copiedAppUrl, setCopiedAppUrl] = useState(false);
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [contactMessage, setContactMessage] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');

  if (!type) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-dev-qtyz7n6jwvu3f3xhq34yvy-829898756502.asia-southeast1.run.app';

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopiedAppUrl(true);
    setTimeout(() => setCopiedAppUrl(false), 2000);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSubmitted(true);
    setTimeout(() => {
      setContactSubmitted(false);
      setContactName('');
      setContactEmail('');
      setContactMessage('');
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-3xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SpiderLogo size="sm" showText={false} />
            <h3 className="font-heading text-lg font-bold text-slate-900 uppercase tracking-wider">
              {type === 'about' && 'About SPIDY SHUBH'}
              {type === 'contact' && 'Contact Support & Admin'}
              {type === 'privacy' && 'Privacy Policy'}
              {type === 'disclaimer' && 'Educational Disclaimer & DMCA'}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white text-slate-400 hover:text-slate-800 border border-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
          {/* ABOUT MODAL */}
          {type === 'about' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <h4 className="font-heading text-base font-bold text-slate-900">
                  Empowering Aspirants with Structured Clarity
                </h4>
                <p>
                  <strong>SPIDY SHUBH</strong> is an independent educational resource directory designed for competitive exam aspirants across India (IIT JEE, NEET UG, UPSC, SSC, and boards).
                </p>
                <p>
                  Instead of hunting across dozens of scattered channels, SPIDY SHUBH catalogs verified batch roadmaps, faculty lineups, formula sheets, and official portals in a fast, responsive interface.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="font-heading text-sm font-bold text-red-600 mb-1">
                    Authentic First
                  </div>
                  <p className="text-xs text-slate-500">
                    We strictly link to genuine, official destination URLs and authorized syllabus repositories.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="font-heading text-sm font-bold text-red-600 mb-1">
                    Student Community
                  </div>
                  <p className="text-xs text-slate-500">
                    Community-driven suggestions and active updates through our Telegram network at <a href="https://t.me/Voidxevra" target="_blank" rel="noopener noreferrer" className="font-bold underline text-red-600">@Voidxevra</a>.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* CONTACT MODAL */}
          {type === 'contact' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Have a query or platform correction? Reach out directly to the SPIDY SHUBH administration:
              </p>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Mail className="w-4 h-4 text-red-600" />
                  <div>
                    <div className="text-[11px] text-slate-400">Direct Support Email</div>
                    <a href="mailto:subham1235665557754@gmail.com" className="font-mono text-xs text-slate-900 hover:text-red-600 font-bold">
                      subham1235665557754@gmail.com
                    </a>
                  </div>
                </div>
                <a
                  href="mailto:subham1235665557754@gmail.com"
                  className="px-3 py-1.5 rounded-xl bg-red-600 text-white text-xs font-semibold hover:bg-red-700"
                >
                  Email Us
                </a>
              </div>

              {contactSubmitted ? (
                <div className="p-6 text-center space-y-2 bg-slate-50 rounded-2xl">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                  <div className="font-heading text-base font-bold text-slate-900">Message Dispatched!</div>
                  <p className="text-xs text-slate-500">Thank you for contacting SPIDY SHUBH. We will respond shortly.</p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-3 pt-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Your Name</label>
                    <input
                      type="text"
                      required
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Your Email</label>
                    <input
                      type="email"
                      required
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="e.g. rahul@example.com"
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Message</label>
                    <textarea
                      required
                      rows={3}
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder="Describe your inquiry..."
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    Send Message
                  </button>
                </form>
              )}
            </div>
          )}

          {/* PRIVACY POLICY */}
          {type === 'privacy' && (
            <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
              <h4 className="font-heading text-sm font-bold text-slate-900">1. Information Collection</h4>
              <p>
                SPIDY SHUBH operates with maximum privacy for learners. We do not require mandatory account registration to browse platforms, view batch directories, or access resource links.
              </p>

              <h4 className="font-heading text-sm font-bold text-slate-900">2. Local Storage</h4>
              <p>
                Your saved platform bookmarks, recent browsing history, and student profile preferences are stored strictly in your browser’s <code>localStorage</code>. No private profile data is shared or sold.
              </p>

              <h4 className="font-heading text-sm font-bold text-slate-900">3. Outbound Destination Links</h4>
              <p>
                When clicking an outbound link to an official portal (PW, Unacademy, Allen, YouTube, etc.), you are governed by the privacy policy of that independent platform.
              </p>
            </div>
          )}

          {/* DISCLAIMER & DMCA */}
          {type === 'disclaimer' && (
            <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
              <div className="p-3 rounded-2xl bg-red-50 border border-red-200 font-semibold text-red-800">
                Notice: SPIDY SHUBH is an independent navigational directory and educational index.
              </div>

              <h4 className="font-heading text-sm font-bold text-slate-900">Non-Hosting Policy</h4>
              <p>
                SPIDY SHUBH does not host, store, or stream any copyrighted video files or paid batch content on its servers. All listings provide informational metadata and redirect visitors to authorized external sources and official portals.
              </p>

              <h4 className="font-heading text-sm font-bold text-slate-900">Intellectual Property & Trademarks</h4>
              <p>
                All company names, logos, and trademarks mentioned (Physics Wallah, Unacademy, Allen, Khan GS, Drishti IAS, Careerwill, etc.) belong strictly to their respective registered owners.
              </p>

              <h4 className="font-heading text-sm font-bold text-slate-900">DMCA Takedown Procedure</h4>
              <p>
                If you are a copyright owner and request an index listing removal, email us at <strong>subham1235665557754@gmail.com</strong> or contact us on Telegram at <strong>@Voidxevra</strong>.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useEffect, useRef, useState } from 'react';
import { Platform } from '../types';
import { PlatformLogo } from './PlatformLogo';
import { SpiderWebDecoration } from './SpiderWebDecoration';
import { Sparkles, ChevronRight, Bookmark, ArrowRight, LayoutGrid, ListFilter } from 'lucide-react';

interface CategoryDirectoryProps {
  platforms: Platform[];
  onSelectPlatform: (platform: Platform) => void;
  bookmarkedIds: string[];
  onToggleBookmark: (id: string) => void;
}

// Capsule Card with IntersectionObserver scroll-reveal animation
const CapsuleCard: React.FC<{
  platform: Platform;
  index: number;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onSelectPlatform: (platform: Platform) => void;
}> = ({ platform, index, isBookmarked, onToggleBookmark, onSelectPlatform }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -40px 0px',
      }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  // Stagger delay based on index modulo 6 for smooth cascading entrance
  const staggerDelay = (index % 6) * 60;

  return (
    <div
      ref={cardRef}
      style={{
        transitionDelay: isVisible ? `${staggerDelay}ms` : '0ms',
      }}
      onClick={() => onSelectPlatform(platform)}
      className={`group relative overflow-hidden p-3.5 sm:p-4 rounded-2xl sm:rounded-3xl bg-white border border-slate-200/90 hover:border-red-500/80 hover:shadow-lg active:scale-[0.98] transition-all duration-300 cursor-pointer flex items-center justify-between gap-3 min-h-[72px] sm:min-h-[82px] ${
        isVisible
          ? 'opacity-100 translate-y-0'
          : 'opacity-0 translate-y-8'
      }`}
    >
      {/* Background Watermark Logo */}
      <div className="absolute -right-3 -bottom-3 w-20 h-20 sm:w-24 sm:h-24 opacity-[0.05] group-hover:opacity-[0.14] group-hover:scale-110 transition-all duration-300 pointer-events-none select-none overflow-hidden">
        {platform.logo ? (
          <img
            src={platform.logo}
            alt=""
            aria-hidden="true"
            className="w-full h-full object-contain filter blur-[0.3px]"
            loading="lazy"
          />
        ) : null}
      </div>

      {/* Gradient Hover Shimmer */}
      <div className="absolute inset-0 bg-gradient-to-r from-red-50/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none" />

      {/* Left: Circular Logo/Icon Container */}
      <div className="relative z-10 flex items-center gap-3 sm:gap-3.5 min-w-0 flex-1">
        <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-slate-50 border border-slate-200/90 shadow-2xs group-hover:border-red-300 group-hover:shadow-md flex items-center justify-center shrink-0 overflow-hidden p-1 transition-all duration-300">
          <PlatformLogo
            src={platform.logo}
            name={platform.name}
            brandColor={platform.brandColor}
            size="sm"
          />
        </div>

        {/* Right: Bold Category Title and Subtitle / Portal Count */}
        <div className="min-w-0 flex-1 pr-1">
          <div className="flex items-center gap-2 mb-0.5">
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-slate-900 group-hover:text-red-600 transition-colors truncate">
              {platform.name}
            </h3>
            <span className="text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200/70 shrink-0">
              {platform.portalCount} {platform.portalCount === 1 ? 'portal' : 'portals'}
            </span>
          </div>

          <p className="text-[11px] sm:text-xs text-slate-500 truncate leading-relaxed font-normal">
            {platform.tagline || platform.description}
          </p>

          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 font-medium">
            <span className="text-red-600 font-semibold">{platform.verifiedBatchCount} Batches</span>
            <span>·</span>
            <span>{platform.exams.slice(0, 2).join(', ')}</span>
          </div>
        </div>
      </div>

      {/* Actions: Bookmark & Explore Arrow */}
      <div className="relative z-10 flex items-center gap-1.5 shrink-0">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleBookmark(platform.id);
          }}
          className={`p-1.5 sm:p-2 rounded-xl transition-all cursor-pointer ${
            isBookmarked
              ? 'text-red-600 bg-red-50'
              : 'text-slate-400 hover:text-red-600 hover:bg-slate-100'
          }`}
          title={isBookmarked ? 'Remove saved batch' : 'Save platform'}
          aria-label="Save platform"
        >
          <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-red-600' : ''}`} />
        </button>

        <div className="w-8 h-8 rounded-full bg-slate-100 group-hover:bg-red-600 text-slate-600 group-hover:text-white flex items-center justify-center transition-all duration-200 shadow-2xs">
          <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
        </div>
      </div>
    </div>
  );
};

export const CategoryDirectory: React.FC<CategoryDirectoryProps> = ({
  platforms,
  onSelectPlatform,
  bookmarkedIds,
  onToggleBookmark,
}) => {
  // Sort platforms A to Z strictly for the directory
  const sortedPlatforms = [...platforms].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <section
      id="resources"
      className="relative w-full py-10 sm:py-16 bg-white overflow-hidden border-t border-slate-200 scroll-mt-20"
    >
      <span id="categories" className="sr-only">Categories</span>

      {/* Spider Web Watermarks in section corners (pointer-events: none) */}
      <SpiderWebDecoration position="top-right" size="lg" opacity="opacity-[0.06]" />
      <SpiderWebDecoration position="bottom-left" size="lg" opacity="opacity-[0.06]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 z-10">
        {/* Section Header (Inspired by reference) */}
        <div className="flex flex-col items-center text-center space-y-2 relative mb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-50 text-red-700 rounded-xl text-[11px] sm:text-xs font-bold border border-red-200/60">
            <Sparkles className="w-3.5 h-3.5 text-red-600" />
            <span>Alphabetical Order (A to Z)</span>
          </div>

          <h2
            className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tighter uppercase italic text-slate-900"
            style={{ textShadow: '2px 2px 0px #fca5a5' }}
          >
            EXPLORE CATEGORIES.
          </h2>

          <div className="w-14 sm:w-16 h-1 sm:h-1.5 bg-[#a31515] rounded-full mx-auto" />

          <p className="text-xs sm:text-sm md:text-base text-slate-600 max-w-xl mx-auto font-medium pt-0.5">
            Browse all 46 educational domains, coaching batches, and study hubs arranged serial-wise from A to Z with verified links.
          </p>

          <div className="sm:absolute sm:right-0 sm:bottom-0 pt-2 sm:pt-0">
            <span className="text-xs sm:text-sm font-bold text-[#a31515] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-red-50 border border-red-200/60">
              <span>All ({platforms.length})</span>
            </span>
          </div>
        </div>

        {/* 1-Column Mobile / 2-Column Desktop Capsule Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4">
          {sortedPlatforms.map((platform, idx) => (
            <CapsuleCard
              key={platform.id}
              platform={platform}
              index={idx}
              isBookmarked={bookmarkedIds.includes(platform.id)}
              onToggleBookmark={onToggleBookmark}
              onSelectPlatform={onSelectPlatform}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

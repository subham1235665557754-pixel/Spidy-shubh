import React, { useState } from 'react';

export type SpiderManStickerVariant = 'standing' | 'hanging' | 'action' | 'spider';

interface SpiderManStickerProps {
  variant: SpiderManStickerVariant;
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showSilkThread?: boolean;
  alt?: string;
}

export const SpiderManSticker: React.FC<SpiderManStickerProps> = ({
  variant,
  className = '',
  size = 'md',
  showSilkThread = true,
  alt = 'Spider-Man Sticker',
}) => {
  const [imageError, setImageError] = useState(false);

  // Standing Spider-Man near Hero / Browse Directory
  if (variant === 'standing') {
    const sizeClasses = {
      xs: 'w-16 h-auto',
      sm: 'w-20 sm:w-24 h-auto',
      md: 'w-20 sm:w-28 md:w-36 lg:w-44 h-auto',
      lg: 'w-28 sm:w-36 md:w-48 lg:w-56 h-auto',
      xl: 'w-36 sm:w-48 md:w-60 lg:w-72 h-auto',
    }[size];

    return (
      <div
        aria-hidden="true"
        className={`pointer-events-none select-none z-20 origin-bottom animate-spider-idle ${className}`}
      >
        {!imageError ? (
          <img
            src="/images/spydy_stand.png"
            alt={alt}
            className={`${sizeClasses} object-contain drop-shadow-2xl`}
            onError={() => setImageError(true)}
            loading="lazy"
          />
        ) : (
          <div className="w-16 h-28 bg-red-600/10 rounded-full flex items-center justify-center text-xs text-red-600 font-bold">
            🕷️
          </div>
        )}
      </div>
    );
  }

  // Hanging upside-down Spider-Man near FAQ section
  if (variant === 'hanging') {
    const sizeClasses = {
      xs: 'w-14 sm:w-16 h-auto',
      sm: 'w-16 sm:w-20 md:w-24 h-auto',
      md: 'w-16 sm:w-24 md:w-32 lg:w-36 h-auto',
      lg: 'w-24 sm:w-32 md:w-44 lg:w-48 h-auto',
      xl: 'w-32 sm:w-44 md:w-56 lg:w-64 h-auto',
    }[size];

    const threadHeight = {
      xs: 'h-8 sm:h-12',
      sm: 'h-10 sm:h-16',
      md: 'h-12 sm:h-20 md:h-24',
      lg: 'h-16 sm:h-24 md:h-32',
      xl: 'h-20 sm:h-32 md:h-40',
    }[size];

    return (
      <div
        aria-hidden="true"
        className={`pointer-events-none select-none z-20 flex flex-col items-center origin-top animate-spider-hang ${className}`}
      >
        {/* Silk web thread hanging from ceiling */}
        {showSilkThread && (
          <div
            className={`w-[1.5px] ${threadHeight} bg-gradient-to-b from-transparent via-slate-400 to-slate-600 opacity-60`}
          />
        )}
        {!imageError ? (
          <img
            src="/images/spydy_hang.png"
            alt={alt}
            className={`${sizeClasses} object-contain drop-shadow-2xl -mt-1`}
            onError={() => setImageError(true)}
            loading="lazy"
          />
        ) : (
          <div className="w-14 h-24 bg-red-600/10 rounded-full flex items-center justify-center text-xs text-red-600 font-bold -mt-1">
            🕷️
          </div>
        )}
      </div>
    );
  }

  // Action crouching Spider-Man (used in community banner or footer)
  if (variant === 'action') {
    const sizeClasses = {
      xs: 'w-16 h-auto',
      sm: 'w-20 sm:w-28 h-auto',
      md: 'w-28 sm:w-36 md:w-48 h-auto',
      lg: 'w-36 sm:w-48 md:w-60 h-auto',
      xl: 'w-48 sm:w-64 md:w-80 h-auto',
    }[size];

    return (
      <div
        aria-hidden="true"
        className={`pointer-events-none select-none z-10 animate-spider-float ${className}`}
      >
        {!imageError ? (
          <img
            src="/images/spidyman-nobg.webp"
            alt={alt}
            className={`${sizeClasses} object-contain drop-shadow-xl`}
            onError={() => setImageError(true)}
            loading="lazy"
          />
        ) : (
          <div className="w-16 h-16 bg-red-600/10 rounded-full flex items-center justify-center text-xs text-red-600 font-bold">
            🕷️
          </div>
        )}
      </div>
    );
  }

  // Spider icon / emblem (used in profile, badges, or headers)
  const sizeClasses = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
  }[size];

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none select-none z-10 animate-spider-float ${className}`}
    >
      {!imageError ? (
        <img
          src="/images/spidyspider.png"
          alt={alt}
          className={`${sizeClasses} object-contain drop-shadow-md`}
          onError={() => setImageError(true)}
          loading="lazy"
        />
      ) : (
        <span className="text-xl">🕷️</span>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Platform } from '../types/index';
import { PlatformLogo } from './PlatformLogo';
import { SpiderWebDecoration } from './SpiderWebDecoration';
import { SpiderManSticker } from './SpiderManSticker';
import {
  User,
  Bookmark,
  History,
  Settings,
  Edit3,
  Check,
  Trash2,
  ExternalLink,
  Target,
  GraduationCap,
  Globe,
  Bell,
  Clock,
  ArrowLeft,
  ChevronRight,
  Send,
  Star,
  CheckCircle2,
  ShieldCheck,
} from 'lucide-react';

interface ProfileViewProps {
  onBack: () => void;
  bookmarkedPlatforms: Platform[];
  onSelectPlatform: (p: Platform) => void;
  onRemoveBookmark: (id: string) => void;
  recentHistory: { platformId: string; viewedAt: string }[];
  allPlatforms: Platform[];
  onClearHistory: () => void;
}

const PROFILE_STORAGE_KEY = 'spidy_shubh_student_profile';

interface StudentProfile {
  name: string;
  telegramOrEmail: string;
  targetExam: string;
  academicStage: string;
  medium: string;
  dailyGoalHours: number;
  telegramNotifications: boolean;
  notesReminder: boolean;
  bio: string;
}

const DEFAULT_PROFILE: StudentProfile = {
  name: 'Shubh Aspirant',
  telegramOrEmail: '@spidy_aspirant',
  targetExam: 'IIT JEE Main & Advanced 2026',
  academicStage: 'Class 12th & Dropper Target',
  medium: 'Hinglish (Bilingual)',
  dailyGoalHours: 7,
  telegramNotifications: true,
  notesReminder: true,
  bio: 'Determined competitive exam aspirant targeting top AIR rank. Using SPIDY SHUBH for structured batch lectures and authentic DPPs.',
};

export const ProfileView: React.FC<ProfileViewProps> = ({
  onBack,
  bookmarkedPlatforms,
  onSelectPlatform,
  onRemoveBookmark,
  recentHistory,
  allPlatforms,
  onClearHistory,
}) => {
  const [profile, setProfile] = useState<StudentProfile>(() => {
    try {
      const stored = localStorage.getItem(PROFILE_STORAGE_KEY);
      return stored ? JSON.parse(stored) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  });

  const [activeTab, setActiveTab] = useState<'overview' | 'bookmarks' | 'history' | 'edit'>('overview');
  const [editForm, setEditForm] = useState<StudentProfile>(profile);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error(e);
    }
  }, [profile]);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfile(editForm);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      setActiveTab('overview');
    }, 1200);
  };

  // Map history to full platform objects
  const historyPlatforms = recentHistory
    .map((item) => {
      const p = allPlatforms.find((plat) => plat.id === item.platformId);
      return p ? { platform: p, viewedAt: item.viewedAt } : null;
    })
    .filter(Boolean) as { platform: Platform; viewedAt: string }[];

  return (
    <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-16">
      {/* Back Button & Breadcrumbs */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm font-semibold text-slate-700 hover:text-red-600 hover:border-red-200 transition-colors shadow-xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-red-600" />
          <span>Back to Directory</span>
        </button>

        <a
          href="https://t.me/Voidxevra"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-xs transition-colors"
        >
          <Send className="w-3.5 h-3.5 fill-white" />
          <span>Telegram: @Voidxevra</span>
        </a>
      </div>

      {/* Main Profile Header Card */}
      <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-6 mb-6 relative overflow-hidden">
        {/* Spider-Web Corner Decoration in Profile Card */}
        <SpiderWebDecoration position="top-right" size="sm" opacity="opacity-[0.06]" />

        {/* Small Spider-Man Character Accent Sticker */}
        <div className="absolute -bottom-2 right-4 sm:right-10 z-0 pointer-events-none opacity-25 sm:opacity-40">
          <SpiderManSticker variant="action" size="xs" alt="Spider-Man" className="w-16 sm:w-20" />
        </div>

        {/* Subtle red line accent at top */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-600 via-rose-500 to-red-700" />

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            {/* Avatar with Spider badge */}
            <div className="relative">
              <div className="w-18 h-18 rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-800 text-white flex items-center justify-center font-heading font-extrabold text-2xl border-2 border-red-600/30 shadow-md">
                {profile.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px] font-bold border-2 border-white shadow-xs">
                ★
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
                  {profile.name}
                </h1>
                <span className="px-2 py-0.5 rounded-md bg-red-50 border border-red-200 text-red-600 text-[11px] font-bold">
                  Verified Aspirant
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {profile.telegramOrEmail} · Member of SPIDY SHUBH Study Directory
              </p>
              <div className="flex items-center flex-wrap gap-2 text-xs text-slate-600 mt-2">
                <span className="inline-flex items-center gap-1 font-semibold text-slate-800">
                  <Target className="w-3.5 h-3.5 text-red-600" />
                  {profile.targetExam}
                </span>
                <span className="text-slate-300">·</span>
                <span className="inline-flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5 text-slate-400" />
                  {profile.academicStage}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Edit Profile Action */}
          <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
            <button
              onClick={() => {
                setEditForm(profile);
                setActiveTab('edit');
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Profile</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 mb-6 overflow-x-auto scrollbar-none">
        {[
          { id: 'overview', label: 'Student Overview', icon: User },
          { id: 'bookmarks', label: `Saved Bookmarks (${bookmarkedPlatforms.length})`, icon: Bookmark },
          { id: 'history', label: `Browsing History (${historyPlatforms.length})`, icon: History },
          { id: 'edit', label: 'Profile Preferences', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'border-red-600 text-red-600 bg-red-50/40 rounded-t-lg'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-red-600' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Main Info Column */}
          <div className="md:col-span-2 space-y-6">
            <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-3">
              <h3 className="font-heading text-base font-bold text-slate-900 flex items-center gap-2">
                <span>About My Preparation</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {profile.bio}
              </p>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                <div className="text-2xl font-extrabold font-heading text-slate-900">
                  {bookmarkedPlatforms.length}
                </div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">Saved Hubs</div>
              </div>
              <div className="p-4 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                <div className="text-2xl font-extrabold font-heading text-red-600">
                  {profile.dailyGoalHours}h
                </div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">Daily Goal</div>
              </div>
              <div className="p-4 rounded-xl bg-white border border-slate-200 text-center shadow-xs col-span-2 sm:col-span-1">
                <div className="text-2xl font-extrabold font-heading text-slate-900">
                  {historyPlatforms.length}
                </div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">Viewed Platforms</div>
              </div>
            </div>

            {/* Target Exam Detail Banner */}
            <div className="rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 text-white p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-red-200 mb-1">
                  Primary Milestone
                </div>
                <h4 className="font-heading text-xl font-bold leading-tight">
                  {profile.targetExam}
                </h4>
                <p className="text-xs text-red-100 mt-1">
                  Keep track of all syllabus revisions, daily DPPs, and national mock series right from SPIDY SHUBH.
                </p>
              </div>
              <button
                onClick={onBack}
                className="px-4 py-2 rounded-xl bg-white text-red-700 hover:bg-red-50 text-xs font-bold shrink-0 transition-colors cursor-pointer"
              >
                Browse Batches
              </button>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-4">
            <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-4">
              <h4 className="font-heading text-sm font-bold text-slate-900 uppercase tracking-wider">
                Student Preferences
              </h4>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="text-slate-500">Learning Medium</span>
                  <span className="font-semibold text-slate-800">{profile.medium}</span>
                </div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="text-slate-500">Academic Stage</span>
                  <span className="font-semibold text-slate-800">{profile.academicStage}</span>
                </div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="text-slate-500">Telegram Channel</span>
                  <a
                    href="https://t.me/Voidxevra"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-bold text-red-600 hover:underline"
                  >
                    @Voidxevra
                  </a>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Batch Alerts</span>
                  <span className="text-emerald-600 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Active
                  </span>
                </div>
              </div>
            </div>

            {/* Quick action card */}
            <div className="rounded-2xl bg-slate-900 text-white p-5 shadow-xs space-y-3">
              <h4 className="font-heading text-base font-bold">
                Join Student Channel
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Receive live exam schedule alerts and new batch notifications on Telegram.
              </p>
              <a
                href="https://t.me/Voidxevra"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <Send className="w-3.5 h-3.5 fill-white" />
                <span>Open @Voidxevra on Telegram</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BOOKMARKS */}
      {activeTab === 'bookmarks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-lg font-bold text-slate-900">
              Saved Coaching & Educational Portals
            </h3>
            <span className="text-xs font-semibold text-slate-500">
              {bookmarkedPlatforms.length} saved
            </span>
          </div>

          {bookmarkedPlatforms.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-white border border-slate-200 space-y-3">
              <Bookmark className="w-10 h-10 text-slate-300 mx-auto" />
              <h4 className="font-heading text-base font-bold text-slate-800">
                No saved platforms yet
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Click the bookmark star on any platform card on the homepage to pin it to your student profile.
              </p>
              <button
                onClick={onBack}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Explore Platforms
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {bookmarkedPlatforms.map((platform) => (
                <div
                  key={platform.id}
                  className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-red-300 transition-all shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2.5">
                        <PlatformLogo
                          src={platform.logo}
                          name={platform.name}
                          brandColor={platform.brandColor}
                          size="sm"
                        />
                        <div>
                          <h4 className="font-heading text-base font-bold text-slate-900 leading-snug">
                            {platform.name}
                          </h4>
                          <span className="text-[11px] text-slate-500">{platform.categoryLabel}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => onRemoveBookmark(platform.id)}
                        className="p-1 text-slate-400 hover:text-red-600 transition-colors"
                        title="Remove bookmark"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 mb-3">
                      {platform.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-500 font-medium">
                      {platform.verifiedBatchCount} Batches
                    </span>
                    <button
                      onClick={() => onSelectPlatform(platform)}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-red-600 text-white text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <span>Open Hub</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BROWSING HISTORY */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading text-lg font-bold text-slate-900">
                Recently Viewed Educational Platforms
              </h3>
              <p className="text-xs text-slate-500">
                Track resources and batches you recently explored during this session.
              </p>
            </div>
            {historyPlatforms.length > 0 && (
              <button
                onClick={onClearHistory}
                className="text-xs text-slate-500 hover:text-red-600 font-semibold cursor-pointer"
              >
                Clear History
              </button>
            )}
          </div>

          {historyPlatforms.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-white border border-slate-200 space-y-3">
              <History className="w-10 h-10 text-slate-300 mx-auto" />
              <h4 className="font-heading text-base font-bold text-slate-800">
                No recent browsing history
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Whenever you open a platform card to check its batches or notes, it will appear here for fast recall.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {historyPlatforms.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-white border border-slate-200 hover:border-slate-300 transition-all flex items-center justify-between gap-4 shadow-xs"
                >
                  <div
                    onClick={() => onSelectPlatform(item.platform)}
                    className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                  >
                    <PlatformLogo
                      src={item.platform.logo}
                      name={item.platform.name}
                      brandColor={item.platform.brandColor}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <h4 className="font-heading text-sm font-bold text-slate-900 truncate">
                        {item.platform.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 truncate">
                        {item.platform.categoryLabel} · {item.platform.verifiedBatchCount} Batches
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 text-xs">
                    <span className="text-slate-400 text-[11px] hidden sm:inline">
                      Viewed {item.viewedAt}
                    </span>
                    <button
                      onClick={() => onSelectPlatform(item.platform)}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-red-600 hover:text-white text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      View
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: EDIT PROFILE */}
      {activeTab === 'edit' && (
        <div className="max-w-2xl mx-auto rounded-2xl bg-white border border-slate-200 p-6 shadow-sm">
          <div className="mb-6 pb-4 border-b border-slate-100">
            <h3 className="font-heading text-xl font-bold text-slate-900">
              Edit Student Profile & Exam Preferences
            </h3>
            <p className="text-xs text-slate-500">
              Personalize your study goals, targeted competitive exams, and contact handle.
            </p>
          </div>

          {savedSuccess && (
            <div className="p-3 mb-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Profile preferences successfully saved!</span>
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Student Full Name
              </label>
              <input
                type="text"
                required
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs sm:text-sm focus:border-red-600 focus:bg-white focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Telegram Username or Email
                </label>
                <input
                  type="text"
                  required
                  value={editForm.telegramOrEmail}
                  onChange={(e) => setEditForm({ ...editForm, telegramOrEmail: e.target.value })}
                  placeholder="@username or student@gmail.com"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs sm:text-sm focus:border-red-600 focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target Examination
                </label>
                <select
                  value={editForm.targetExam}
                  onChange={(e) => setEditForm({ ...editForm, targetExam: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs sm:text-sm focus:border-red-600 focus:bg-white focus:outline-none cursor-pointer"
                >
                  <option value="IIT JEE Main & Advanced 2026">IIT JEE Main & Advanced 2026</option>
                  <option value="NEET UG 2026 (Medical)">NEET UG 2026 (Medical)</option>
                  <option value="UPSC Civil Services (IAS/IPS)">UPSC Civil Services (IAS/IPS)</option>
                  <option value="SSC CGL & Govt Exams">SSC CGL & Govt Exams</option>
                  <option value="Class 12 Boards PCM/PCB">Class 12 Boards PCM/PCB</option>
                  <option value="Defence NDA & CDS">Defence NDA & CDS</option>
                  <option value="Banking IBPS & SBI PO">Banking IBPS & SBI PO</option>
                  <option value="Software Development & Coding">Software Development & Coding</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Academic Stage
                </label>
                <select
                  value={editForm.academicStage}
                  onChange={(e) => setEditForm({ ...editForm, academicStage: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs sm:text-sm focus:border-red-600 focus:bg-white focus:outline-none cursor-pointer"
                >
                  <option value="Class 11th Regular">Class 11th Regular</option>
                  <option value="Class 12th Regular">Class 12th Regular</option>
                  <option value="Dropper / Repeater Batch">Dropper / Repeater Batch</option>
                  <option value="College Undergraduate">College Undergraduate</option>
                  <option value="Graduate / Working Aspirant">Graduate / Working Aspirant</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Preferred Language / Medium
                </label>
                <select
                  value={editForm.medium}
                  onChange={(e) => setEditForm({ ...editForm, medium: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs sm:text-sm focus:border-red-600 focus:bg-white focus:outline-none cursor-pointer"
                >
                  <option value="Hinglish (Bilingual)">Hinglish (Bilingual - Most Popular)</option>
                  <option value="Hindi Medium (शुद्ध हिंदी)">Hindi Medium (शुद्ध हिंदी)</option>
                  <option value="English Medium (Pure English)">English Medium (Pure English)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Target Daily Study Hours ({editForm.dailyGoalHours} hours/day)
              </label>
              <input
                type="range"
                min={3}
                max={14}
                value={editForm.dailyGoalHours}
                onChange={(e) => setEditForm({ ...editForm, dailyGoalHours: Number(e.target.value) })}
                className="w-full accent-red-600 cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                <span>3 hours</span>
                <span>8 hours (Standard)</span>
                <span>14 hours (Intensive)</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Bio & Study Strategy
              </label>
              <textarea
                rows={3}
                value={editForm.bio}
                onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs sm:text-sm focus:border-red-600 focus:bg-white focus:outline-none resize-none"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setActiveTab('overview')}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Save Profile Changes</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

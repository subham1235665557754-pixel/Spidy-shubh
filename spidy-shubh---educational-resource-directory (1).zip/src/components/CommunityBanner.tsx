import React from 'react';
import { Send, ArrowRight, CheckCircle2 } from 'lucide-react';
import { SpiderWebDecoration } from './SpiderWebDecoration';
import { SpiderManSticker } from './SpiderManSticker';

interface CommunityBannerProps {
  onOpenSuggestion: () => void;
}

export const CommunityBanner: React.FC<CommunityBannerProps> = ({ onOpenSuggestion }) => {
  return (
    <section className="relative my-10 overflow-hidden rounded-3xl bg-gradient-to-br from-red-600 via-rose-600 to-slate-900 text-white p-6 sm:p-10 shadow-lg">
      {/* Decorative Web Overlays */}
      <SpiderWebDecoration position="top-right" size="lg" opacity="opacity-[0.15]" dark={true} />
      <SpiderWebDecoration position="bottom-left" size="md" opacity="opacity-[0.12]" dark={true} />

      {/* Spider-Man Action Sticker in Corner */}
      <div className="absolute -bottom-3 -right-2 sm:right-6 md:right-10 z-0 pointer-events-none opacity-40 sm:opacity-75">
        <SpiderManSticker
          variant="action"
          size="md"
          alt="Spider-Man"
          className="w-24 sm:w-36 md:w-44"
        />
      </div>

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Side: Copy */}
        <div className="lg:col-span-7 space-y-3 sm:space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-[11px] font-bold uppercase tracking-wider text-white">
            <Send className="w-3.5 h-3.5 fill-white" />
            <span>Official SPIDY SHUBH Student Network</span>
          </div>

          <h2 className="font-heading text-2xl sm:text-4xl font-extrabold leading-tight">
            Never Miss a Batch Launch, Mock Test Schedule or Free Revision Capsule
          </h2>

          <p className="text-xs sm:text-sm text-red-100 leading-relaxed max-w-xl">
            Join thousands of JEE, NEET, and UPSC aspirants in our real-time Telegram channel (@Voidxevra).
            Get instant notifications when Physics Wallah, Allen, Unacademy, and Khan GS update their lecture roadmaps and syllabus notices.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 text-xs text-white">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
              <span>Instant NTA / UPSC exam updates</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
              <span>Direct batch request resolution</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
              <span>Free verified formula sheets</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
              <span>Zero spam, strict academic focus</span>
            </div>
          </div>
        </div>

        {/* Right Side: Action Box */}
        <div className="lg:col-span-5 flex flex-col gap-3 bg-white p-5 rounded-2xl text-slate-900 shadow-md">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-bold text-slate-800">Telegram Channel Active</span>
            </div>
            <span className="text-red-600 font-mono font-bold text-xs">@Voidxevra</span>
          </div>

          <a
            href="https://t.me/Voidxevra"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-5 rounded-xl font-bold uppercase tracking-wider text-xs sm:text-sm bg-red-600 hover:bg-red-700 text-white shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Send className="w-4 h-4 fill-white" />
            <span>Join SPIDY SHUBH Telegram Now</span>
            <ArrowRight className="w-4 h-4" />
          </a>

          <button
            onClick={onOpenSuggestion}
            className="w-full py-2.5 px-4 rounded-xl font-bold text-xs uppercase tracking-wider bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Can't find a batch? Submit Request</span>
          </button>
        </div>
      </div>
    </section>
  );
};

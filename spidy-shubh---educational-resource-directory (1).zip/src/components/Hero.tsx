import React from 'react';
import { Search, Compass, Send, Sparkles, User, Menu } from 'lucide-react';
import { SpiderLogo } from './SpiderLogo';

interface HeroProps {
  onExploreClick: () => void;
  onProfileClick: () => void;
  onMenuClick: () => void;
  onSearchChange: (query: string) => void;
  searchQuery: string;
  totalPlatforms: number;
  totalBatches: number;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreClick,
  onProfileClick,
  onMenuClick,
  onSearchChange,
  searchQuery,
  totalPlatforms,
  totalBatches,
}) => {
  return (
    <section
      aria-label="Spider-Verse Front Screen"
      className="relative w-full min-h-[92vh] sm:min-h-[95vh] lg:min-h-screen h-[100dvh] overflow-hidden flex flex-col justify-between bg-[#0A0F1D] text-white select-none"
    >
      {/* 1. Immersive Spider-Man Mask Wallpaper Background */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <img
          src="/images/image-1.png"
          alt="Spider-Man Suit - Spidy Shubh"
          className="w-full h-full object-cover object-[center_top] sm:object-center select-none brightness-95"
          loading="eager"
        />
        {/* Cinematic Vignette Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0F1D] via-[#0A0F1D]/45 to-[#0A0F1D]/75" />
        <div className="absolute inset-0 bg-radial-at-c from-transparent via-[#0A0F1D]/30 to-[#0A0F1D]/80" />
      </div>

      {/* 2. Spider-Web Background Vectors in Corners (pointer-events: none) */}
      <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
        {/* Top-Left Spinning Web */}
        <div className="absolute -top-4 -left-4 w-32 xs:w-44 sm:w-64 md:w-80 h-32 xs:h-44 sm:h-64 md:h-80 pointer-events-none">
          <div className="w-full h-full flex items-center justify-center animate-spider-spin-cw origin-center">
            <img
              src="/images/web1.png"
              alt="Spider Web Top Left"
              className="w-full h-full object-contain opacity-35 sm:opacity-45 mix-blend-screen animate-spider-zoom select-none pointer-events-none"
            />
          </div>
        </div>

        {/* Bottom-Right Counter-Spinning Web */}
        <div className="absolute -bottom-6 -right-6 w-32 xs:w-44 sm:w-64 md:w-80 h-32 xs:h-44 sm:h-64 md:h-80 pointer-events-none">
          <div className="w-full h-full flex items-center justify-center animate-spider-spin-ccw origin-center">
            <img
              src="/images/web1.png"
              alt="Spider Web Bottom Right"
              className="w-full h-full object-contain opacity-35 sm:opacity-45 mix-blend-screen animate-spider-zoom select-none pointer-events-none"
            />
          </div>
        </div>
      </div>

      {/* 3. Small Hanging Spider-Man Sticker with Gentle Swinging Keyframe in Top-Right Corner */}
      <div className="absolute top-0 right-14 xs:right-20 sm:right-28 md:right-36 z-30 pointer-events-none flex flex-col items-center">
        {/* Silk Web Thread */}
        <div className="w-[1.5px] h-9 xs:h-12 sm:h-16 md:h-20 bg-white/70 shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
        {/* Hanging Spider-Man Sticker */}
        <div className="animate-spider-hang origin-top">
          <img
            src="/images/spydy_hang.png"
            alt="Hanging Spider-Man Sticker"
            className="w-12 xs:w-16 sm:w-22 md:w-28 h-auto object-contain drop-shadow-[0_6px_14px_rgba(220,38,38,0.5)] select-none pointer-events-none"
          />
        </div>
      </div>

      {/* 4. Standing Spider-Man Mascot at Bottom-Right Corner */}
      <div className="absolute bottom-2 right-2 sm:bottom-4 sm:right-8 lg:right-12 z-20 pointer-events-none hidden xs:block">
        <div className="animate-spider-idle origin-bottom">
          <img
            src="/images/spydy_stand.png"
            alt="Standing Spider-Man Mascot"
            className="w-16 xs:w-20 sm:w-28 md:w-36 lg:w-44 h-auto object-contain drop-shadow-[0_8px_20px_rgba(0,0,0,0.7)] select-none pointer-events-none"
          />
        </div>
      </div>

      {/* 5. Top Bar: SPIDY SHUBH Brand Logo (Top-Left) & Profile + Hamburger Menu (Top-Right) */}
      <header className="relative w-full z-40 px-4 sm:px-6 md:px-8 lg:px-12 pt-4 sm:pt-6 flex items-center justify-between">
        {/* Top-Left: SPIDY SHUBH Brand Logo with Spider Icon */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 sm:gap-2.5 py-1">
            <img
              src="/IMG-20261013-WA0001.jpg"
              alt="SPIDY Logo Emblem"
              className="h-8 sm:h-10 w-auto object-contain drop-shadow-[0_0_12px_rgba(220,38,38,0.75)] select-none"
              onError={(e) => {
                const target = e.currentTarget;
                if (target.src.indexOf('/images/spidylogo-nobg.png') === -1) {
                  target.src = '/images/spidylogo-nobg.png';
                }
              }}
            />
            <div className="flex flex-col">
              <span className="font-heading text-lg sm:text-2xl font-black italic tracking-wider text-white uppercase leading-none drop-shadow-md">
                SPIDY <span className="text-red-500">SHUBH</span>
              </span>
              <span className="text-[9px] sm:text-[10px] font-extrabold tracking-[0.2em] text-red-400 uppercase mt-0.5">
                MULTIVERSE
              </span>
            </div>
          </div>
        </div>

        {/* Top-Right: Profile Icon and Interactive Hamburger Menu Button */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onProfileClick}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 shadow-sm"
            title="Student Profile & Bookmarks"
            aria-label="Student Profile"
          >
            <User className="w-4 h-4 text-red-400" />
            <span className="hidden sm:inline text-xs font-bold tracking-wide">Profile</span>
          </button>

          <button
            onClick={onMenuClick}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-red-600/90 hover:bg-red-600 backdrop-blur-md border border-red-500/50 text-white transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 shadow-md shadow-red-600/25"
            title="Open Menu Drawer"
            aria-label="Open Navigation Menu"
          >
            <Menu className="w-5 h-5 text-white" />
            <span className="hidden sm:inline text-xs font-bold uppercase tracking-wider">Menu</span>
          </button>
        </div>
      </header>

      {/* 6. Center / Bottom: Styled Brand Name, Tagline & Action Buttons */}
      <div className="relative z-30 px-4 sm:px-8 md:px-12 lg:px-16 pb-8 sm:pb-12 max-w-4xl">
        {/* Kicker Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/25 border border-red-500/40 text-[11px] sm:text-xs font-bold text-red-300 backdrop-blur-md mb-3">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span>STUDENT RESOURCE MULTIVERSE</span>
          <span className="text-red-400">·</span>
          <span>46+ PLATFORMS</span>
        </div>

        {/* Brand Name */}
        <h1
          className="text-3xl xs:text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black italic tracking-tighter leading-[0.92] uppercase select-none mb-2 break-words"
          style={{ textShadow: '3px 3px 0px #ef4444, 6px 6px 0px #a31515' }}
        >
          SPIDY<br />SHUBH.
        </h1>

        {/* Tagline */}
        <p className="text-xs xs:text-sm sm:text-base font-bold tracking-[0.18em] text-red-400 uppercase mb-2">
          STUDENT RESOURCE MULTIVERSE
        </p>

        <p className="text-xs sm:text-sm text-slate-300 max-w-xl font-normal leading-relaxed mb-5">
          Access verified study materials, lecture roadmaps, formula handbooks, and faculty directories across India's top competitive coaching platforms.
        </p>

        {/* Hero Search Bar */}
        <div className="max-w-xl relative mb-5">
          <div className="relative flex items-center">
            <Search className="absolute left-4 w-4 sm:w-5 h-4 sm:h-5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search 46 platforms, exams (IIT JEE, NEET, UPSC), or batches..."
              className="w-full pl-11 pr-24 py-3 sm:py-3.5 rounded-2xl bg-white/10 hover:bg-white/15 focus:bg-white text-white focus:text-slate-900 placeholder-slate-400 border border-white/20 focus:border-red-600 focus:ring-4 focus:ring-red-500/30 focus:outline-none backdrop-blur-md text-xs sm:text-sm transition-all shadow-lg"
            />
            {searchQuery ? (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 px-2 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold cursor-pointer"
              >
                Clear
              </button>
            ) : (
              <div className="absolute right-3 hidden sm:flex items-center gap-1 text-[11px] text-slate-300 bg-white/10 px-2 py-1 rounded-lg font-mono">
                <span>⌘K</span>
              </div>
            )}
          </div>
        </div>

        {/* Hero Action Buttons */}
        <div className="flex flex-wrap items-center gap-3">
          {/* EXPLORE Button */}
          <button
            onClick={onExploreClick}
            className="spidy-btn inline-flex items-center gap-2 px-6 sm:px-8 py-3 sm:py-3.5 rounded-xl font-black text-xs sm:text-sm tracking-wider uppercase bg-gradient-to-r from-[#a31515] to-[#dc2626] hover:from-[#7a0f0f] hover:to-[#b91c1c] text-white shadow-[0_0_25px_rgba(220,38,38,0.55),0_6px_15px_rgba(0,0,0,0.3)] border border-red-500/50 cursor-pointer active:scale-95 transition-all"
          >
            <Compass className="w-4 h-4 text-white group-hover:rotate-45 transition-transform" />
            <span>Explore</span>
          </button>

          {/* Telegram Channel Pill */}
          <a
            href="https://t.me/Voidxevra"
            target="_blank"
            rel="noopener noreferrer"
            className="spidy-btn inline-flex items-center gap-2 px-4 py-3 sm:py-3.5 rounded-xl text-xs font-bold text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 border border-white/10 backdrop-blur-md transition-all"
          >
            <Send className="w-3.5 h-3.5 fill-red-400 text-red-400" />
            <span>@Voidxevra</span>
          </a>
        </div>

        {/* Metrics Row */}
        <div className="mt-6 pt-4 border-t border-white/10 flex items-center gap-6 text-xs text-slate-300">
          <div>
            <span className="font-heading text-lg font-black text-white">{totalPlatforms}+</span>
            <span className="text-[11px] text-slate-400 ml-1.5 font-medium">Platforms</span>
          </div>
          <div className="w-1 h-1 rounded-full bg-red-500" />
          <div>
            <span className="font-heading text-lg font-black text-red-400">{totalBatches * 10}+</span>
            <span className="text-[11px] text-slate-400 ml-1.5 font-medium">Batches</span>
          </div>
          <div className="w-1 h-1 rounded-full bg-red-500" />
          <div>
            <span className="font-heading text-lg font-black text-white">100%</span>
            <span className="text-[11px] text-slate-400 ml-1.5 font-medium">Free Links</span>
          </div>
        </div>
      </div>
    </section>
  );
};

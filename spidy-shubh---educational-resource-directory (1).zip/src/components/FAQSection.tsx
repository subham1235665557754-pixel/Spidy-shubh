import React, { useState } from 'react';
import { FAQS_DATA } from '../data/faqs';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { SpiderWebDecoration } from './SpiderWebDecoration';
import { SpiderManSticker } from './SpiderManSticker';

export const FAQSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>('what-is-spidy-shubh');
  const [filter, setFilter] = useState<'all' | 'general' | 'batches' | 'notes' | 'dmca'>('all');

  const toggle = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  const filteredFaqs = FAQS_DATA.filter(
    (item) => filter === 'all' || item.category === filter
  );

  return (
    <section id="faq" className="relative py-14 border-t border-slate-200/90 scroll-mt-20 overflow-hidden bg-slate-50/40">
      {/* Background Spider-Web Accents */}
      <SpiderWebDecoration position="top-left" size="lg" opacity="opacity-[0.06]" />
      <SpiderWebDecoration position="bottom-right" size="lg" opacity="opacity-[0.06]" />

      {/* Hanging Upside-Down Spider-Man Sticker with swinging animation */}
      <div className="absolute top-0 right-2 sm:right-6 md:right-12 lg:right-16 z-20 pointer-events-none">
        <SpiderManSticker
          variant="hanging"
          size="md"
          alt="Hanging Spider-Man"
          className="w-14 xs:w-18 sm:w-24 md:w-32 lg:w-36"
        />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 z-10">
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 border border-red-200 text-xs font-bold text-red-700">
            <HelpCircle className="w-3.5 h-3.5 text-red-600" />
            <span>Student Help Center</span>
          </div>
          <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-slate-900">
            Frequently Asked Questions
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
            Everything you need to know about navigating SPIDY SHUBH, accessing verified study links, and our educational policies.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center justify-center gap-1.5 flex-wrap mb-6">
          {[
            { id: 'all', label: 'All Questions' },
            { id: 'general', label: 'General & Platform' },
            { id: 'batches', label: 'Batches & Courses' },
            { id: 'notes', label: 'Notes & Formulae' },
            { id: 'dmca', label: 'Legal & DMCA' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                filter === cat.id
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Accordion list */}
        <div className="space-y-3">
          {filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className="rounded-2xl bg-white border border-slate-200 overflow-hidden transition-all shadow-2xs"
              >
                <button
                  onClick={() => toggle(faq.id)}
                  className="w-full p-4 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50 transition-colors"
                >
                  <span className="font-heading text-base font-bold text-slate-900">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-red-600 transition-transform duration-200 shrink-0 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

import React from 'react';

interface SpiderLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const SpiderLogo: React.FC<SpiderLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
}) => {
  const sizeMap = {
    sm: { icon: 28, box: 'w-8 h-8', title: 'text-lg', sub: 'text-[9px]' },
    md: { icon: 38, box: 'w-10 h-10', title: 'text-2xl', sub: 'text-[11px]' },
    lg: { icon: 50, box: 'w-14 h-14', title: 'text-3xl sm:text-4xl', sub: 'text-xs' },
  };

  const currentSize = sizeMap[size];
  const [imgSrc, setImgSrc] = React.useState<string>('/IMG-20261013-WA0001.jpg');

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Spider Emblem from Photo */}
      <div className="relative flex items-center justify-center shrink-0">
        {/* Ambient Red Glow */}
        <div className="absolute -inset-1 rounded-2xl bg-red-600/30 blur-sm pointer-events-none" />
        
        <div className={`relative flex items-center justify-center ${currentSize.box} rounded-xl bg-zinc-950 border border-red-900/60 shadow-[0_0_15px_rgba(220,38,38,0.35)] overflow-hidden p-1`}>
          <img
            src={imgSrc}
            alt="SPIDY SHUBH Logo"
            className="w-full h-full object-contain drop-shadow-[0_0_8px_rgba(239,68,68,0.8)] select-none"
            onError={() => {
              if (imgSrc !== '/images/spidylogo-nobg.png') {
                setImgSrc('/images/spidylogo-nobg.png');
              }
            }}
          />
        </div>
      </div>

      {/* Typography */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 leading-none">
            <span className={`font-extrabold tracking-wider text-slate-900 ${currentSize.title} font-heading`}>
              SPIDY
            </span>
            <span className={`font-extrabold tracking-wider text-red-600 drop-shadow-sm ${currentSize.title} font-heading`}>
              SHUBH
            </span>
          </div>
          <span className={`font-semibold tracking-widest uppercase text-slate-500 ${currentSize.sub}`}>
            Study Resource Network
          </span>
        </div>
      )}
    </div>
  );
};

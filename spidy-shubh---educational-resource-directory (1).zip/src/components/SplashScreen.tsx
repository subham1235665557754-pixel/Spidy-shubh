import React, { useState, useEffect } from 'react';

const SPLASH_SESSION_KEY = 'spidy_shubh_splash_seen';

interface SplashScreenProps {
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  // Check if user has already seen splash screen in this session
  const [isVisible, setIsVisible] = useState<boolean>(() => {
    try {
      if (typeof window === 'undefined') return false;
      return sessionStorage.getItem(SPLASH_SESSION_KEY) !== 'true';
    } catch {
      return false;
    }
  });

  const [isFading, setIsFading] = useState<boolean>(false);

  useEffect(() => {
    if (!isVisible) return;

    // Show on initial load for exactly 2.5 seconds (2500ms) before fading out
    const fadeTimer = setTimeout(() => {
      setIsFading(true);
    }, 2500);

    // After 500ms fade-out transition (3.0s total), remove from DOM and persist in sessionStorage
    const removeTimer = setTimeout(() => {
      try {
        sessionStorage.setItem(SPLASH_SESSION_KEY, 'true');
      } catch (err) {
        console.error('Failed to set sessionStorage:', err);
      }
      setIsVisible(false);
      if (onFinish) onFinish();
    }, 3000);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, [isVisible, onFinish]);

  const handleDismiss = () => {
    try {
      sessionStorage.setItem(SPLASH_SESSION_KEY, 'true');
    } catch (err) {
      console.error(err);
    }
    setIsFading(true);
    setTimeout(() => {
      setIsVisible(false);
      if (onFinish) onFinish();
    }, 350);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <aside
      role="status"
      aria-live="polite"
      aria-label="SPIDY SHUBH Student Resource Multiverse Loading Screen"
      onClick={handleDismiss}
      className={`fixed inset-0 z-[99999] bg-white flex flex-col items-center justify-center select-none overflow-hidden transition-opacity duration-500 ease-out cursor-pointer ${
        isFading ? 'opacity-0 pointer-events-none' : 'opacity-100 pointer-events-auto'
      }`}
    >
      {/* Subtle Spider-Web Geometric Watermark in Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-[0.035]">
        <svg
          viewBox="0 0 1000 1000"
          className="w-full h-full object-cover text-red-600"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
        >
          <circle cx="500" cy="500" r="100" strokeDasharray="6 6" />
          <circle cx="500" cy="500" r="220" strokeDasharray="8 8" />
          <circle cx="500" cy="500" r="340" strokeDasharray="10 10" />
          <circle cx="500" cy="500" r="460" strokeDasharray="12 12" />
          <line x1="500" y1="0" x2="500" y2="1000" />
          <line x1="0" y1="500" x2="1000" y2="500" />
          <line x1="146" y1="146" x2="854" y2="854" />
          <line x1="146" y1="854" x2="854" y2="146" />
        </svg>
      </div>

      {/* Ambient soft red glow center */}
      <div className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-red-500/5 blur-3xl pointer-events-none -translate-y-6" />

      {/* Main Splash Content Container */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 max-w-sm sm:max-w-md animate-[splashPop_0.6s_cubic-bezier(0.16,1,0.3,1)_forwards]">
        {/* Red Spider Emblem Logo from Photo */}
        <div className="relative mb-5 flex items-center justify-center">
          <div className="absolute -inset-4 rounded-3xl bg-red-600/20 blur-xl pointer-events-none animate-pulse" />
          <div className="relative flex items-center justify-center w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-zinc-950 p-2.5 border-2 border-red-600/50 shadow-[0_12px_40px_rgba(230,36,41,0.35)] overflow-hidden group">
            <img
              src="/IMG-20261013-WA0001.jpg"
              alt="SPIDY SHUBH Logo"
              className="w-full h-full object-contain drop-shadow-[0_0_16px_rgba(239,68,68,0.85)] select-none transition-transform duration-500 group-hover:scale-105"
              onError={(e) => {
                const target = e.currentTarget;
                if (target.src.indexOf('/images/spidylogo-nobg.png') === -1) {
                  target.src = '/images/spidylogo-nobg.png';
                }
              }}
            />
          </div>
        </div>

        {/* Red 'SPIDY SHUBH' Logo Title */}
        <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-[#E62429] tracking-wider mb-2 drop-shadow-[0_2px_12px_rgba(230,36,41,0.18)]">
          SPIDY SHUBH
        </h1>

        {/* Text: STUDENT RESOURCE MULTIVERSE */}
        <p className="font-heading font-bold text-xs sm:text-sm text-slate-700 tracking-[0.22em] uppercase mb-8">
          STUDENT RESOURCE MULTIVERSE
        </p>

        {/* Loader with Three Bouncing Red Dots */}
        <div className="flex items-center justify-center gap-2.5 py-2" aria-label="Loading animation">
          <span
            className="w-3 h-3 rounded-full bg-[#E62429] shadow-[0_2px_6px_rgba(230,36,41,0.4)]"
            style={{
              animation: 'splashDotWave 1.2s ease-in-out infinite',
              animationDelay: '0s',
            }}
          />
          <span
            className="w-3 h-3 rounded-full bg-[#E62429] shadow-[0_2px_6px_rgba(230,36,41,0.4)]"
            style={{
              animation: 'splashDotWave 1.2s ease-in-out infinite',
              animationDelay: '0.2s',
            }}
          />
          <span
            className="w-3 h-3 rounded-full bg-[#E62429] shadow-[0_2px_6px_rgba(230,36,41,0.4)]"
            style={{
              animation: 'splashDotWave 1.2s ease-in-out infinite',
              animationDelay: '0.4s',
            }}
          />
        </div>
      </div>

      {/* Subtle skip indicator at the bottom */}
      <div className="absolute bottom-6 text-[11px] font-semibold text-slate-400 tracking-wider uppercase opacity-75">
        Tap anywhere to skip
      </div>

      {/* Embedded Animation Styles */}
      <style>{`
        @keyframes splashPop {
          0% {
            opacity: 0;
            transform: scale(0.92) translateY(10px);
          }
          100% {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }
        @keyframes splashDotWave {
          0%, 80%, 100% {
            transform: translateY(0);
            opacity: 0.35;
          }
          40% {
            transform: translateY(-10px);
            opacity: 1;
          }
        }
      `}</style>
    </aside>
  );
};

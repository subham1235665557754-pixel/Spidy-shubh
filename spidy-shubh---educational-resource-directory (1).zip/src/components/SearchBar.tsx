import React from 'react';
import { ExamCategory } from '../types';
import { CATEGORIES_CONFIG } from '../data/platforms';
import { Search, SlidersHorizontal, X } from 'lucide-react';

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedCategory: ExamCategory;
  onSelectCategory: (cat: ExamCategory) => void;
  sortBy: 'popular' | 'alpha' | 'batches' | 'rating';
  onSortChange: (sort: 'popular' | 'alpha' | 'batches' | 'rating') => void;
  resultsCount: number;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onSelectCategory,
  sortBy,
  onSortChange,
  resultsCount,
}) => {
  return (
    <div className="w-full space-y-3">
      {/* Category Filter Horizontal Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-none">
        {CATEGORIES_CONFIG.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id as ExamCategory)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 border ${
                isSelected
                  ? 'bg-red-600 border-red-600 text-white shadow-xs'
                  : 'bg-white border-slate-200 text-slate-700 hover:text-red-600 hover:border-slate-300'
              }`}
            >
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Query Bar + Sort Bar Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-2 rounded-2xl bg-white border border-slate-200 shadow-2xs">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Filter by platform, subject, faculty or batch..."
            className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-50 text-xs sm:text-sm text-slate-900 placeholder-slate-400 border border-transparent focus:border-red-600 focus:bg-white focus:outline-none transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center justify-between sm:justify-end gap-3 px-1 sm:px-0">
          <div className="text-xs text-slate-500 font-medium">
            <span className="text-red-600 font-bold">{resultsCount}</span> platform{resultsCount === 1 ? '' : 's'}
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <SlidersHorizontal className="w-3.5 h-3.5 text-red-600" />
            <span className="hidden xs:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value as any)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-800 focus:border-red-600 focus:outline-none cursor-pointer"
            >
              <option value="popular">Most Popular</option>
              <option value="alpha">Alphabetical (A–Z)</option>
              <option value="batches">Most Batches</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

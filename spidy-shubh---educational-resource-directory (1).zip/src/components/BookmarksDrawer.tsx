import React from 'react';
import { Platform } from '../types/index';
import { X, Bookmark, Trash2, ArrowRight } from 'lucide-react';
import { PlatformLogo } from './PlatformLogo';

interface BookmarksDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  bookmarkedPlatforms: Platform[];
  onSelectPlatform: (p: Platform) => void;
  onRemoveBookmark: (id: string) => void;
  onClearAll: () => void;
}

export const BookmarksDrawer: React.FC<BookmarksDrawerProps> = ({
  isOpen,
  onClose,
  bookmarkedPlatforms,
  onSelectPlatform,
  onRemoveBookmark,
  onClearAll,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-md h-full bg-white border-l border-slate-200 p-6 flex flex-col justify-between shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-red-100 text-red-600">
                <Bookmark className="w-5 h-5 fill-red-600" />
              </div>
              <div>
                <h3 className="font-heading text-lg font-bold text-slate-900">
                  Saved Platforms ({bookmarkedPlatforms.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Quick access to your preferred coaching hubs
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-100 text-slate-500 hover:text-slate-900 border border-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* List */}
          <div className="py-4 overflow-y-auto max-h-[calc(100vh-180px)] space-y-3">
            {bookmarkedPlatforms.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <Bookmark className="w-10 h-10 text-slate-300 mx-auto" />
                <p className="text-xs text-slate-500">
                  No platforms bookmarked yet.
                </p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Click the bookmark icon on any educational platform card to save it here for fast revision.
                </p>
              </div>
            ) : (
              bookmarkedPlatforms.map((platform) => (
                <div
                  key={platform.id}
                  className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-red-300 transition-all flex items-center justify-between gap-3 shadow-2xs group"
                >
                  <div
                    onClick={() => {
                      onClose();
                      onSelectPlatform(platform);
                    }}
                    className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                  >
                    <PlatformLogo
                      src={platform.logo}
                      name={platform.name}
                      brandColor={platform.brandColor}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <h4 className="font-heading text-sm font-bold text-slate-900 group-hover:text-red-600 transition-colors truncate">
                        {platform.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 truncate">
                        {platform.verifiedBatchCount} Batches · {platform.categoryLabel}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => onRemoveBookmark(platform.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-slate-100 transition-colors"
                      title="Remove bookmark"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        onClose();
                        onSelectPlatform(platform);
                      }}
                      className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:text-white hover:bg-red-600 transition-all"
                      title="Open platform details"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer */}
        {bookmarkedPlatforms.length > 0 && (
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <button
              onClick={onClearAll}
              className="text-slate-500 hover:text-red-600 transition-colors cursor-pointer"
            >
              Clear all bookmarks
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold cursor-pointer"
            >
              Close
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

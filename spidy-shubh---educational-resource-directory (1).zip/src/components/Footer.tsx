import React from 'react';
import { SpiderLogo } from './SpiderLogo';
import { SpiderWebDecoration } from './SpiderWebDecoration';
import { Send, ArrowUp } from 'lucide-react';

interface FooterProps {
  onOpenModal: (type: 'about' | 'contact' | 'privacy' | 'disclaimer') => void;
  onOpenSuggestion: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenModal, onOpenSuggestion }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-slate-200 bg-white text-slate-600 relative overflow-hidden">
      {/* Subtle Spider-Web Background Accents in Footer */}
      <SpiderWebDecoration position="top-right" size="lg" opacity="opacity-[0.05]" />
      <SpiderWebDecoration position="bottom-left" size="md" opacity="opacity-[0.04]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-8">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-3">
            <SpiderLogo size="sm" />
            <p className="text-xs text-slate-500 leading-relaxed max-w-sm">
              <strong>SPIDY SHUBH</strong> is a central educational directory for Indian students navigating verified coaching batches, star faculties, notes, and official portals.
            </p>
            <div className="flex items-center gap-2 pt-1 flex-wrap">
              <a
                href="https://t.me/Voidxevra"
                target="_blank"
                rel="noopener noreferrer"
                className="spidy-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-xs font-bold text-white shadow-2xs transition-colors"
              >
                <Send className="w-3.5 h-3.5 fill-white" />
                <span>Join Telegram @Voidxevra</span>
              </a>
            </div>
          </div>

          {/* Directory Verticals */}
          <div className="space-y-2.5">
            <h4 className="font-heading text-xs font-bold text-slate-900 uppercase tracking-wider">
              Exam Verticals
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li><a href="#platforms" className="hover:text-red-600 transition-colors">IIT JEE (Main & Adv)</a></li>
              <li><a href="#platforms" className="hover:text-red-600 transition-colors">NEET UG Medical</a></li>
              <li><a href="#platforms" className="hover:text-red-600 transition-colors">UPSC Civil Services</a></li>
              <li><a href="#platforms" className="hover:text-red-600 transition-colors">SSC CGL & Govt Jobs</a></li>
              <li><a href="#platforms" className="hover:text-red-600 transition-colors">Software & Coding</a></li>
              <li><a href="#platforms" className="hover:text-red-600 transition-colors">Class 9–12 Boards</a></li>
            </ul>
          </div>

          {/* Tools & Actions */}
          <div className="space-y-2.5">
            <h4 className="font-heading text-xs font-bold text-slate-900 uppercase tracking-wider">
              Tools & Community
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button onClick={onOpenSuggestion} className="hover:text-red-600 transition-colors text-left cursor-pointer">
                  Request Missing Batch
                </button>
              </li>
              <li>
                <a href="#faq" className="hover:text-red-600 transition-colors">
                  Frequently Asked Questions
                </a>
              </li>
              <li>
                <a href="https://t.me/Voidxevra" target="_blank" rel="noopener noreferrer" className="hover:text-red-600 transition-colors text-left">
                  Telegram: @Voidxevra
                </a>
              </li>
            </ul>
          </div>

          {/* Legal Policies */}
          <div className="space-y-2.5">
            <h4 className="font-heading text-xs font-bold text-slate-900 uppercase tracking-wider">
              Legal & Support
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button onClick={() => onOpenModal('disclaimer')} className="hover:text-red-600 transition-colors text-left cursor-pointer">
                  Disclaimer & DMCA Policy
                </button>
              </li>
              <li>
                <button onClick={() => onOpenModal('privacy')} className="hover:text-red-600 transition-colors text-left cursor-pointer">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => onOpenModal('about')} className="hover:text-red-600 transition-colors text-left cursor-pointer">
                  About SPIDY SHUBH
                </button>
              </li>
              <li>
                <button onClick={() => onOpenModal('contact')} className="hover:text-red-600 transition-colors text-left cursor-pointer">
                  Contact Support
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="text-center sm:text-left">
            <span>© 2026 <strong>SPIDY SHUBH</strong>. Educational Directory. All original brand trademarks belong to their respective institutions.</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={scrollToTop}
              className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:text-red-600 transition-colors cursor-pointer"
              title="Scroll to top"
              aria-label="Scroll to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

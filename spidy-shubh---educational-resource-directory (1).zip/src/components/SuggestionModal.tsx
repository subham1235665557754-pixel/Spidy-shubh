import React, { useState, useEffect } from 'react';
import { UserSuggestion } from '../types';
import { X, Send, PlusCircle, CheckCircle2, History, AlertCircle } from 'lucide-react';

interface SuggestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPlatform?: string;
  initialBatch?: string;
}

const STORAGE_KEY = 'spidy_shubh_user_suggestions';

export const SuggestionModal: React.FC<SuggestionModalProps> = ({
  isOpen,
  onClose,
  initialPlatform = '',
  initialBatch = '',
}) => {
  const [activeTab, setActiveTab] = useState<'form' | 'history'>('form');
  const [platformName, setPlatformName] = useState(initialPlatform);
  const [examType, setExamType] = useState('IIT JEE');
  const [batchName, setBatchName] = useState(initialBatch);
  const [description, setDescription] = useState('');
  const [userEmailOrTelegram, setUserEmailOrTelegram] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [pastSuggestions, setPastSuggestions] = useState<UserSuggestion[]>([]);

  useEffect(() => {
    if (initialPlatform) setPlatformName(initialPlatform);
    if (initialBatch) setBatchName(initialBatch);
  }, [initialPlatform, initialBatch, isOpen]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setPastSuggestions(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Error loading suggestions', e);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!platformName || !batchName) return;

    const newSuggestion: UserSuggestion = {
      id: 'sug_' + Date.now(),
      platformName,
      examType,
      batchName,
      description: description || 'No additional notes provided.',
      userEmailOrTelegram: userEmailOrTelegram || 'Anonymous Student',
      createdAt: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
      status: 'Pending Review',
    };

    const updated = [newSuggestion, ...pastSuggestions];
    setPastSuggestions(updated);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (err) {
      console.error(err);
    }

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setPlatformName('');
      setBatchName('');
      setDescription('');
      setUserEmailOrTelegram('');
      setActiveTab('history');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-xl bg-white border border-slate-200 rounded-3xl shadow-xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-100 text-red-600">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading text-xl sm:text-2xl font-bold text-slate-900">
                Suggest Batch or Educational Resource
              </h2>
              <p className="text-xs text-slate-500">
                Recommend new platforms, notes, or test series to SPIDY SHUBH.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white text-slate-400 hover:text-slate-800 border border-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-100 bg-white px-6">
          <button
            onClick={() => setActiveTab('form')}
            className={`py-2.5 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'form'
                ? 'border-red-600 text-red-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            New Suggestion
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-2.5 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'border-red-600 text-red-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>My Submitted Requests ({pastSuggestions.length})</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {activeTab === 'form' ? (
            submitted ? (
              <div className="py-10 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="font-heading text-xl font-bold text-slate-900">
                  Suggestion Received!
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Thank you! The SPIDY SHUBH student moderation team has logged your submission.
                  Check the Telegram channel (<a href="https://t.me/Voidxevra" target="_blank" rel="noopener noreferrer" className="text-red-600 underline">@Voidxevra</a>) for updates.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Platform Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={platformName}
                      onChange={(e) => setPlatformName(e.target.value)}
                      placeholder="e.g. Physics Wallah, Allen, Drishti"
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Target Exam Vertical *
                    </label>
                    <select
                      value={examType}
                      onChange={(e) => setExamType(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none cursor-pointer"
                    >
                      <option value="IIT JEE">IIT JEE (Main & Advanced)</option>
                      <option value="NEET UG">NEET UG (Medical)</option>
                      <option value="UPSC CSE">UPSC Civil Services</option>
                      <option value="SSC & Railway">SSC CGL / Railway RRB</option>
                      <option value="Coding & Tech">Coding & Software</option>
                      <option value="Class 9-12 Boards">Class 9-12 Boards</option>
                      <option value="Defence / NDA">Defence / NDA / CDS</option>
                      <option value="Banking / PO">Banking / IBPS / SBI</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Batch Title or Resource Needed *
                  </label>
                  <input
                    type="text"
                    required
                    value={batchName}
                    onChange={(e) => setBatchName(e.target.value)}
                    placeholder="e.g. Arjuna JEE 2027 or Chemistry Formula Handbook"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Additional Details & Official Link (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Specify educator name or link to official syllabus..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Your Telegram / Email (Optional)
                  </label>
                  <input
                    type="text"
                    value={userEmailOrTelegram}
                    onChange={(e) => setUserEmailOrTelegram(e.target.value)}
                    placeholder="@yourhandle or student@gmail.com"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs focus:border-red-600 focus:bg-white focus:outline-none"
                  />
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5 text-[11px] text-slate-600">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>
                    Note: SPIDY SHUBH indexes legitimate educational links. Please do not submit pirated links.
                  </span>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl font-bold uppercase tracking-wider text-xs bg-red-600 hover:bg-red-700 text-white shadow-xs transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Suggestion to SPIDY SHUBH</span>
                </button>
              </form>
            )
          ) : (
            <div className="space-y-3">
              {pastSuggestions.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  No previous suggestions submitted from this browser yet.
                </div>
              ) : (
                pastSuggestions.map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-heading font-bold text-slate-900">
                        {item.platformName} · {item.batchName}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-800">
                        {item.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Exam: <span className="font-semibold text-slate-700">{item.examType}</span> · Submitted {item.createdAt}
                    </div>
                    <p className="text-xs text-slate-600 italic">
                      "{item.description}"
                    </p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Platform, BatchItem, PortalItem } from '../types/index';
import { PlatformLogo } from './PlatformLogo';
import { SpiderWebDecoration } from './SpiderWebDecoration';
import { SpiderManSticker } from './SpiderManSticker';
import {
  X,
  ExternalLink,
  Bookmark,
  Share2,
  CheckCircle2,
  FileText,
  Users,
  Globe,
  Youtube,
  Send,
  Layers,
  Check,
  AlertTriangle,
  Compass,
} from 'lucide-react';

interface PlatformDetailModalProps {
  platform: Platform | null;
  onClose: () => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onRequestUrl?: (batchTitle: string, platformName: string) => void;
}

export const PlatformDetailModal: React.FC<PlatformDetailModalProps> = ({
  platform,
  onClose,
  isBookmarked,
  onToggleBookmark,
  onRequestUrl,
}) => {
  const [activeTab, setActiveTab] = useState<'portals' | 'batches' | 'resources' | 'faculty' | 'about'>('portals');
  const [copiedLink, setCopiedLink] = useState(false);

  if (!platform) return null;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 overflow-y-auto bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-4xl bg-white border border-slate-200 rounded-2xl sm:rounded-3xl shadow-xl overflow-hidden flex flex-col max-h-[94vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Banner */}
        <div
          className="relative px-4 sm:px-6 py-4 sm:py-6 border-b border-slate-200 overflow-hidden"
          style={{
            background: `linear-gradient(to bottom right, ${platform.brandColor}12 0%, #ffffff 80%)`,
          }}
        >
          {/* Subtle Corner Spider-Web in Header */}
          <SpiderWebDecoration position="top-right" size="sm" opacity="opacity-[0.08]" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="spidy-btn absolute top-4 right-4 p-2 rounded-xl bg-white text-slate-500 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer shadow-2xs z-20"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pr-12">
            <div className="flex items-center gap-4">
              <PlatformLogo
                src={platform.logo}
                name={platform.name}
                brandColor={platform.brandColor}
                size="xl"
              />

              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-slate-900">
                    {platform.name}
                  </h2>
                  <CheckCircle2 className="w-5 h-5 text-red-600 fill-red-100" />
                </div>
                <p className="text-xs sm:text-sm text-slate-600 italic mt-0.5 font-medium">
                  "{platform.tagline}"
                </p>
                <div className="flex items-center gap-2.5 text-xs text-slate-500 mt-2">
                  <span className="font-bold text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-md">
                    {platform.portalCount} {platform.portalCount === 1 ? 'Portal' : 'Portals'}
                  </span>
                  <span className="text-slate-300">·</span>
                  <span>{platform.categoryLabel}</span>
                  <span className="text-slate-300">·</span>
                  <span className="text-amber-600 font-bold">★ {platform.rating} ({platform.reviewCount.toLocaleString()} reviews)</span>
                </div>
              </div>
            </div>

            {/* Header Action Tools */}
            <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
              <button
                onClick={() => onToggleBookmark(platform.id)}
                className={`spidy-btn flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold cursor-pointer transition-all ${
                  isBookmarked
                    ? 'bg-red-50 text-red-700 border-red-300 shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-red-600 text-red-600' : ''}`} />
                <span>{isBookmarked ? 'Saved' : 'Save'}</span>
              </button>

              <button
                onClick={handleShare}
                className="spidy-btn flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold cursor-pointer transition-all"
                title="Share platform"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied' : 'Share'}</span>
              </button>

              <a
                href={platform.officialWebsite}
                target="_blank"
                rel="noopener noreferrer"
                className="spidy-btn flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold uppercase tracking-wider transition-all shadow-xs"
              >
                <span>Official Web</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-2 border-b border-slate-200 bg-slate-50/50 overflow-x-auto scrollbar-none">
          {[
            { id: 'portals', label: `Portals Directory (${platform.portalCount})`, icon: Compass },
            { id: 'batches', label: `Available Batches (${platform.batches.length})`, icon: Layers },
            { id: 'resources', label: `Free Notes & PYQs (${platform.resources.length})`, icon: FileText },
            { id: 'faculty', label: `Faculty Mentors (${platform.faculties.length})`, icon: Users },
            { id: 'about', label: 'About & Links', icon: Globe },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'border-red-600 text-red-600 bg-white rounded-t-xl'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-red-600' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="relative p-4 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* Subtle Background Spider Web inside Modal Body */}
          <SpiderWebDecoration position="bottom-right" size="lg" opacity="opacity-[0.04]" />
          {/* TAB 1: PORTALS DIRECTORY */}
          {activeTab === 'portals' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-heading">
                    Verified Portals for {platform.name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Each portal gives access to specific examination live classrooms, study workbooks, or test series.
                  </p>
                </div>
                <span className="text-xs font-bold text-red-600">
                  {platform.portals.length} Verified Portals
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {platform.portals.map((portal) => (
                  <div
                    key={portal.id}
                    className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-red-300 transition-all flex flex-col justify-between shadow-2xs group"
                  >
                    <div>
                      <div className="flex items-start gap-3 mb-3">
                        <PlatformLogo
                          src={portal.logo || platform.logo}
                          name={portal.name}
                          brandColor={platform.brandColor}
                          size="md"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-md">
                              {portal.status} Portal
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                              <Check className="w-3 h-3" /> Online
                            </span>
                          </div>

                          <h4 className="font-heading text-lg font-bold text-slate-900 leading-snug line-clamp-1">
                            <a
                              href={portal.portalUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="hover:text-red-600 transition-colors"
                            >
                              {portal.name}
                            </a>
                          </h4>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed mb-4">
                        {portal.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-end">
                      <a
                        href={portal.portalUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-red-600 text-white text-xs font-bold transition-colors shadow-2xs"
                      >
                        <span>Open Portal</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: BATCHES */}
          {activeTab === 'batches' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-heading">
                    Available Batches for {platform.name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Target year breakdown, educator lineup, and verified destination access links.
                  </p>
                </div>
                <span className="text-xs font-bold text-red-600">
                  {platform.batches.length} Programs
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {platform.batches.map((batch) => (
                  <div
                    key={batch.id}
                    className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-red-300 transition-all flex flex-col justify-between shadow-2xs group"
                  >
                    <div>
                      <div className="flex items-start gap-3 mb-3">
                        <PlatformLogo
                          src={batch.logo || platform.logo}
                          name={batch.title}
                          brandColor={platform.brandColor}
                          size="md"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-md truncate max-w-[170px]">
                              {batch.targetExam} ({batch.targetYear})
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 shrink-0">
                              {batch.status}
                            </span>
                          </div>

                          <h4 className="font-heading text-lg font-bold text-slate-900 leading-snug line-clamp-1">
                            <a
                              href={batch.officialCourseUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="hover:text-red-600 transition-colors"
                            >
                              {batch.title}
                            </a>
                          </h4>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed mb-3">
                        {batch.description}
                      </p>

                      <div className="text-xs text-slate-500 mb-2">
                        <span className="text-slate-400 font-medium">Faculty:</span>{' '}
                        <span className="font-medium text-slate-800">{batch.facultyNames.join(', ')}</span>
                      </div>

                      <div className="flex items-center gap-3 text-[11px] text-slate-600 mb-3">
                        {batch.notesAvailable && (
                          <span className="flex items-center gap-1 text-emerald-600 font-medium">
                            <Check className="w-3 h-3" /> Notes
                          </span>
                        )}
                        {batch.dppAvailable && (
                          <span className="flex items-center gap-1 text-emerald-600 font-medium">
                            <Check className="w-3 h-3" /> DPPs
                          </span>
                        )}
                        {batch.testSeriesIncluded && (
                          <span className="flex items-center gap-1 text-amber-600 font-medium">
                            <Check className="w-3 h-3" /> Tests
                          </span>
                        )}
                      </div>
                    </div>

                    {batch.urlVerified ? (
                      <a
                        href={batch.officialCourseUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-900 hover:bg-red-600 text-white text-xs font-bold uppercase tracking-wider transition-colors shadow-2xs"
                      >
                        <span>Open Portal</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 px-2 py-1 rounded-lg flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Needs URL
                        </span>
                        <button
                          onClick={() => onRequestUrl && onRequestUrl(batch.title, platform.name)}
                          className="flex-1 text-xs font-bold text-slate-700 hover:text-red-600 bg-slate-100 hover:bg-slate-200 py-1.5 px-3 rounded-lg transition-colors"
                        >
                          Submit Batch URL
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: FREE NOTES & RESOURCES */}
          {activeTab === 'resources' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 font-heading">
                  Verified Notes, Formula Handbooks & Question Archives
                </h3>
                <p className="text-xs text-slate-500">
                  Open educational handbooks, practice papers, and verified syllabus digests.
                </p>
              </div>

              <div className="space-y-3">
                {platform.resources.map((resource) => (
                  <div
                    key={resource.id}
                    className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 px-2 py-0.5 rounded-md bg-red-50 border border-red-200">
                          {resource.format}
                        </span>
                        <span className="text-xs text-slate-400">
                          Verified: {resource.verifiedDate}
                        </span>
                      </div>
                      <h4 className="font-heading text-base font-bold text-slate-900">
                        {resource.title}
                      </h4>
                      <p className="text-xs text-slate-600">
                        {resource.description}
                      </p>
                    </div>

                    <a
                      href={resource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold uppercase tracking-wider transition-all shadow-xs shrink-0"
                    >
                      <span>Open Verified Resource</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: FACULTY MENTORS */}
          {activeTab === 'faculty' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 font-heading">
                  Leading Educators & Star Faculty
                </h3>
                <p className="text-xs text-slate-500">
                  Learn directly from India’s top recognized mentors.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {platform.faculties.map((mentor) => (
                  <div
                    key={mentor.name}
                    className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="w-10 h-10 rounded-full bg-red-50 border border-red-200 flex items-center justify-center font-heading font-bold text-red-600 text-base mb-3">
                        {mentor.name[0]}
                      </div>
                      <h4 className="font-heading text-base font-bold text-slate-900">
                        {mentor.name}
                      </h4>
                      <p className="text-xs text-red-600 font-semibold mb-1">
                        {mentor.subject}
                      </p>
                      <p className="text-xs text-slate-500 mb-2">
                        {mentor.specialty}
                      </p>
                    </div>
                    <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-100">
                      Experience: <span className="text-slate-800 font-semibold">{mentor.experience}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: ABOUT & OFFICIAL LINKS */}
          {activeTab === 'about' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-2xs">
                <h3 className="font-heading text-lg font-bold text-slate-900">
                  About {platform.name}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {platform.description}
                </p>
              </div>

              <div>
                <h4 className="font-heading text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                  Verified Official Direct Portals
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {platform.officialWebsite && (
                    <a
                      href={platform.officialWebsite}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-red-400 text-slate-800 flex items-center justify-between transition-all shadow-2xs"
                    >
                      <div className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-red-600" />
                        <span className="text-xs font-semibold">Official Website</span>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                    </a>
                  )}

                  {platform.officialYoutube && (
                    <a
                      href={platform.officialYoutube}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-red-400 text-slate-800 flex items-center justify-between transition-all shadow-2xs"
                    >
                      <div className="flex items-center gap-2">
                        <Youtube className="w-4 h-4 text-red-600" />
                        <span className="text-xs font-semibold">Official YouTube</span>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                    </a>
                  )}

                  <a
                    href="https://t.me/Voidxevra"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-red-400 text-slate-800 flex items-center justify-between transition-all shadow-2xs"
                  >
                    <div className="flex items-center gap-2">
                      <Send className="w-4 h-4 text-red-600" />
                      <span className="text-xs font-semibold">Telegram Channel</span>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Note */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <span>SPIDY SHUBH is an educational indexer. All trademarks belong to respective owners.</span>
          <button
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
          >
            Close Viewer [Esc]
          </button>
        </div>
      </div>
    </div>
  );
};

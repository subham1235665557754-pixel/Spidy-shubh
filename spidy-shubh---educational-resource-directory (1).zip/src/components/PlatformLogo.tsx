import React, { useState } from 'react';

interface PlatformLogoProps {
  src?: string;
  name: string;
  brandColor?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const PlatformLogo: React.FC<PlatformLogoProps> = ({
  src,
  name,
  brandColor = '#dc2626',
  size = 'md',
  className = '',
}) => {
  const [imageError, setImageError] = useState(false);

  // Helper to extract clean 2-3 character initials for text fallback
  const getInitials = (str: string) => {
    if (!str) return 'SP';
    const cleaned = str
      .replace(/[()✅🚀🔥✨💥⚡💎🏆🎯📚🎓💡👑🌈💻📱😎🛒🦬🌟⚔️👨‍🏫]/g, '')
      .replace(/OFFICIAL/gi, '')
      .trim();
    const parts = cleaned.split(/\s+/).filter(Boolean);
    if (parts.length === 0) return str.slice(0, 2).toUpperCase();
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  };

  const sizeClasses = {
    xs: 'w-7 h-7 rounded-lg text-[10px]',
    sm: 'w-9 h-9 sm:w-10 sm:h-10 rounded-xl text-xs',
    md: 'w-12 h-12 rounded-xl text-sm',
    lg: 'w-14 h-14 rounded-2xl text-base',
    xl: 'w-16 h-16 sm:w-20 sm:h-20 rounded-2xl text-xl font-extrabold',
  }[size];

  // If image is present and has not errored, render the image logo
  if (src && !imageError) {
    return (
      <div
        className={`${sizeClasses} shrink-0 bg-white border border-slate-200/90 shadow-2xs overflow-hidden flex items-center justify-center p-1 group-hover:scale-105 transition-transform duration-200 ${className}`}
      >
        <img
          src={src}
          alt={`${name} logo`}
          className="w-full h-full object-contain rounded-md select-none"
          onError={() => setImageError(true)}
          loading="lazy"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  // Clean text-based initials fallback matching reference design
  return (
    <div
      className={`${sizeClasses} shrink-0 flex items-center justify-center font-heading font-extrabold text-white shadow-2xs group-hover:scale-105 transition-transform duration-200 select-none ${className}`}
      style={{
        background: `linear-gradient(135deg, ${brandColor} 0%, #0f172a 100%)`,
      }}
      title={name}
      aria-label={`${name} logo`}
    >
      <span>{getInitials(name)}</span>
    </div>
  );
};

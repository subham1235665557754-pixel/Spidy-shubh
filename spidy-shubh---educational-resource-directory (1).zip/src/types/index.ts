export type ExamCategory = 
  | 'all'
  | 'iit-jee'
  | 'neet'
  | 'upsc'
  | 'ssc-govt'
  | 'coding-tech'
  | 'boards'
  | 'defence'
  | 'banking'
  | 'teaching'
  | 'railway'
  | 'state-exams'
  | 'medical-pg';

export interface BatchItem {
  id: string;
  title: string;
  logo?: string;
  targetExam: string;
  targetYear: string;
  facultyNames: string[];
  subject: string;
  description: string;
  status: 'Active' | 'Popular' | 'New' | 'Upcoming';
  modulesCount: number;
  officialCourseUrl: string;
  urlVerified: boolean; // false means "Needs URL"
  notesAvailable: boolean;
  dppAvailable: boolean;
  testSeriesIncluded: boolean;
  portalName?: string;
}

export interface PortalItem {
  id: string;
  name: string;
  logo?: string;
  portalUrl: string;
  urlVerified: boolean;
  description: string;
  status: 'Active' | 'Verified' | 'Mirror' | 'Official';
  batchCount: number;
  batches: BatchItem[];
}

export interface ResourceItem {
  id: string;
  title: string;
  type: 'notes' | 'dpp' | 'pyq' | 'formula' | 'syllabus' | 'test-series';
  format: 'PDF Guide' | 'Official Portal' | 'Video Archive' | 'Practice Set';
  description: string;
  url: string;
  isOfficial: boolean;
  verifiedDate: string;
}

export interface FacultyMember {
  name: string;
  subject: string;
  experience: string;
  specialty: string;
}

export interface Platform {
  id: string;
  name: string;
  slug: string;
  logo?: string;
  tagline: string;
  establishedYear: number;
  category: ExamCategory;
  categoryLabel: string;
  exams: string[];
  brandColor: string; // Hex color for subtle ambient glow
  badgeText?: string;
  description: string;
  officialWebsite: string;
  officialYoutube?: string;
  officialAppUrl?: string;
  telegramChannel?: string;
  portalCount: number;
  portals: PortalItem[];
  verifiedBatchCount: number;
  rating: number; // e.g. 4.9
  reviewCount: number;
  featured: boolean;
  faculties: FacultyMember[];
  batches: BatchItem[];
  resources: ResourceItem[];
}

export interface UserSuggestion {
  id: string;
  platformName: string;
  examType: string;
  batchName: string;
  description: string;
  userEmailOrTelegram: string;
  createdAt: string;
  status: 'Pending Review' | 'Verified' | 'Added to Directory';
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'general' | 'batches' | 'notes' | 'dmca';
}

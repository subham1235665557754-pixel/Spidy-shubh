/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { Platform, ExamCategory } from './types';
import { PLATFORMS_DATA } from './data/platforms';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SearchBar } from './components/SearchBar';
import { AlphabetFilter } from './components/AlphabetFilter';
import { PlatformCard } from './components/PlatformCard';
import { PlatformDetailModal } from './components/PlatformDetailModal';
import { ProfileView } from './components/ProfileView';
import { SuggestionModal } from './components/SuggestionModal';
import { BookmarksDrawer } from './components/BookmarksDrawer';
import { CommunityBanner } from './components/CommunityBanner';
import { FAQSection } from './components/FAQSection';
import { InfoModals } from './components/InfoModals';
import { Footer } from './components/Footer';
import { SpiderWebDecoration } from './components/SpiderWebDecoration';
import { SpiderManSticker } from './components/SpiderManSticker';
import { CategoryDirectory } from './components/CategoryDirectory';
import { SideNavDrawer } from './components/SideNavDrawer';
import { SplashScreen } from './components/SplashScreen';
import { Send, FilterX } from 'lucide-react';

const BOOKMARKS_STORAGE_KEY = 'spidy_shubh_bookmarks';
const HISTORY_STORAGE_KEY = 'spidy_shubh_recent_history';

export default function App() {
  // Navigation View State ('home' or 'profile')
  const [currentPage, setCurrentPage] = useState<'home' | 'profile'>('home');

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ExamCategory>('all');
  const [selectedLetter, setSelectedLetter] = useState('ALL');
  const [sortBy, setSortBy] = useState<'popular' | 'alpha' | 'batches' | 'rating'>('popular');

  // Modals & Drawers
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | null>(null);
  const [isSuggestionOpen, setIsSuggestionOpen] = useState(false);
  const [suggestionPrefill, setSuggestionPrefill] = useState({ platform: '', batch: '' });
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);
  const [isSideNavOpen, setIsSideNavOpen] = useState(false);
  const [activeInfoModal, setActiveInfoModal] = useState<'about' | 'contact' | 'privacy' | 'disclaimer' | null>(null);

  // Bookmarks persistence
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(BOOKMARKS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : ['physics-wallah', 'allen', 'khan-global-studies'];
    } catch {
      return ['physics-wallah'];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(BOOKMARKS_STORAGE_KEY, JSON.stringify(bookmarkedIds));
    } catch (e) {
      console.error(e);
    }
  }, [bookmarkedIds]);

  // Browsing History persistence
  const [recentHistory, setRecentHistory] = useState<{ platformId: string; viewedAt: string }[]>(() => {
    try {
      const saved = localStorage.getItem(HISTORY_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [
        { platformId: 'physics-wallah', viewedAt: 'Today' },
        { platformId: 'allen', viewedAt: 'Yesterday' }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(recentHistory));
    } catch (e) {
      console.error(e);
    }
  }, [recentHistory]);

  const handleSelectPlatform = (platform: Platform) => {
    setSelectedPlatform(platform);
    // Add to recent history
    setRecentHistory((prev) => {
      const nowFormatted = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const filtered = prev.filter((item) => item.platformId !== platform.id);
      return [{ platformId: platform.id, viewedAt: nowFormatted }, ...filtered].slice(0, 20);
    });
  };

  const clearHistory = () => {
    setRecentHistory([]);
  };

  // Keyboard shortcut Cmd/Ctrl + K to focus search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (currentPage !== 'home') {
          setCurrentPage('home');
        }
        setTimeout(() => {
          const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
          if (searchInput) {
            searchInput.focus();
          }
        }, 50);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage]);

  const toggleBookmark = (id: string) => {
    setBookmarkedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const clearAllBookmarks = () => {
    setBookmarkedIds([]);
  };

  // Available starting letters in catalog
  const availableLetters = useMemo(() => {
    const letters = new Set<string>();
    PLATFORMS_DATA.forEach((p) => {
      const firstChar = p.name.trim()[0]?.toUpperCase();
      if (firstChar) letters.add(firstChar);
    });
    return Array.from(letters);
  }, []);

  // Filtered & Sorted platforms
  const filteredPlatforms = useMemo(() => {
    return PLATFORMS_DATA.filter((platform) => {
      // 1. Search Query Match
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const nameMatch = platform.name.toLowerCase().includes(q);
        const taglineMatch = platform.tagline.toLowerCase().includes(q);
        const descMatch = platform.description.toLowerCase().includes(q);
        const examMatch = platform.exams.some((e) => e.toLowerCase().includes(q));
        const facultyMatch = platform.faculties.some((f) =>
          f.name.toLowerCase().includes(q) || f.subject.toLowerCase().includes(q)
        );
        const batchMatch = platform.batches.some((b) =>
          b.title.toLowerCase().includes(q) || b.subject.toLowerCase().includes(q)
        );
        const portalMatch = platform.portals.some((p) =>
          p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
        );

        if (!nameMatch && !taglineMatch && !descMatch && !examMatch && !facultyMatch && !batchMatch && !portalMatch) {
          return false;
        }
      }

      // 2. Category Match
      if (selectedCategory !== 'all') {
        if (platform.category !== selectedCategory) {
          const categoryKeywords: Record<string, string[]> = {
            'iit-jee': ['jee', 'iit', 'engineering'],
            'neet': ['neet', 'medical', 'biology'],
            'upsc': ['upsc', 'civil', 'ias', 'cse', 'prelims', 'mains', 'bpsc'],
            'ssc-govt': ['ssc', 'cgl', 'chsl', 'cpo', 'govt', 'competition', 'police'],
            'railway': ['railway', 'rrb', 'alp', 'technician', 'ntpc'],
            'defence': ['defence', 'nda', 'cds', 'afcat', 'ssb'],
            'coding-tech': ['coding', 'dsa', 'web dev', 'placement', 'java'],
            'boards': ['cbse', 'icse', 'board', 'bseb', 'matric', 'inter', '12', '10'],
            'banking': ['bank', 'ibps', 'sbi', 'po', 'clerk'],
            'teaching': ['ctet', 'tet', 'super tet', 'teaching', 'kvs', 'dsssb'],
            'state-exams': ['state', 'police', 'ro', 'aro', 'bpsc', 'uppsc', 'ras'],
            'medical-pg': ['pg', 'fmge', 'ini-cet', 'next', 'nursing'],
          };
          const keywords = categoryKeywords[selectedCategory] || [];
          const matchesKeyword = platform.exams.some((ex) =>
            keywords.some((k) => ex.toLowerCase().includes(k))
          );
          if (!matchesKeyword) return false;
        }
      }

      // 3. Alphabet Letter Match
      if (selectedLetter !== 'ALL') {
        const firstLetter = platform.name.trim()[0]?.toUpperCase();
        if (firstLetter !== selectedLetter) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'popular') {
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        return b.reviewCount - a.reviewCount;
      }
      if (sortBy === 'alpha') {
        return a.name.localeCompare(b.name);
      }
      if (sortBy === 'batches') {
        return b.verifiedBatchCount - a.verifiedBatchCount;
      }
      if (sortBy === 'rating') {
        return b.rating - a.rating;
      }
      return 0;
    });
  }, [searchQuery, selectedCategory, selectedLetter, sortBy]);

  const bookmarkedPlatformsList = useMemo(() => {
    return PLATFORMS_DATA.filter((p) =>
      bookmarkedIds.includes(p.id) ||
      (bookmarkedIds.includes('pw-physicswallah') && p.id === 'physics-wallah') ||
      (bookmarkedIds.includes('allen-career-institute') && p.id === 'allen') ||
      (bookmarkedIds.includes('khan-gs-research-centre') && p.id === 'khan-global-studies')
    );
  }, [bookmarkedIds]);

  const handleExploreClick = () => {
    if (currentPage !== 'home') {
      setCurrentPage('home');
    }
    setTimeout(() => {
      const el = document.getElementById('resources') || document.getElementById('categories') || document.getElementById('platforms');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 50);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedLetter('ALL');
    setSortBy('popular');
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col font-sans overflow-x-hidden w-full max-w-full">
      {/* Session Animated Splash Screen */}
      <SplashScreen />

      {/* Compact Header */}
      <Navbar
        bookmarkCount={bookmarkedIds.length}
        onOpenBookmarks={() => setIsBookmarksOpen(true)}
        onOpenSuggestion={() => setIsSuggestionOpen(true)}
        onOpenAbout={() => setActiveInfoModal('about')}
        onOpenProfile={() => setCurrentPage('profile')}
        currentPage={currentPage}
        onGoHome={() => setCurrentPage('home')}
      />

      <main className="flex-1 w-full max-w-full overflow-x-hidden">
        {currentPage === 'profile' ? (
          /* Profile Page View */
          <ProfileView
            onBack={() => setCurrentPage('home')}
            bookmarkedPlatforms={bookmarkedPlatformsList}
            onSelectPlatform={handleSelectPlatform}
            onRemoveBookmark={toggleBookmark}
            recentHistory={recentHistory}
            allPlatforms={PLATFORMS_DATA}
            onClearHistory={clearHistory}
          />
        ) : (
          /* Clean Educational Directory Homepage */
          <>
            {/* Full-screen Spider-Man Hero Section with Wallpaper and Hanging Sticker */}
            <Hero
              onExploreClick={handleExploreClick}
              onProfileClick={() => setCurrentPage('profile')}
              onMenuClick={() => setIsSideNavOpen(true)}
              onSearchChange={setSearchQuery}
              searchQuery={searchQuery}
              totalPlatforms={PLATFORMS_DATA.length}
              totalBatches={PLATFORMS_DATA.reduce((acc, curr) => acc + curr.batches.length, 0)}
            />

            {/* Educational Category Directory: Capsule/Pill Cards A-Z with Scroll Reveal */}
            <CategoryDirectory
              platforms={PLATFORMS_DATA}
              onSelectPlatform={handleSelectPlatform}
              bookmarkedIds={bookmarkedIds}
              onToggleBookmark={toggleBookmark}
            />

            {/* Detailed Platform Directory & Search Catalog Section */}
            <section id="platforms" className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 scroll-mt-20 overflow-hidden">
              {/* Subtle Section Spider-Web Accents */}
              <SpiderWebDecoration position="top-right" size="lg" opacity="opacity-[0.05]" />
              <SpiderWebDecoration position="bottom-left" size="lg" opacity="opacity-[0.05]" />

              {/* Directory Section Kicker & Header */}
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6" id="categories">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-red-600 uppercase tracking-wider mb-1">
                    <span>Directory Catalog</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
                    <span>Verified Portals</span>
                  </div>
                  <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-slate-900">
                    Educational Platforms & Coaching Hubs
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                    Explore premier coaching institutes, faculty directories, and official study resources.
                  </p>
                </div>
              </div>

              {/* Search, Filter Tabs & Sort Controls */}
              <div className="mb-3">
                <SearchBar
                  searchQuery={searchQuery}
                  onSearchChange={setSearchQuery}
                  selectedCategory={selectedCategory}
                  onSelectCategory={setSelectedCategory}
                  sortBy={sortBy}
                  onSortChange={setSortBy}
                  resultsCount={filteredPlatforms.length}
                />
              </div>

              {/* Alphabet Index Filter */}
              <div className="mb-6">
                <AlphabetFilter
                  selectedLetter={selectedLetter}
                  onSelectLetter={setSelectedLetter}
                  availableLetters={availableLetters}
                />
              </div>

              {/* Platform Cards Grid */}
              {filteredPlatforms.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {filteredPlatforms.map((platform) => (
                    <PlatformCard
                      key={platform.id}
                      platform={platform}
                      isBookmarked={bookmarkedIds.includes(platform.id)}
                      onToggleBookmark={toggleBookmark}
                      onSelectPlatform={handleSelectPlatform}
                    />
                  ))}
                </div>
              ) : (
                /* Empty Filter State */
                <div className="py-16 px-4 rounded-3xl bg-white border border-slate-200 text-center space-y-3 shadow-2xs">
                  <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 mx-auto flex items-center justify-center">
                    <FilterX className="w-6 h-6" />
                  </div>
                  <h3 className="font-heading text-lg font-bold text-slate-900">
                    No matching educational platforms found
                  </h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    No platform matches "{searchQuery}". Try searching for another subject or suggest this platform.
                  </p>
                  <div className="flex items-center justify-center gap-2 pt-2">
                    <button
                      onClick={handleResetFilters}
                      className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold cursor-pointer"
                    >
                      Reset Filters
                    </button>
                    <button
                      onClick={() => setIsSuggestionOpen(true)}
                      className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      Suggest Platform
                    </button>
                  </div>
                </div>
              )}

              {/* Telegram Community Banner with @Voidxevra */}
              <CommunityBanner onOpenSuggestion={() => setIsSuggestionOpen(true)} />

              {/* FAQ Accordion Section */}
              <FAQSection />
            </section>
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenModal={(type) => setActiveInfoModal(type)}
        onOpenSuggestion={() => setIsSuggestionOpen(true)}
      />

      {/* Floating Telegram Quick Action (Visible on all viewports, linked to https://t.me/Voidxevra) */}
      <a
        href="https://t.me/Voidxevra"
        target="_blank"
        rel="noopener noreferrer"
        className="spidy-btn fixed bottom-5 right-5 z-40 group inline-flex items-center gap-2 px-3.5 py-3 sm:px-4 sm:py-3 rounded-full bg-red-600 hover:bg-red-700 text-white shadow-xl shadow-red-600/30 border border-red-500/40 cursor-pointer active:scale-95 transition-all"
        title="Join Telegram Community (@Voidxevra)"
        aria-label="Join Telegram Community"
      >
        <Send className="w-4 h-4 fill-white shrink-0 group-hover:rotate-12 transition-transform" />
        <span className="hidden sm:inline text-xs font-bold tracking-wide">Join Telegram (@Voidxevra)</span>
      </a>

      {/* Platform Detailed Modal View */}
      <PlatformDetailModal
        platform={selectedPlatform}
        onClose={() => setSelectedPlatform(null)}
        isBookmarked={selectedPlatform ? bookmarkedIds.includes(selectedPlatform.id) : false}
        onToggleBookmark={toggleBookmark}
        onRequestUrl={(batchTitle, platformName) => {
          setSuggestionPrefill({ platform: platformName, batch: batchTitle });
          setIsSuggestionOpen(true);
        }}
      />

      {/* Suggestion Form Modal */}
      <SuggestionModal
        isOpen={isSuggestionOpen}
        onClose={() => {
          setIsSuggestionOpen(false);
          setSuggestionPrefill({ platform: '', batch: '' });
        }}
        initialPlatform={suggestionPrefill.platform}
        initialBatch={suggestionPrefill.batch}
      />

      {/* Bookmarks Drawer */}
      <BookmarksDrawer
        isOpen={isBookmarksOpen}
        onClose={() => setIsBookmarksOpen(false)}
        bookmarkedPlatforms={bookmarkedPlatformsList}
        onSelectPlatform={handleSelectPlatform}
        onRemoveBookmark={toggleBookmark}
        onClearAll={clearAllBookmarks}
      />

      {/* Info Modals (About, Contact, Privacy, Disclaimer) */}
      <InfoModals
        type={activeInfoModal}
        onClose={() => setActiveInfoModal(null)}
      />

      {/* Side Navigation Drawer */}
      <SideNavDrawer
        isOpen={isSideNavOpen}
        onClose={() => setIsSideNavOpen(false)}
        onNavigateHome={() => {
          if (currentPage !== 'home') setCurrentPage('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateResources={() => {
          if (currentPage !== 'home') setCurrentPage('home');
          setTimeout(() => {
            document.getElementById('resources')?.scrollIntoView({ behavior: 'smooth' });
          }, 50);
        }}
        onNavigateCategories={() => {
          if (currentPage !== 'home') setCurrentPage('home');
          setTimeout(() => {
            document.getElementById('categories')?.scrollIntoView({ behavior: 'smooth' });
          }, 50);
        }}
        onOpenBookmarks={() => setIsBookmarksOpen(true)}
        onOpenProfile={() => setCurrentPage('profile')}
        onOpenAbout={() => setActiveInfoModal('about')}
        bookmarkCount={bookmarkedIds.length}
      />
    </div>
  );
}

import { Platform, ExamCategory } from '../types/index';

export const CATEGORIES_CONFIG = [
  { id: 'all', label: 'All Categories (46)', icon: 'Compass', count: 46 },
  { id: 'iit-jee', label: 'IIT JEE & Engineering', icon: 'Flame', count: 11 },
  { id: 'neet', label: 'NEET Medical', icon: 'HeartPulse', count: 8 },
  { id: 'upsc', label: 'UPSC & Civil Services', icon: 'Award', count: 8 },
  { id: 'ssc-govt', label: 'SSC & Govt Exams', icon: 'Landmark', count: 16 },
  { id: 'railway', label: 'Railway & ALP', icon: 'Train', count: 6 },
  { id: 'defence', label: 'Defence & Military', icon: 'ShieldAlert', count: 6 },
  { id: 'boards', label: 'State & CBSE Boards', icon: 'BookOpen', count: 15 },
  { id: 'coding-tech', label: 'Coding & Tech', icon: 'Terminal', count: 1 },
  { id: 'banking', label: 'Banking & PO', icon: 'Briefcase', count: 14 },
  { id: 'teaching', label: 'Teaching & TET', icon: 'GraduationCap', count: 2 },
  { id: 'medical-pg', label: 'Medical & Nursing', icon: 'HeartPulse', count: 1 },
];

export const PLATFORMS_DATA: Platform[] = [
  {
    "id": "cds-journey",
    "name": "CDS JOURNEY",
    "slug": "cds-journey",
    "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
    "tagline": "CDS JOURNEY Learning Hub",
    "establishedYear": 2021,
    "category": "defence",
    "categoryLabel": "Defence & Military Services",
    "exams": [
      "UPSC CDS",
      "NDA",
      "AFCAT",
      "SSB Interview"
    ],
    "brandColor": "#15803d",
    "badgeText": "CDS JOURNEY",
    "description": "Your ultimate guide and companion for clearing defence service examinations.",
    "officialWebsite": "https://cdsjourney.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://cdsjourney.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 5,
    "portals": [
      {
        "id": "official-cds-journey",
        "name": "CDS JOURNEY OFFICIAL ✅",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "portalUrl": "https://cdsjourney.com",
        "urlVerified": true,
        "description": "Official CDS JOURNEY guide for defence service examinations.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "cdsj-1",
        "name": "CDS JOURNEY 🚀",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "portalUrl": "https://merry-flan-8b1dd4.netlify.app/#batches",
        "urlVerified": true,
        "description": "CDS Journey defence exam batch navigation and study platform.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "cds-streamfiles",
        "name": "CDS Journey 🔥",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "portalUrl": "https://cds.streamfiles.eu.org/",
        "urlVerified": true,
        "description": "CDS Journey streamfiles portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "cds-journey-spidy",
        "name": "CDS Journey Spidy Universe ⚔️",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "portalUrl": "https://spidyuniversecds.vercel.app/",
        "urlVerified": true,
        "description": "CDS Journey defence exam batch navigation, NDA & CDS preparation platform on Spidy Universe.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "cdsj-vercel-portal",
        "name": "CDS JOURNEY Portal ⚔️",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "portalUrl": "https://cdsjourneyy.vercel.app/",
        "urlVerified": true,
        "description": "CDS Journey defence exam batch navigation, NDA & CDS preparation platform on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 5,
    "rating": 5,
    "reviewCount": 2100,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "UPSC CDS",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-cds-journey-batch",
        "title": "CDS JOURNEY OFFICIAL ✅",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "CDS JOURNEY",
          "Official",
          "Defence"
        ],
        "subject": "Official Platform",
        "description": "Official CDS JOURNEY guide for defence service examinations.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://cdsjourney.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "CDS JOURNEY OFFICIAL ✅"
      },
      {
        "id": "cdsj-1-batch",
        "title": "CDS JOURNEY 🚀",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "targetExam": "Defence & CDS Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "CDS JOURNEY",
          "Netlify",
          "Defence"
        ],
        "subject": "Defence & CDS Prep",
        "description": "CDS Journey defence exam batch navigation and study platform.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://merry-flan-8b1dd4.netlify.app/#batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "CDS JOURNEY 🚀"
      },
      {
        "id": "cds-streamfiles-batch",
        "title": "CDS Journey 🔥",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "CDS Journey",
          "Streamfiles"
        ],
        "subject": "Batches & Courses",
        "description": "CDS Journey streamfiles portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://cds.streamfiles.eu.org/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "CDS Journey 🔥"
      },
      {
        "id": "cds-journey-spidy-batch",
        "title": "CDS Journey Spidy Universe ⚔️",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "targetExam": "Defence Preparation",
        "targetYear": "2025-2026",
        "facultyNames": [
          "CDS Journey",
          "Spidy",
          "Spidy Universe"
        ],
        "subject": "Defence Preparation",
        "description": "CDS Journey defence exam batch navigation, NDA & CDS preparation platform on Spidy Universe.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://spidyuniversecds.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "CDS Journey Spidy Universe ⚔️"
      },
      {
        "id": "cdsj-vercel-portal-batch",
        "title": "CDS JOURNEY Portal ⚔️",
        "logo": "https://i.postimg.cc/RZKjTBwV/images-(2).jpg",
        "targetExam": "Defence & CDS Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "CDS JOURNEY",
          "Vercel",
          "Defence"
        ],
        "subject": "Defence & CDS Prep",
        "description": "CDS Journey defence exam batch navigation, NDA & CDS preparation platform on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://cdsjourneyy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "CDS JOURNEY Portal ⚔️"
      }
    ],
    "resources": [
      {
        "id": "cds-journey-res-1",
        "title": "CDS JOURNEY Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for CDS JOURNEY.",
        "url": "https://cdsjourney.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "allen",
    "name": "Allen",
    "slug": "allen",
    "logo": "https://preppronetwork.vercel.app/assets/allen-logo-BXCyAebg.png",
    "tagline": "Allen Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "IIT JEE & NEET Medical",
    "exams": [
      "JEE Main",
      "JEE Advanced",
      "NEET-UG",
      "Olympiads"
    ],
    "brandColor": "#0284c7",
    "badgeText": "Allen",
    "description": "Premier institute for JEE (Main+Advanced), NEET-UG, Pre-Nurture & Career Foundation preparation.",
    "officialWebsite": "https://preppronetwork.vercel.app/viewer",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://preppronetwork.vercel.app/viewer",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 3,
    "portals": [
      {
        "id": "allen-preppro-viewer",
        "name": "Allen PrepPro Viewer",
        "logo": "https://preppronetwork.vercel.app/assets/allen-logo-BXCyAebg.png",
        "portalUrl": "https://preppronetwork.vercel.app/viewer",
        "urlVerified": true,
        "description": "Allen Career Institute study portal, video lecture viewer, and test prep on PrepPro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "allen-online-render",
        "name": "Allen Online Portal",
        "logo": "https://preppronetwork.vercel.app/assets/allen-logo-BXCyAebg.png",
        "portalUrl": "https://allen-online.onrender.com/",
        "urlVerified": true,
        "description": "Allen Online digital batches, practice tests, and coaching curriculum on Render.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "allen-streamfiles",
        "name": "Allen StreamFiles",
        "logo": "https://preppronetwork.vercel.app/assets/allen-logo-BXCyAebg.png",
        "portalUrl": "https://others.streamfiles.eu.org/allen/",
        "urlVerified": true,
        "description": "Allen Career Institute coaching batches, lectures, and test prep portal on StreamFiles.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 3,
    "rating": 4.9,
    "reviewCount": 1860,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "JEE Main",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "allen-preppro-viewer-batch",
        "title": "Allen PrepPro Viewer",
        "logo": "https://preppronetwork.vercel.app/assets/allen-logo-BXCyAebg.png",
        "targetExam": "JEE & NEET Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Allen",
          "PrepPro",
          "Viewer"
        ],
        "subject": "JEE & NEET Coaching",
        "description": "Allen Career Institute study portal, video lecture viewer, and test prep on PrepPro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://preppronetwork.vercel.app/viewer",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Allen PrepPro Viewer"
      },
      {
        "id": "allen-online-render-batch",
        "title": "Allen Online Portal",
        "logo": "https://preppronetwork.vercel.app/assets/allen-logo-BXCyAebg.png",
        "targetExam": "JEE & NEET Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Allen",
          "Online",
          "Batches"
        ],
        "subject": "JEE & NEET Coaching",
        "description": "Allen Online digital batches, practice tests, and coaching curriculum on Render.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://allen-online.onrender.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Allen Online Portal"
      },
      {
        "id": "allen-streamfiles-batch",
        "title": "Allen StreamFiles",
        "logo": "https://preppronetwork.vercel.app/assets/allen-logo-BXCyAebg.png",
        "targetExam": "JEE & NEET Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Allen",
          "StreamFiles",
          "Batches"
        ],
        "subject": "JEE & NEET Coaching",
        "description": "Allen Career Institute coaching batches, lectures, and test prep portal on StreamFiles.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://others.streamfiles.eu.org/allen/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Allen StreamFiles"
      }
    ],
    "resources": [
      {
        "id": "allen-res-1",
        "title": "Allen Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Allen.",
        "url": "https://preppronetwork.vercel.app/viewer",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "career-will",
    "name": "Career Will",
    "slug": "career-will",
    "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
    "tagline": "Career Will Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "SSC & Government Exams",
    "exams": [
      "SSC CGL",
      "CHSL",
      "CPO",
      "Banking",
      "Teaching"
    ],
    "brandColor": "#7c3aed",
    "badgeText": "Career Will",
    "description": "Affordable and accessible learning solutions to help students achieve their career goals.",
    "officialWebsite": "https://careerwill.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://careerwill.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 7,
    "portals": [
      {
        "id": "official-career-will",
        "name": "Career Will OFFICIAL ✅",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "portalUrl": "https://careerwill.com",
        "urlVerified": true,
        "description": "Official Career Will learning solutions platform.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "cw-1",
        "name": "Career Will 🚀",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "portalUrl": "https://asmultiverse.in/details?id=Career%20Will",
        "urlVerified": true,
        "description": "Career Will course details and batch access on AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "cw-2",
        "name": "Career Will 🔥",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "portalUrl": "https://runtkyp.xo.je/?i=1",
        "urlVerified": true,
        "description": "Career Will learning gateway and study portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "careerwill-workers-bat",
        "name": "Careerwill BAT Portal",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "portalUrl": "https://bat.careerw.workers.dev/",
        "urlVerified": true,
        "description": "Careerwill fast batch access portal for SSC, Teaching, and Banking exams.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "cw-bison-dpdns",
        "name": "Careerwill Bison Portal 🦬",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "portalUrl": "https://cw.bison.dpdns.org/",
        "urlVerified": true,
        "description": "Careerwill competitive exam batches and lectures portal on Bison DPDNS.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "career-will-1",
        "name": "Carrier Will",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "portalUrl": "https://cw.studybison.in/",
        "urlVerified": true,
        "description": "Carrier Will by StudyBison",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "career-will-runtkyp",
        "name": "Career Will Runtkyp Portal",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "portalUrl": "https://runtkyp.xo.je/?i=2",
        "urlVerified": true,
        "description": "Career Will competitive exams preparation batches and study portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 7,
    "rating": 5,
    "reviewCount": 2340,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SSC CGL",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-career-will-batch",
        "title": "Career Will OFFICIAL ✅",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Career Will",
          "Official",
          "Careers"
        ],
        "subject": "Official Platform",
        "description": "Official Career Will learning solutions platform.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://careerwill.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Career Will OFFICIAL ✅"
      },
      {
        "id": "cw-1-batch",
        "title": "Career Will 🚀",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Career Will",
          "AS Multiverse",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Career Will course details and batch access on AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.in/details?id=Career%20Will",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Career Will 🚀"
      },
      {
        "id": "cw-2-batch",
        "title": "Career Will 🔥",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Career Will",
          "Runtkyp",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Career Will learning gateway and study portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://runtkyp.xo.je/?i=1",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Career Will 🔥"
      },
      {
        "id": "careerwill-workers-bat-batch",
        "title": "Careerwill BAT Portal",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "targetExam": "Competitive Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Careerwill",
          "BAT",
          "SSC"
        ],
        "subject": "Competitive Exams",
        "description": "Careerwill fast batch access portal for SSC, Teaching, and Banking exams.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bat.careerw.workers.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Careerwill BAT Portal"
      },
      {
        "id": "cw-bison-dpdns-batch",
        "title": "Careerwill Bison Portal 🦬",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "targetExam": "Competitive Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Careerwill",
          "Bison",
          "Govt Exams"
        ],
        "subject": "Competitive Exams",
        "description": "Careerwill competitive exam batches and lectures portal on Bison DPDNS.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://cw.bison.dpdns.org/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Careerwill Bison Portal 🦬"
      },
      {
        "id": "career-will-1-batch",
        "title": "Carrier Will",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Carrier Will",
          "StudyBison"
        ],
        "subject": "Batches & Courses",
        "description": "Carrier Will by StudyBison",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://cw.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Carrier Will"
      },
      {
        "id": "career-will-runtkyp-batch",
        "title": "Career Will Runtkyp Portal",
        "logo": "https://careerwillforpc.com.in/wp-content/uploads/2026/03/careerwill-pc.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Career Will",
          "Runtkyp",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Career Will competitive exams preparation batches and study portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://runtkyp.xo.je/?i=2",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Career Will Runtkyp Portal"
      }
    ],
    "resources": [
      {
        "id": "career-will-res-1",
        "title": "Career Will Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Career Will.",
        "url": "https://careerwill.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "aash-officer",
    "name": "AASH Officer",
    "slug": "aash-officer",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTq6pmnz5_32ytmZynsrHywQU5GWPh7F39oiU2aImH9_Q&s",
    "tagline": "AASH Officer Learning Hub",
    "establishedYear": 2021,
    "category": "railway",
    "categoryLabel": "Railway, ALP & Officer",
    "exams": [
      "Railway ALP",
      "Technician Grade 1 & 3",
      "RRB NTPC",
      "Group D"
    ],
    "brandColor": "#ea580c",
    "badgeText": "AASH Officer",
    "description": "Targeted learning initiative and officer exam preparation portal for competitive recruitment and banking examinations.",
    "officialWebsite": "https://studyapkmod-aash.vercel.app/home",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://studyapkmod-aash.vercel.app/home",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "aash-officer-studyapkmod",
        "name": "AASH Officer",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTq6pmnz5_32ytmZynsrHywQU5GWPh7F39oiU2aImH9_Q&s",
        "portalUrl": "https://studyapkmod-aash.vercel.app/home",
        "urlVerified": true,
        "description": "Official AASH Officer exam preparation portal, batches, and video lectures.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.9,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Railway ALP",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "aash-officer-studyapkmod-batch",
        "title": "AASH Officer",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTq6pmnz5_32ytmZynsrHywQU5GWPh7F39oiU2aImH9_Q&s",
        "targetExam": "Officer & Competitive Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "AASH Officer",
          "Officer Exams",
          "Batches"
        ],
        "subject": "Officer & Competitive Exams",
        "description": "Official AASH Officer exam preparation portal, batches, and video lectures.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmod-aash.vercel.app/home",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "AASH Officer"
      }
    ],
    "resources": [
      {
        "id": "aash-officer-res-1",
        "title": "AASH Officer Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for AASH Officer.",
        "url": "https://studyapkmod-aash.vercel.app/home",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "book",
    "name": "PW BOOK",
    "slug": "book",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRer8oad1p28ArRprX_GU6yjym-n8P4gp4PPkXH2po9BQ&s=10",
    "tagline": "PW BOOK Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "PW Books & Study Material",
    "exams": [
      "PW Books",
      "Formula Sheets",
      "PYQ Modules",
      "Question Banks"
    ],
    "brandColor": "#dc2626",
    "badgeText": "PW BOOK",
    "description": "Explore diverse study materials and books.",
    "officialWebsite": "https://books.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://books.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 14,
    "portals": [
      {
        "id": "official-book",
        "name": "BOOK OFFICIAL ✅",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://books.com",
        "urlVerified": true,
        "description": "Official BOOK diverse study materials platform.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "bk-1",
        "name": "BOOK 🚀",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://bookverse.deltastudy.fun/",
        "urlVerified": true,
        "description": "Bookverse digital textbook and study resource library by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "bk-2",
        "name": "BOOK 🔥",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://studypanda.live/books",
        "urlVerified": true,
        "description": "StudyPanda online e-books and reference material library.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "bk-3",
        "name": "BOOK 🌟",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://books.studybeepro.site/",
        "urlVerified": true,
        "description": "StudyBeePro digital book library and preparation guides.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "bk-4",
        "name": "BOOK ✨",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://nexthope.pages.dev/pinnacle/",
        "urlVerified": true,
        "description": "Pinnacle book portal and study material collection by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pinnacle-dreamstudy-books",
        "name": "BOOK 💥",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://pinnacle-dreamstudy.pages.dev/",
        "urlVerified": true,
        "description": "Pinnacle Dream Study book collection and preparation guides.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "learnjh-books",
        "name": "Books ⚡",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://learnjh.vercel.app/books",
        "urlVerified": true,
        "description": "Library and book resources by LearnJH.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-books-streamfiles",
        "name": "Pw Books 💎",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://books.streamfiles.eu.org/",
        "urlVerified": true,
        "description": "Pw Books streamfiles portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "books-studybison",
        "name": "StudyBison Books 📚",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://books.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison digital textbook repository, module solutions, and e-library.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "bk-deltastudy-books",
        "name": "Delta Study Books 📚",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://books.deltastudy.in/",
        "urlVerified": true,
        "description": "Delta Study digital textbook, formula booklet, and competitive exam books library.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "books-1",
        "name": "Books",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "portalUrl": "https://books.asmultiverse.in/",
        "urlVerified": true,
        "description": "Books by ASMultiverse",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-books-deltaverse",
        "name": "PW Books DeltaVerse",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRer8oad1p28ArRprX_GU6yjym-n8P4gp4PPkXH2po9BQ&s=10",
        "portalUrl": "https://books.deltaverse.site/",
        "urlVerified": true,
        "description": "Physics Wallah digital book library, e-books, and study material on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pwx-books-pages",
        "name": "PWX Books Cloudflare",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRer8oad1p28ArRprX_GU6yjym-n8P4gp4PPkXH2po9BQ&s=10",
        "portalUrl": "https://pwxbooks.pages.dev/",
        "urlVerified": true,
        "description": "PWX Books Cloudflare Pages digital library for Physics Wallah textbooks and solutions.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pikachu-books-library",
        "name": "Pikachu Books Library",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRer8oad1p28ArRprX_GU6yjym-n8P4gp4PPkXH2po9BQ&s=10",
        "portalUrl": "https://pikachu-books.vercel.app/?view=library",
        "urlVerified": true,
        "description": "Pikachu Books interactive digital library reader for Physics Wallah books and notes.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 14,
    "rating": 5,
    "reviewCount": 3180,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "PW Books",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-book-batch",
        "title": "BOOK OFFICIAL ✅",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "Official",
          "Study Materials"
        ],
        "subject": "Official Platform",
        "description": "Official BOOK diverse study materials platform.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://books.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "BOOK OFFICIAL ✅"
      },
      {
        "id": "bk-1-batch",
        "title": "BOOK 🚀",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "Bookverse",
          "Delta Study"
        ],
        "subject": "Books & Study Materials",
        "description": "Bookverse digital textbook and study resource library by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bookverse.deltastudy.fun/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "BOOK 🚀"
      },
      {
        "id": "bk-2-batch",
        "title": "BOOK 🔥",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "StudyPanda",
          "Books"
        ],
        "subject": "Books & Study Materials",
        "description": "StudyPanda online e-books and reference material library.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studypanda.live/books",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "BOOK 🔥"
      },
      {
        "id": "bk-3-batch",
        "title": "BOOK 🌟",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "StudyBeePro",
          "Books"
        ],
        "subject": "Books & Study Materials",
        "description": "StudyBeePro digital book library and preparation guides.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://books.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "BOOK 🌟"
      },
      {
        "id": "bk-4-batch",
        "title": "BOOK ✨",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "Pinnacle",
          "Next Hope"
        ],
        "subject": "Books & Study Materials",
        "description": "Pinnacle book portal and study material collection by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/pinnacle/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "BOOK ✨"
      },
      {
        "id": "pinnacle-dreamstudy-books-batch",
        "title": "BOOK 💥",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "Pinnacle",
          "Dream Study"
        ],
        "subject": "Books & Study Materials",
        "description": "Pinnacle Dream Study book collection and preparation guides.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pinnacle-dreamstudy.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "BOOK 💥"
      },
      {
        "id": "learnjh-books-batch",
        "title": "Books ⚡",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Books",
          "LearnJH",
          "Library"
        ],
        "subject": "Books & Study Materials",
        "description": "Library and book resources by LearnJH.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnjh.vercel.app/books",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Books ⚡"
      },
      {
        "id": "pw-books-streamfiles-batch",
        "title": "Pw Books 💎",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Pw Books",
          "Streamfiles",
          "Books"
        ],
        "subject": "Books & Study Material",
        "description": "Pw Books streamfiles portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://books.streamfiles.eu.org/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Pw Books 💎"
      },
      {
        "id": "books-studybison-batch",
        "title": "StudyBison Books 📚",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "StudyBison",
          "E-Books"
        ],
        "subject": "Books & Study Materials",
        "description": "StudyBison digital textbook repository, module solutions, and e-library.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://books.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison Books 📚"
      },
      {
        "id": "bk-deltastudy-books-batch",
        "title": "Delta Study Books 📚",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Books & Study Materials",
        "targetYear": "2025-2026",
        "facultyNames": [
          "BOOK",
          "Delta Study",
          "Books"
        ],
        "subject": "Books & Study Materials",
        "description": "Delta Study digital textbook, formula booklet, and competitive exam books library.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://books.deltastudy.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Delta Study Books 📚"
      },
      {
        "id": "books-1-batch",
        "title": "Books",
        "logo": "https://st2.depositphotos.com/3573725/6541/v/450/depositphotos_65413355-stock-illustration-book-logo.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Books",
          "ASMultiverse"
        ],
        "subject": "Batches & Courses",
        "description": "Books by ASMultiverse",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://books.asmultiverse.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Books"
      },
      {
        "id": "pw-books-deltaverse-batch",
        "title": "PW Books DeltaVerse",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRer8oad1p28ArRprX_GU6yjym-n8P4gp4PPkXH2po9BQ&s=10",
        "targetExam": "Digital Books & Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "PW Books",
          "DeltaVerse",
          "E-Books"
        ],
        "subject": "Digital Books & Material",
        "description": "Physics Wallah digital book library, e-books, and study material on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://books.deltaverse.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW Books DeltaVerse"
      },
      {
        "id": "pwx-books-pages-batch",
        "title": "PWX Books Cloudflare",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRer8oad1p28ArRprX_GU6yjym-n8P4gp4PPkXH2po9BQ&s=10",
        "targetExam": "Digital Books & Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "PW Books",
          "PWX Books",
          "Cloudflare Pages"
        ],
        "subject": "Digital Books & Material",
        "description": "PWX Books Cloudflare Pages digital library for Physics Wallah textbooks and solutions.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pwxbooks.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PWX Books Cloudflare"
      },
      {
        "id": "pikachu-books-library-batch",
        "title": "Pikachu Books Library",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRer8oad1p28ArRprX_GU6yjym-n8P4gp4PPkXH2po9BQ&s=10",
        "targetExam": "Digital Books & Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "PW Books",
          "Pikachu Books",
          "Library"
        ],
        "subject": "Digital Books & Material",
        "description": "Pikachu Books interactive digital library reader for Physics Wallah books and notes.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pikachu-books.vercel.app/?view=library",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Pikachu Books Library"
      }
    ],
    "resources": [
      {
        "id": "book-res-1",
        "title": "PW BOOK Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for PW BOOK.",
        "url": "https://books.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "disha-online",
    "name": "Disha Online",
    "slug": "disha-online",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDlATTHTYcldlWgZjEeutIAAauF5pnt9Esxgx5FV3yCA&s",
    "tagline": "Disha Online Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "State & Matric Boards",
    "exams": [
      "Bihar Board Matric",
      "Class 10th",
      "Class 12th Inter Science"
    ],
    "brandColor": "#d97706",
    "badgeText": "Disha Online",
    "description": "Online coaching, live batches, and comprehensive study materials by Disha Online.",
    "officialWebsite": "https://disha-studyapkmod.vercel.app/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://disha-studyapkmod.vercel.app/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "disha-online-studyapkmod",
        "name": "Disha Online",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDlATTHTYcldlWgZjEeutIAAauF5pnt9Esxgx5FV3yCA&s",
        "portalUrl": "https://disha-studyapkmod.vercel.app/",
        "urlVerified": true,
        "description": "Official Disha Online study portal, batch courses, and exam preparation resources.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.9,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Bihar Board Matric",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "disha-online-studyapkmod-batch",
        "title": "Disha Online",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDlATTHTYcldlWgZjEeutIAAauF5pnt9Esxgx5FV3yCA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Disha Online",
          "Batches",
          "Study Material"
        ],
        "subject": "Batches & Courses",
        "description": "Official Disha Online study portal, batch courses, and exam preparation resources.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://disha-studyapkmod.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Disha Online"
      }
    ],
    "resources": [
      {
        "id": "disha-online-res-1",
        "title": "Disha Online Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Disha Online.",
        "url": "https://disha-studyapkmod.vercel.app/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "apna-college",
    "name": "Apna College",
    "slug": "apna-college",
    "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
    "tagline": "Apna College Learning Hub",
    "establishedYear": 2021,
    "category": "coding-tech",
    "categoryLabel": "Coding & Computer Science",
    "exams": [
      "DSA Java & C++",
      "Full Stack Web Dev",
      "Placement Prep"
    ],
    "brandColor": "#059669",
    "badgeText": "Apna College",
    "description": "Learn coding and excel in placement preparation.",
    "officialWebsite": "https://www.apnacollege.in/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.apnacollege.in/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 6,
    "portals": [
      {
        "id": "official-apna-college",
        "name": "Apna College OFFICIAL ✅",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "portalUrl": "https://www.apnacollege.in/",
        "urlVerified": true,
        "description": "Official Apna College platform for coding and placement preparation.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "ac-1",
        "name": "Apna College 🚀",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "portalUrl": "https://asmultiverse.in/details?id=apna-college-mod-apk",
        "urlVerified": true,
        "description": "Apna College coding and placement course access on AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "apna-college-mod",
        "name": "Apna College Mod Portal 🚀",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "portalUrl": "https://studyapkmod-apnacollege.vercel.app/#/",
        "urlVerified": true,
        "description": "Apna College coding batches, lectures and resources portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "apna-college-coursaa",
        "name": "Apna College Coursaa",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "portalUrl": "https://coursaa-main.vercel.app/",
        "urlVerified": true,
        "description": "Apna College coding batches, Alpha (DSA), Delta (Web Dev), Sigma, and Prime courses on Coursaa.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "apna-college-lrnt-ccwu",
        "name": "Apna College LRNT",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "portalUrl": "https://ac.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "Apna College coding tutorials, placement roadmaps, and programming batches on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "apna-college-gateway-classes",
        "name": "Apna College Gateway Classes",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "portalUrl": "https://gatewayclasses.vercel.app/",
        "urlVerified": true,
        "description": "Apna College programming batches, placement prep, and web development resources on Gateway Classes.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 6,
    "rating": 5,
    "reviewCount": 2220,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "DSA Java & C++",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-apna-college-batch",
        "title": "Apna College OFFICIAL ✅",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Apna College",
          "Official",
          "Coding"
        ],
        "subject": "Official Platform",
        "description": "Official Apna College platform for coding and placement preparation.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.apnacollege.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Apna College OFFICIAL ✅"
      },
      {
        "id": "ac-1-batch",
        "title": "Apna College 🚀",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "targetExam": "Coding & Placements",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Apna College",
          "Coding",
          "AS Multiverse"
        ],
        "subject": "Coding & Placements",
        "description": "Apna College coding and placement course access on AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.in/details?id=apna-college-mod-apk",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Apna College 🚀"
      },
      {
        "id": "apna-college-mod-batch",
        "title": "Apna College Mod Portal 🚀",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "targetExam": "Coding & Development",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Apna College",
          "Vercel",
          "Coding"
        ],
        "subject": "Coding & Development",
        "description": "Apna College coding batches, lectures and resources portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmod-apnacollege.vercel.app/#/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Apna College Mod Portal 🚀"
      },
      {
        "id": "apna-college-coursaa-batch",
        "title": "Apna College Coursaa",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "targetExam": "Coding & Placements",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Apna College",
          "Coursaa",
          "Coding"
        ],
        "subject": "Coding & Placements",
        "description": "Apna College coding batches, Alpha (DSA), Delta (Web Dev), Sigma, and Prime courses on Coursaa.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://coursaa-main.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Apna College Coursaa"
      },
      {
        "id": "apna-college-lrnt-ccwu-batch",
        "title": "Apna College LRNT",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "targetExam": "Coding & Placements",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Apna College",
          "LRNT",
          "Coding"
        ],
        "subject": "Coding & Placements",
        "description": "Apna College coding tutorials, placement roadmaps, and programming batches on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://ac.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Apna College LRNT"
      },
      {
        "id": "apna-college-gateway-classes-batch",
        "title": "Apna College Gateway Classes",
        "logo": "https://i.ibb.co/0y74Ks8X/x.jpg",
        "targetExam": "Coding & Placements",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Apna College",
          "Gateway Classes",
          "Coding"
        ],
        "subject": "Coding & Placements",
        "description": "Apna College programming batches, placement prep, and web development resources on Gateway Classes.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://gatewayclasses.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Apna College Gateway Classes"
      }
    ],
    "resources": [
      {
        "id": "apna-college-res-1",
        "title": "Apna College Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Apna College.",
        "url": "https://www.apnacollege.in/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "all-competition",
    "name": "All competition",
    "slug": "all-competition",
    "logo": "https://img.magnific.com/free-vector/corporate-leadership-bullseye-concept-background-company-success_1017-63147.jpg?semt=ais_hybrid&w=740&q=80",
    "tagline": "All Competition Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "SSC & All Competition",
    "exams": [
      "SSC CGL",
      "CHSL",
      "General Studies",
      "Maths"
    ],
    "brandColor": "#2563eb",
    "badgeText": "All Competition",
    "description": "Preparation resources and classes for all competitive exams.",
    "officialWebsite": "https://www.allcompetitionclasses.com/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.allcompetitionclasses.com/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "all-competition-classes",
        "name": "All Competition OFFICIAL ✅",
        "logo": "https://img.magnific.com/free-vector/corporate-leadership-bullseye-concept-background-company-success_1017-63147.jpg?semt=ais_hybrid&w=740&q=80",
        "portalUrl": "https://www.allcompetitionclasses.com/",
        "urlVerified": true,
        "description": "Classes and preparation materials for all competitive examinations.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.9,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SSC CGL",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "all-competition-classes-batch",
        "title": "All Competition OFFICIAL ✅",
        "logo": "https://img.magnific.com/free-vector/corporate-leadership-bullseye-concept-background-company-success_1017-63147.jpg?semt=ais_hybrid&w=740&q=80",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "All Competition",
          "Classes",
          "Preparation"
        ],
        "subject": "Batches & Courses",
        "description": "Classes and preparation materials for all competitive examinations.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.allcompetitionclasses.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "All Competition OFFICIAL ✅"
      }
    ],
    "resources": [
      {
        "id": "all-competition-res-1",
        "title": "All competition Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for All competition.",
        "url": "https://www.allcompetitionclasses.com/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "gyan-bindu",
    "name": "Gyan Bindu GS Academy",
    "slug": "gyan-bindu",
    "logo": "https://appx-wsb-gcp.akamai.net.in/subject/2022-06-13-0.6832003604181192.webp",
    "tagline": "Gyan Bindu Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Bihar Daroga & GS Academy",
    "exams": [
      "Bihar Police SI",
      "BPSC",
      "Bihar SSC",
      "Daroga PT/Mains"
    ],
    "brandColor": "#b91c1c",
    "badgeText": "Gyan Bindu",
    "description": "Premier GS Academy Patna for Bihar Daroga, BPSC, SSC, and state competitive exam free batches by Roshan Sir & Bittu Jha Sir.",
    "officialWebsite": "https://www.gyanbindugsacademy.com/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.gyanbindugsacademy.com/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "gyanbindu-official",
        "name": "Gyan Bindu GS Academy Official",
        "logo": "https://i.postimg.cc/k476K2Pj/gyanbindu.png",
        "portalUrl": "https://www.gyanbindugsacademy.com/",
        "urlVerified": true,
        "description": "Official Gyan Bindu GS Academy Patna portal for Bihar Daroga, BPSC, SSC, and state competitive exam batches by Roshan Anand Sir and Bittu Jha Sir.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "gyanbindu-batches-portal",
        "name": "Gyan Bindu GS Batches & Notes",
        "logo": "https://i.postimg.cc/k476K2Pj/gyanbindu.png",
        "portalUrl": "https://t.me/s/gyanbindugsacademy",
        "urlVerified": true,
        "description": "Gyan Bindu GS Academy free notes, lecture archives, Daroga test series and revision batch materials.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 4.9,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Bihar Police SI",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "gyanbindu-official-batch",
        "title": "Gyan Bindu GS Academy Official",
        "logo": "https://i.postimg.cc/k476K2Pj/gyanbindu.png",
        "targetExam": "BPSC & Daroga Batches",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Gyan Bindu",
          "Roshan Sir",
          "Bittu Jha Sir"
        ],
        "subject": "BPSC & Daroga Batches",
        "description": "Official Gyan Bindu GS Academy Patna portal for Bihar Daroga, BPSC, SSC, and state competitive exam batches by Roshan Anand Sir and Bittu Jha Sir.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.gyanbindugsacademy.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Gyan Bindu GS Academy Official"
      },
      {
        "id": "gyanbindu-batches-portal-batch",
        "title": "Gyan Bindu GS Batches & Notes",
        "logo": "https://i.postimg.cc/k476K2Pj/gyanbindu.png",
        "targetExam": "Batches & Notes",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Gyan Bindu",
          "Daroga",
          "SSC"
        ],
        "subject": "Batches & Notes",
        "description": "Gyan Bindu GS Academy free notes, lecture archives, Daroga test series and revision batch materials.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://t.me/s/gyanbindugsacademy",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Gyan Bindu GS Batches & Notes"
      }
    ],
    "resources": [
      {
        "id": "gyan-bindu-res-1",
        "title": "Gyan Bindu GS Academy Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Gyan Bindu GS Academy.",
        "url": "https://www.gyanbindugsacademy.com/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "eduteria",
    "name": "Eduteria",
    "slug": "eduteria",
    "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
    "tagline": "Eduteria Learning Hub",
    "establishedYear": 2021,
    "category": "upsc",
    "categoryLabel": "BPSC & State Civil Services",
    "exams": [
      "BPSC Prelims",
      "Bihar Daroga",
      "Current Affairs",
      "State PSC"
    ],
    "brandColor": "#047857",
    "badgeText": "Eduteria",
    "description": "Premier learning platform by Pravin Sir for BPSC, Bihar Daroga, SSC, and Current Affairs preparation.",
    "officialWebsite": "https://eduteria.live/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://eduteria.live/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 4,
    "portals": [
      {
        "id": "eduteria-official",
        "name": "Eduteria OFFICIAL ✅",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "portalUrl": "https://eduteria.live/",
        "urlVerified": true,
        "description": "Official Eduteria portal by Pravin Sir for BPSC, Bihar Daroga, and state civil services preparation.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "eduteria-vercel-portal",
        "name": "Eduteria Web 📚",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "portalUrl": "https://eduteriaa.vercel.app/",
        "urlVerified": true,
        "description": "Eduteria online study portal, current affairs compilations, and BPSC exam resources on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "eduteria-lrnt-ccwu",
        "name": "Eduteria LRNT",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "portalUrl": "https://et.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "Eduteria BPSC, Bihar Daroga, and Current Affairs study portal on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "eduteria-studyapkmod",
        "name": "Eduteria StudyAPKMod",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "portalUrl": "https://studyapkmod-eduteria.vercel.app/",
        "urlVerified": true,
        "description": "Eduteria BPSC, Bihar Daroga, and Current Affairs preparation batches and study portal on StudyAPKMod.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 4,
    "rating": 5,
    "reviewCount": 1980,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "BPSC Prelims",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "eduteria-official-batch",
        "title": "Eduteria OFFICIAL ✅",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Eduteria",
          "Official",
          "BPSC"
        ],
        "subject": "Official Platform",
        "description": "Official Eduteria portal by Pravin Sir for BPSC, Bihar Daroga, and state civil services preparation.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://eduteria.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Eduteria OFFICIAL ✅"
      },
      {
        "id": "eduteria-vercel-portal-batch",
        "title": "Eduteria Web 📚",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "targetExam": "Batches & Current Affairs",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Eduteria",
          "Vercel",
          "BPSC"
        ],
        "subject": "Batches & Current Affairs",
        "description": "Eduteria online study portal, current affairs compilations, and BPSC exam resources on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://eduteriaa.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Eduteria Web 📚"
      },
      {
        "id": "eduteria-lrnt-ccwu-batch",
        "title": "Eduteria LRNT",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "targetExam": "Government & State Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Eduteria",
          "LRNT",
          "BPSC"
        ],
        "subject": "Government & State Exams",
        "description": "Eduteria BPSC, Bihar Daroga, and Current Affairs study portal on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://et.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Eduteria LRNT"
      },
      {
        "id": "eduteria-studyapkmod-batch",
        "title": "Eduteria StudyAPKMod",
        "logo": "https://decicqog4ulhy.cloudfront.net/0/admin_v1/application_management/clientlogo/2897883166_Eduteria-logo.png",
        "targetExam": "Government & State Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Eduteria",
          "StudyAPKMod",
          "BPSC"
        ],
        "subject": "Government & State Exams",
        "description": "Eduteria BPSC, Bihar Daroga, and Current Affairs preparation batches and study portal on StudyAPKMod.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmod-eduteria.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Eduteria StudyAPKMod"
      }
    ],
    "resources": [
      {
        "id": "eduteria-res-1",
        "title": "Eduteria Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Eduteria.",
        "url": "https://eduteria.live/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "gs-version",
    "name": "Gs Version",
    "slug": "gs-version",
    "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
    "tagline": "Gs Version Learning Hub",
    "establishedYear": 2021,
    "category": "upsc",
    "categoryLabel": "General Studies & GS",
    "exams": [
      "UPSC GS",
      "State PSC",
      "History",
      "Polity & Geography"
    ],
    "brandColor": "#9333ea",
    "badgeText": "Gs Version",
    "description": "Focused general studies preparation and specialized study resources.",
    "officialWebsite": "https://gsvision.co.in/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://gsvision.co.in/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 4,
    "portals": [
      {
        "id": "official-gs-version",
        "name": "Gs Version OFFICIAL ✅",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "portalUrl": "https://gsvision.co.in/",
        "urlVerified": true,
        "description": "Official Gs Version focused general studies preparation.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "gsv-1",
        "name": "Gs Version 🚀",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "portalUrl": "https://gs.learntopper.in/",
        "urlVerified": true,
        "description": "Gs Version general studies portal and exam preparation hub.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "gsv-2",
        "name": "Gs Version 🔥",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "portalUrl": "https://nexthope.pages.dev/gsvision/",
        "urlVerified": true,
        "description": "GS Vision portal and study resources by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "gsvision-dreamstudy",
        "name": "GS Vision 🌟",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "portalUrl": "https://gsvision-dreamstudy.pages.dev/",
        "urlVerified": true,
        "description": "GS Vision Dream Study Portal for general studies lectures and notes.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 4,
    "rating": 5,
    "reviewCount": 1980,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "UPSC GS",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-gs-version-batch",
        "title": "Gs Version OFFICIAL ✅",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Gs Version",
          "Official",
          "General Studies"
        ],
        "subject": "Official Platform",
        "description": "Official Gs Version focused general studies preparation.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://gsvision.co.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Gs Version OFFICIAL ✅"
      },
      {
        "id": "gsv-1-batch",
        "title": "Gs Version 🚀",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "targetExam": "General Studies",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Gs Version",
          "Learntopper",
          "GS"
        ],
        "subject": "General Studies",
        "description": "Gs Version general studies portal and exam preparation hub.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://gs.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Gs Version 🚀"
      },
      {
        "id": "gsv-2-batch",
        "title": "Gs Version 🔥",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "targetExam": "General Studies",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Gs Version",
          "GS Vision",
          "Next Hope"
        ],
        "subject": "General Studies",
        "description": "GS Vision portal and study resources by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/gsvision/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Gs Version 🔥"
      },
      {
        "id": "gsvision-dreamstudy-batch",
        "title": "GS Vision 🌟",
        "logo": "https://i.postimg.cc/6Qt2YgcB/IMG-20260621-114809.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "GS Vision",
          "Dream Study",
          "General Studies"
        ],
        "subject": "Batches & Courses",
        "description": "GS Vision Dream Study Portal for general studies lectures and notes.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://gsvision-dreamstudy.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "GS Vision 🌟"
      }
    ],
    "resources": [
      {
        "id": "gs-version-res-1",
        "title": "Gs Version Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Gs Version.",
        "url": "https://gsvision.co.in/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "english-speaking",
    "name": "English Speaking",
    "slug": "english-speaking",
    "logo": "/images/english_speaking_logo.jpg",
    "tagline": "English Speaking Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Spoken English & Communication",
    "exams": [
      "Spoken English",
      "English Grammar",
      "Vocab Mastery"
    ],
    "brandColor": "#4f46e5",
    "badgeText": "English Speaking",
    "description": "Resources for English speaking and communication skills.",
    "officialWebsite": "https://rolexcoderz.com/AR/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://rolexcoderz.com/AR/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "english-speaking-ar",
        "name": "English Speaking AR",
        "logo": "/images/english_speaking_logo.jpg",
        "portalUrl": "https://rolexcoderz.com/AR/",
        "urlVerified": true,
        "description": "English speaking resources by Rolex Coderz.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.8,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Spoken English",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "english-speaking-ar-batch",
        "title": "English Speaking AR",
        "logo": "/images/english_speaking_logo.jpg",
        "targetExam": "Language & Communication",
        "targetYear": "2025-2026",
        "facultyNames": [
          "English Speaking",
          "Rolex Coderz"
        ],
        "subject": "Language & Communication",
        "description": "English speaking resources by Rolex Coderz.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rolexcoderz.com/AR/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "English Speaking AR"
      }
    ],
    "resources": [
      {
        "id": "english-speaking-res-1",
        "title": "English Speaking Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for English Speaking.",
        "url": "https://rolexcoderz.com/AR/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "iit-school",
    "name": "IIT School",
    "slug": "iit-school",
    "logo": "https://cdn-1.webcatalog.io/catalog/iit-school/iit-school-icon-filled-256.png?v=1717862732147",
    "tagline": "IIT School Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "IIT JEE Engineering Prep",
    "exams": [
      "JEE Main",
      "JEE Advanced",
      "Class 11 & 12 PCM"
    ],
    "brandColor": "#2563eb",
    "badgeText": "IIT School",
    "description": "Platform for IIT-JEE and competitive exam preparation.",
    "officialWebsite": "https://www.iitschool.in/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.iitschool.in/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 3,
    "portals": [
      {
        "id": "iit-school-1",
        "name": "IIT School OFFICIAL ✅",
        "logo": "https://cdn-1.webcatalog.io/catalog/iit-school/iit-school-icon-filled-256.png?v=1717862732147",
        "portalUrl": "https://www.iitschool.in/",
        "urlVerified": true,
        "description": "Official portal for IIT School courses.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "iit-school-2",
        "name": "IIT School 🚀",
        "logo": "https://cdn-1.webcatalog.io/catalog/iit-school/iit-school-icon-filled-256.png?v=1717862732147",
        "portalUrl": "https://others.streamfiles.eu.org",
        "urlVerified": true,
        "description": "Streamfiles portal for IIT School.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "iit-school-streamfiles",
        "name": "IIT School StreamFiles",
        "logo": "https://cdn-1.webcatalog.io/catalog/iit-school/iit-school-icon-filled-256.png?v=1717862732147",
        "portalUrl": "https://others.streamfiles.eu.org/iit/",
        "urlVerified": true,
        "description": "IIT School study batches, video lectures, and learning resources on StreamFiles.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 3,
    "rating": 4.9,
    "reviewCount": 1860,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "JEE Main",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "iit-school-1-batch",
        "title": "IIT School OFFICIAL ✅",
        "logo": "https://cdn-1.webcatalog.io/catalog/iit-school/iit-school-icon-filled-256.png?v=1717862732147",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "IIT School",
          "Official"
        ],
        "subject": "Batches & Courses",
        "description": "Official portal for IIT School courses.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.iitschool.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "IIT School OFFICIAL ✅"
      },
      {
        "id": "iit-school-2-batch",
        "title": "IIT School 🚀",
        "logo": "https://cdn-1.webcatalog.io/catalog/iit-school/iit-school-icon-filled-256.png?v=1717862732147",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "IIT School",
          "Streamfiles"
        ],
        "subject": "Batches & Courses",
        "description": "Streamfiles portal for IIT School.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://others.streamfiles.eu.org",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "IIT School 🚀"
      },
      {
        "id": "iit-school-streamfiles-batch",
        "title": "IIT School StreamFiles",
        "logo": "https://cdn-1.webcatalog.io/catalog/iit-school/iit-school-icon-filled-256.png?v=1717862732147",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "IIT School",
          "StreamFiles",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "IIT School study batches, video lectures, and learning resources on StreamFiles.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://others.streamfiles.eu.org/iit/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "IIT School StreamFiles"
      }
    ],
    "resources": [
      {
        "id": "iit-school-res-1",
        "title": "IIT School Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for IIT School.",
        "url": "https://www.iitschool.in/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "just-padhle",
    "name": "Just Padhle",
    "slug": "just-padhle",
    "logo": "https://i.ibb.co/fdZ4rc6F/10266.jpg",
    "tagline": "Just Padhle Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "CBSE & School Foundation",
    "exams": [
      "Class 9th",
      "Class 10th",
      "Board Crash Course"
    ],
    "brandColor": "#0891b2",
    "badgeText": "Just Padhle",
    "description": "Student-centric revision platform offering concise notes, quick revision series, and board exam tips.",
    "officialWebsite": "https://padhle.in/home/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://padhle.in/home/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 3,
    "portals": [
      {
        "id": "jp-2",
        "name": "Just Padhle OFFICIAL ✅",
        "logo": "https://i.ibb.co/fdZ4rc6F/10266.jpg",
        "portalUrl": "https://padhle.in/home/",
        "urlVerified": true,
        "description": "Official portal for Just Padhle batches, notes, and revision materials.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "jp-1",
        "name": "Just Padhle 🚀",
        "logo": "https://i.ibb.co/fdZ4rc6F/10266.jpg",
        "portalUrl": "https://deltastudy.fun/padhle",
        "urlVerified": true,
        "description": "Just Padhle batch access and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "official-just-padhle",
        "name": "Just Padhle 🔥",
        "logo": "https://i.ibb.co/fdZ4rc6F/10266.jpg",
        "portalUrl": "https://padhle.in",
        "urlVerified": true,
        "description": "Official Just Padhle student-centric revision platform.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 3,
    "rating": 4.9,
    "reviewCount": 1860,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Class 9th",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "jp-2-batch",
        "title": "Just Padhle OFFICIAL ✅",
        "logo": "https://i.ibb.co/fdZ4rc6F/10266.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Just Padhle",
          "Official",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Official portal for Just Padhle batches, notes, and revision materials.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://padhle.in/home/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Just Padhle OFFICIAL ✅"
      },
      {
        "id": "jp-1-batch",
        "title": "Just Padhle 🚀",
        "logo": "https://i.ibb.co/fdZ4rc6F/10266.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Just Padhle",
          "Delta Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Just Padhle batch access and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/padhle",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Just Padhle 🚀"
      },
      {
        "id": "official-just-padhle-batch",
        "title": "Just Padhle 🔥",
        "logo": "https://i.ibb.co/fdZ4rc6F/10266.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Just Padhle",
          "Official",
          "Revision"
        ],
        "subject": "Official Platform",
        "description": "Official Just Padhle student-centric revision platform.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://padhle.in",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Just Padhle 🔥"
      }
    ],
    "resources": [
      {
        "id": "just-padhle-res-1",
        "title": "Just Padhle Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Just Padhle.",
        "url": "https://padhle.in/home/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "education-baba",
    "name": "Education Baba",
    "slug": "education-baba",
    "logo": "https://i.ibb.co/9kSMLvKQ/x.jpg",
    "tagline": "Education Baba Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "State Board Preparation",
    "exams": [
      "Class 12th Arts",
      "Science",
      "Commerce",
      "Board Topper"
    ],
    "brandColor": "#b45309",
    "badgeText": "Education Baba",
    "description": "Top platform for state board exam preparation.",
    "officialWebsite": "https://educationbaba.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://educationbaba.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "official-education-baba",
        "name": "Education Baba OFFICIAL ✅",
        "logo": "https://i.ibb.co/9kSMLvKQ/x.jpg",
        "portalUrl": "https://educationbaba.com",
        "urlVerified": true,
        "description": "Official Education Baba platform for state board exam preparation.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "eb-1",
        "name": "Education Baba 🚀",
        "logo": "https://i.ibb.co/9kSMLvKQ/x.jpg",
        "portalUrl": "https://asmultiverse.in/details?id=education-baba",
        "urlVerified": true,
        "description": "Education Baba state board preparation material on AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 5,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Class 12th Arts",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-education-baba-batch",
        "title": "Education Baba OFFICIAL ✅",
        "logo": "https://i.ibb.co/9kSMLvKQ/x.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Education Baba",
          "Official",
          "State Boards"
        ],
        "subject": "Official Platform",
        "description": "Official Education Baba platform for state board exam preparation.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://educationbaba.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Education Baba OFFICIAL ✅"
      },
      {
        "id": "eb-1-batch",
        "title": "Education Baba 🚀",
        "logo": "https://i.ibb.co/9kSMLvKQ/x.jpg",
        "targetExam": "State Board Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Education Baba",
          "Board Prep",
          "AS Multiverse"
        ],
        "subject": "State Board Prep",
        "description": "Education Baba state board preparation material on AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.in/details?id=education-baba",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Education Baba 🚀"
      }
    ],
    "resources": [
      {
        "id": "education-baba-res-1",
        "title": "Education Baba Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Education Baba.",
        "url": "https://educationbaba.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "futurekul",
    "name": "Futurekul",
    "slug": "futurekul",
    "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
    "tagline": "Futurekul Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Government Exam Preparation",
    "exams": [
      "General Science",
      "SSC CGL",
      "Railway",
      "State Exams"
    ],
    "brandColor": "#c026d3",
    "badgeText": "Futurekul",
    "description": "Modern, dynamic learning platform to shape the future of dedicated students.",
    "officialWebsite": "https://futurekul.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://futurekul.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 9,
    "portals": [
      {
        "id": "official-futurekul",
        "name": "Futurekul OFFICIAL ✅",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://futurekul.com",
        "urlVerified": true,
        "description": "Official Futurekul modern dynamic learning platform.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "fk-1",
        "name": "Futurekul 🚀",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://fk.learntopper.in/",
        "urlVerified": true,
        "description": "Futurekul learning portal and batch navigation by Learntopper.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "fk-2",
        "name": "Futurekul 🔥",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://studybeepro.site/futurekul/",
        "urlVerified": true,
        "description": "Futurekul study portal and resource gateway by Study Bee Pro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "fk-3",
        "name": "Futurekul 🌟",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://nexthope.pages.dev/futurekul/",
        "urlVerified": true,
        "description": "Futurekul batch portal and online lectures by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "fk-dreamstudy",
        "name": "Futurekul ✨",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://futurekul-dreamstudy.pages.dev/",
        "urlVerified": true,
        "description": "Futurekul Dream Study interactive learning portal and batch access.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "fl-studybison",
        "name": "StudyBison Futurekul 🚀",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://fl.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison Futurekul Dream Study courses, test series, and batch access.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "futurekul-sumit-qzz",
        "name": "Futurekul Sumit 🚀",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://futurekul.sumit.qzz.io/",
        "urlVerified": true,
        "description": "Futurekul batches and exam preparation portal by Sumit.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "futurekul-studyapkmod",
        "name": "Futurekul Mod Portal 🌟",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://studyapkmod-futurekull.vercel.app/",
        "urlVerified": true,
        "description": "Futurekul study materials and batches portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "futurekul-lrnt-ccwu",
        "name": "Futurekul LRNT",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "portalUrl": "https://fk.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "Futurekul online courses, study materials, and interactive batches on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 9,
    "rating": 5,
    "reviewCount": 2580,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "General Science",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-futurekul-batch",
        "title": "Futurekul OFFICIAL ✅",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "Official",
          "Learning"
        ],
        "subject": "Official Platform",
        "description": "Official Futurekul modern dynamic learning platform.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://futurekul.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul OFFICIAL ✅"
      },
      {
        "id": "fk-1-batch",
        "title": "Futurekul 🚀",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "Learntopper",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Futurekul learning portal and batch navigation by Learntopper.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://fk.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul 🚀"
      },
      {
        "id": "fk-2-batch",
        "title": "Futurekul 🔥",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "Study Bee Pro",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Futurekul study portal and resource gateway by Study Bee Pro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studybeepro.site/futurekul/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul 🔥"
      },
      {
        "id": "fk-3-batch",
        "title": "Futurekul 🌟",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "Next Hope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Futurekul batch portal and online lectures by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/futurekul/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul 🌟"
      },
      {
        "id": "fk-dreamstudy-batch",
        "title": "Futurekul ✨",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "Dream Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Futurekul Dream Study interactive learning portal and batch access.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://futurekul-dreamstudy.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul ✨"
      },
      {
        "id": "fl-studybison-batch",
        "title": "StudyBison Futurekul 🚀",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "StudyBison",
          "Dream Study"
        ],
        "subject": "Batches & Courses",
        "description": "StudyBison Futurekul Dream Study courses, test series, and batch access.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://fl.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison Futurekul 🚀"
      },
      {
        "id": "futurekul-sumit-qzz-batch",
        "title": "Futurekul Sumit 🚀",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "Sumit",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Futurekul batches and exam preparation portal by Sumit.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://futurekul.sumit.qzz.io/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul Sumit 🚀"
      },
      {
        "id": "futurekul-studyapkmod-batch",
        "title": "Futurekul Mod Portal 🌟",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "Vercel",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Futurekul study materials and batches portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmod-futurekull.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul Mod Portal 🌟"
      },
      {
        "id": "futurekul-lrnt-ccwu-batch",
        "title": "Futurekul LRNT",
        "logo": "https://i.postimg.cc/z3YX3H2x/images-(1).jpg",
        "targetExam": "Modern Learning",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Futurekul",
          "LRNT",
          "Batches"
        ],
        "subject": "Modern Learning",
        "description": "Futurekul online courses, study materials, and interactive batches on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://fk.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Futurekul LRNT"
      }
    ],
    "resources": [
      {
        "id": "futurekul-res-1",
        "title": "Futurekul Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Futurekul.",
        "url": "https://futurekul.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "md-classes",
    "name": "MD classes",
    "slug": "md-classes",
    "logo": "https://i.postimg.cc/bwbmK3zB/download-(2).jpg",
    "tagline": "MD Classes Learning Hub",
    "establishedYear": 2021,
    "category": "railway",
    "categoryLabel": "Railway & Technical Exams",
    "exams": [
      "Railway ALP",
      "RRB NTPC",
      "Group D",
      "UP Police"
    ],
    "brandColor": "#d97706",
    "badgeText": "MD Classes",
    "description": "Quality education and resources for comprehensive exam preparation.",
    "officialWebsite": "https://mdclasses.classx.co.in/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://mdclasses.classx.co.in/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "official-md-classes",
        "name": "MD classes OFFICIAL ✅",
        "logo": "https://i.postimg.cc/bwbmK3zB/download-(2).jpg",
        "portalUrl": "https://mdclasses.classx.co.in/",
        "urlVerified": true,
        "description": "Official MD classes education and resources portal.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mdc-1",
        "name": "MD Classes 🚀",
        "logo": "https://i.postimg.cc/bwbmK3zB/download-(2).jpg",
        "portalUrl": "https://mdclassesx.vercel.app/",
        "urlVerified": true,
        "description": "MD Classes online lecture portal and study resources on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 5,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Railway ALP",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-md-classes-batch",
        "title": "MD classes OFFICIAL ✅",
        "logo": "https://i.postimg.cc/bwbmK3zB/download-(2).jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MD classes",
          "Official",
          "Preparation"
        ],
        "subject": "Official Platform",
        "description": "Official MD classes education and resources portal.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://mdclasses.classx.co.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MD classes OFFICIAL ✅"
      },
      {
        "id": "mdc-1-batch",
        "title": "MD Classes 🚀",
        "logo": "https://i.postimg.cc/bwbmK3zB/download-(2).jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MD Classes",
          "Vercel",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MD Classes online lecture portal and study resources on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mdclassesx.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MD Classes 🚀"
      }
    ],
    "resources": [
      {
        "id": "md-classes-res-1",
        "title": "MD classes Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for MD classes.",
        "url": "https://mdclasses.classx.co.in/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "munil-sir",
    "name": "Munil Sir",
    "slug": "munil-sir",
    "logo": "https://nocache-appxdb.classx.co.in/subject/2024-08-09-0.845544467533613.png",
    "tagline": "Munil Sir Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "Mathematics & JEE Prep",
    "exams": [
      "JEE Maths",
      "Class 12 Boards",
      "Calculus & Algebra"
    ],
    "brandColor": "#7c3aed",
    "badgeText": "Munil Sir",
    "description": "Dedicated educational channel and learning platform by Munil Sir for mathematics, science, and exam guidance.",
    "officialWebsite": "https://study.munilsir.com/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://study.munilsir.com/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "official-munil-sir",
        "name": "Munil Sir OFFICIAL ✅",
        "logo": "https://nocache-appxdb.classx.co.in/subject/2024-08-09-0.845544467533613.png",
        "portalUrl": "https://study.munilsir.com/",
        "urlVerified": true,
        "description": "Official platform by Munil Sir for mathematics and science.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "ms-1",
        "name": "Munil Sir 🚀",
        "logo": "https://nocache-appxdb.classx.co.in/subject/2024-08-09-0.845544467533613.png",
        "portalUrl": "https://deltastudy.fun/munilsir",
        "urlVerified": true,
        "description": "Munil Sir batch access and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 5,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "JEE Maths",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-munil-sir-batch",
        "title": "Munil Sir OFFICIAL ✅",
        "logo": "https://nocache-appxdb.classx.co.in/subject/2024-08-09-0.845544467533613.png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Munil Sir",
          "Official",
          "Maths"
        ],
        "subject": "Official Platform",
        "description": "Official platform by Munil Sir for mathematics and science.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://study.munilsir.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Munil Sir OFFICIAL ✅"
      },
      {
        "id": "ms-1-batch",
        "title": "Munil Sir 🚀",
        "logo": "https://nocache-appxdb.classx.co.in/subject/2024-08-09-0.845544467533613.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Munil Sir",
          "Delta Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Munil Sir batch access and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/munilsir",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Munil Sir 🚀"
      }
    ],
    "resources": [
      {
        "id": "munil-sir-res-1",
        "title": "Munil Sir Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Munil Sir.",
        "url": "https://study.munilsir.com/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "motion",
    "name": "Motion",
    "slug": "motion",
    "logo": "https://play-lh.googleusercontent.com/GEucuhu6bsxw8ogG1PJbIPnEMfX45CbmRy8CKtPRGdlV_IZedvRDgbVXUOpotEUFq6A",
    "tagline": "Motion Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "Motion Kota JEE & NEET",
    "exams": [
      "JEE Main",
      "JEE Advanced",
      "NEET UG",
      "Kota Coaching"
    ],
    "brandColor": "#2563eb",
    "badgeText": "Motion",
    "description": "Premier coaching institute for JEE Main, JEE Advanced, NEET, and Olympiads preparation.",
    "officialWebsite": "https://others.streamfiles.eu.org/motion/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://others.streamfiles.eu.org/motion/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "motion-streamfiles",
        "name": "Motion",
        "logo": "https://play-lh.googleusercontent.com/GEucuhu6bsxw8ogG1PJbIPnEMfX45CbmRy8CKtPRGdlV_IZedvRDgbVXUOpotEUFq6A",
        "portalUrl": "https://others.streamfiles.eu.org/motion/",
        "urlVerified": true,
        "description": "Official Motion Learning coaching batches, lectures, and test prep portal on StreamFiles.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.9,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "JEE Main",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "motion-streamfiles-batch",
        "title": "Motion",
        "logo": "https://play-lh.googleusercontent.com/GEucuhu6bsxw8ogG1PJbIPnEMfX45CbmRy8CKtPRGdlV_IZedvRDgbVXUOpotEUFq6A",
        "targetExam": "JEE & NEET Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Motion",
          "Motion Education",
          "Kota Coaching"
        ],
        "subject": "JEE & NEET Coaching",
        "description": "Official Motion Learning coaching batches, lectures, and test prep portal on StreamFiles.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://others.streamfiles.eu.org/motion/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Motion"
      }
    ],
    "resources": [
      {
        "id": "motion-res-1",
        "title": "Motion Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Motion.",
        "url": "https://others.streamfiles.eu.org/motion/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "kd-live",
    "name": "KD Live",
    "slug": "kd-live",
    "logo": "https://i.postimg.cc/Pqg46Zgt/image-search-1790505464474.jpg",
    "tagline": "KD Live Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "KD Live SSC & English",
    "exams": [
      "SSC CGL",
      "English by Neetu Singh",
      "CPO",
      "CHSL"
    ],
    "brandColor": "#e11d48",
    "badgeText": "KD Live",
    "description": "Premier preparation portal, live batches, video lectures, and study resources for SSC, Banking, Teaching, and competitive exams by KD Live.",
    "officialWebsite": "https://kd-live.netlify.app/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://kd-live.netlify.app/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "kd-live",
        "name": "KD Live",
        "logo": "https://i.postimg.cc/Pqg46Zgt/image-search-1790505464474.jpg",
        "portalUrl": "https://kd-live.netlify.app/",
        "urlVerified": true,
        "description": "Official portal for KD Live study batches, courses, video lectures, and competitive exam preparation resources.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.9,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SSC CGL",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "kd-live-batch",
        "title": "KD Live",
        "logo": "https://i.postimg.cc/Pqg46Zgt/image-search-1790505464474.jpg",
        "targetExam": "SSC & Government Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KD Live",
          "SSC",
          "Banking"
        ],
        "subject": "SSC & Government Exams",
        "description": "Official portal for KD Live study batches, courses, video lectures, and competitive exam preparation resources.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://kd-live.netlify.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "KD Live"
      }
    ],
    "resources": [
      {
        "id": "kd-live-res-1",
        "title": "KD Live Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for KD Live.",
        "url": "https://kd-live.netlify.app/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "master-sahab",
    "name": "Master Sahab",
    "slug": "master-sahab",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
    "tagline": "Master Sahab Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "Academic Guidance & Foundation",
    "exams": [
      "Board Exams",
      "Foundation Classes",
      "School Prep"
    ],
    "brandColor": "#65a30d",
    "badgeText": "Master Sahab",
    "description": "Interactive educational portal and learning resource for student guidance, exam tips, and subject mastery.",
    "officialWebsite": "https://mastersahab.in",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://mastersahab.in",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 7,
    "portals": [
      {
        "id": "official-master-sahab",
        "name": "Master Sahab OFFICIAL ✅",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "portalUrl": "https://mastersahab.in",
        "urlVerified": true,
        "description": "Official Master Sahab educational portal and learning resource.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "msahab-1",
        "name": "Master Sahab 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "portalUrl": "https://deltastudy.fun/mastersahab",
        "urlVerified": true,
        "description": "Master Sahab study batches and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "msahab-2",
        "name": "Master Sahab 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "portalUrl": "https://mastersahab.studybeepro.site/",
        "urlVerified": true,
        "description": "Master Sahab learning portal and resources by Study Bee Pro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "msahab-3",
        "name": "Master Sahab 🌟",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "portalUrl": "https://nexthope.pages.dev/mastersahab/",
        "urlVerified": true,
        "description": "Master Sahab batch portal and courses by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "ms-studybison",
        "name": "StudyBison Master Sahab 🎓",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "portalUrl": "https://ms.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison Master Sahab interactive educational portal and exam batches.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "master-sahab-1",
        "name": "Mastar Sahab",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "portalUrl": "https://mastersahab.studypanda.live/",
        "urlVerified": true,
        "description": "Mastar Sahab by StudyPanda",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "master-sahab-nextmate",
        "name": "Master Sahab NextMate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "portalUrl": "https://master-sahab.nextmate.site/",
        "urlVerified": true,
        "description": "Master Sahab student guidance, lecture series, and batch access on NextMate.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 7,
    "rating": 5,
    "reviewCount": 2340,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Board Exams",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-master-sahab-batch",
        "title": "Master Sahab OFFICIAL ✅",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Master Sahab",
          "Official",
          "Guidance"
        ],
        "subject": "Official Platform",
        "description": "Official Master Sahab educational portal and learning resource.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://mastersahab.in",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Master Sahab OFFICIAL ✅"
      },
      {
        "id": "msahab-1-batch",
        "title": "Master Sahab 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Master Sahab",
          "Delta Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Master Sahab study batches and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/mastersahab",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Master Sahab 🚀"
      },
      {
        "id": "msahab-2-batch",
        "title": "Master Sahab 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Master Sahab",
          "Study Bee Pro",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Master Sahab learning portal and resources by Study Bee Pro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mastersahab.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Master Sahab 🔥"
      },
      {
        "id": "msahab-3-batch",
        "title": "Master Sahab 🌟",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Master Sahab",
          "Next Hope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Master Sahab batch portal and courses by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/mastersahab/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Master Sahab 🌟"
      },
      {
        "id": "ms-studybison-batch",
        "title": "StudyBison Master Sahab 🎓",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Master Sahab",
          "StudyBison",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "StudyBison Master Sahab interactive educational portal and exam batches.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://ms.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison Master Sahab 🎓"
      },
      {
        "id": "master-sahab-1-batch",
        "title": "Mastar Sahab",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Mastar Sahab",
          "StudyPanda"
        ],
        "subject": "Batches & Courses",
        "description": "Mastar Sahab by StudyPanda",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://mastersahab.studypanda.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Mastar Sahab"
      },
      {
        "id": "master-sahab-nextmate-batch",
        "title": "Master Sahab NextMate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnIU9FCUpuoM2huY5k-ggVgZIB28M4VKpaS-1NOCixoA&s",
        "targetExam": "Student Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Master Sahab",
          "NextMate",
          "Study Portal"
        ],
        "subject": "Student Guidance",
        "description": "Master Sahab student guidance, lecture series, and batch access on NextMate.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://master-sahab.nextmate.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Master Sahab NextMate"
      }
    ],
    "resources": [
      {
        "id": "master-sahab-res-1",
        "title": "Master Sahab Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Master Sahab.",
        "url": "https://mastersahab.in",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "missionjeet",
    "name": "MissionJEET",
    "slug": "missionjeet",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
    "tagline": "MissionJEET Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "Engineering & Medical Hub",
    "exams": [
      "JEE Main",
      "JEE Advanced",
      "NEET UG",
      "Dropper Batches"
    ],
    "brandColor": "#dc2626",
    "badgeText": "MissionJEET",
    "description": "Targeted learning initiative and coaching portal for competitive engineering entrance examinations.",
    "officialWebsite": "https://missionjeet.in/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://missionjeet.in/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 24,
    "portals": [
      {
        "id": "mj-1",
        "name": "MissionJEET OFFICIAL ✅",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://missionjeet.in/",
        "urlVerified": true,
        "description": "Official MissionJEET portal and learning resources.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-mta",
        "name": "MissionJEET 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mj.mtaiirus.site/",
        "urlVerified": true,
        "description": "MissionJEET batch portal and learning gateway on MTA.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-2",
        "name": "MissionJEET 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mission-jeet.primestudy.live/missionjeet/",
        "urlVerified": true,
        "description": "MissionJEET portal and resources by Prime Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-3",
        "name": "MissionJEET 🌟",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://studyparcham.in/mj/",
        "urlVerified": true,
        "description": "MissionJEET learning gateway by Study Parcham.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-4",
        "name": "MissionJEET ✨",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://deltastudy.fun/missionjeet",
        "urlVerified": true,
        "description": "MissionJEET batch access and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-5",
        "name": "MissionJEET 💥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://studypanda.live/missionjeet",
        "urlVerified": true,
        "description": "MissionJEET courses and study material by Study Panda.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-6",
        "name": "MissionJEET ⚡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://studybeepro.site/mj/",
        "urlVerified": true,
        "description": "MissionJEET learning gateway by Study Bee Pro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-7",
        "name": "MissionJEET 💎",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://nexthope.pages.dev/mj/",
        "urlVerified": true,
        "description": "Next hope MissionJEET portal and learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-8",
        "name": "MissionJEET 🏆",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://missionjeet.modgalaxy.in/",
        "urlVerified": true,
        "description": "MissionJEET portal and learning resources by ModGalaxy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-9",
        "name": "MissionJEET 🎯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mj.learntopper.in/",
        "urlVerified": true,
        "description": "MissionJEET portal and learning resources by Learntopper.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mission-jeet-next",
        "name": "MissionJEET 📚",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://next-jeet.pages.dev/mission-jeet",
        "urlVerified": true,
        "description": "Mission JEET Next learning initiative for competitive entrance exam preparation.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "learnjh-missionjeet",
        "name": "MissionJEET 💡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://learnjh.vercel.app/missionjeet",
        "urlVerified": true,
        "description": "MissionJEET resources and batches by LearnJH.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-streamfiles",
        "name": "Mission Jeet ⭐",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mj.streamfiles.eu.org/",
        "urlVerified": true,
        "description": "Mission Jeet streamfiles portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-studybison",
        "name": "StudyBison MissionJEET 🏆",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mj.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison MissionJEET engineering entrance coaching portal and batch player.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edufreek-mj",
        "name": "EduFreek MissionJEET ⚡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://edufreek.ct.ws/generate.php?platform=mj",
        "urlVerified": true,
        "description": "EduFreek MissionJEET batch link generator and lecture access platform.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "missionjeet-studyspark",
        "name": "MissionJEET StudySpark",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://jeet.studyspark.pro/",
        "urlVerified": true,
        "description": "MissionJEET resources by StudySpark.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "missionjeet-learnxpw",
        "name": "MissionJEET LearnX Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://www.learnxpw.site/study/missionjeet",
        "urlVerified": true,
        "description": "MissionJEET batch courses and preparation material on LearnX.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mj-learnex",
        "name": "MissionJEET LearnEx 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://learnex.vercel.app/MJ",
        "urlVerified": true,
        "description": "MissionJEET engineering exam preparation portal on LearnEx Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mission-jeet-1",
        "name": "Mission Jeet",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://platform.studyparcham.in/missionjeet",
        "urlVerified": true,
        "description": "Mission Jeet by StudyParcham",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "missionjeet-studyhulk-vercel",
        "name": "MissionJEET StudyHulk",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mjstudyhulk.vercel.app/",
        "urlVerified": true,
        "description": "MissionJEET engineering entrance preparation portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "missionjeet-keygenerate",
        "name": "MissionJEET Key Generate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mj.testuk.org/keygenerate",
        "urlVerified": true,
        "description": "MissionJEET key generation and access gateway for engineering coaching.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "missionjeet-nextmate",
        "name": "MissionJEET NextMate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://missionjeet.nextmate.site/",
        "urlVerified": true,
        "description": "MissionJEET engineering batches and live lecture platform on NextMate.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "missionjeet-lrnt-ccwu",
        "name": "MissionJEET LRNT",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://mj.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "MissionJEET digital learning batches and study resources on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "missionjeet-deltaverse",
        "name": "MissionJEET DeltaVerse",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "portalUrl": "https://deltaverse.site/missionjeet",
        "urlVerified": true,
        "description": "MissionJEET engineering batches and competitive study portal on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 24,
    "rating": 4.8,
    "reviewCount": 4380,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "JEE Main",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "mj-1-batch",
        "title": "MissionJEET OFFICIAL ✅",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Official",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Official MissionJEET portal and learning resources.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://missionjeet.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET OFFICIAL ✅"
      },
      {
        "id": "mj-mta-batch",
        "title": "MissionJEET 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "MTA",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET batch portal and learning gateway on MTA.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mj.mtaiirus.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 🚀"
      },
      {
        "id": "mj-2-batch",
        "title": "MissionJEET 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Prime Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET portal and resources by Prime Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mission-jeet.primestudy.live/missionjeet/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 🔥"
      },
      {
        "id": "mj-3-batch",
        "title": "MissionJEET 🌟",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Study Parcham",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET learning gateway by Study Parcham.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyparcham.in/mj/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 🌟"
      },
      {
        "id": "mj-4-batch",
        "title": "MissionJEET ✨",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Delta Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET batch access and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/missionjeet",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET ✨"
      },
      {
        "id": "mj-5-batch",
        "title": "MissionJEET 💥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Study Panda",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET courses and study material by Study Panda.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studypanda.live/missionjeet",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 💥"
      },
      {
        "id": "mj-6-batch",
        "title": "MissionJEET ⚡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Study Bee Pro",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET learning gateway by Study Bee Pro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studybeepro.site/mj/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET ⚡"
      },
      {
        "id": "mj-7-batch",
        "title": "MissionJEET 💎",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Next Hope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Next hope MissionJEET portal and learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/mj/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 💎"
      },
      {
        "id": "mj-8-batch",
        "title": "MissionJEET 🏆",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "ModGalaxy",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET portal and learning resources by ModGalaxy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://missionjeet.modgalaxy.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 🏆"
      },
      {
        "id": "mj-9-batch",
        "title": "MissionJEET 🎯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Learntopper",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET portal and learning resources by Learntopper.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mj.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 🎯"
      },
      {
        "id": "mission-jeet-next-batch",
        "title": "MissionJEET 📚",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Next Jeet",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Mission JEET Next learning initiative for competitive entrance exam preparation.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://next-jeet.pages.dev/mission-jeet",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 📚"
      },
      {
        "id": "learnjh-missionjeet-batch",
        "title": "MissionJEET 💡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "LearnJH"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET resources and batches by LearnJH.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnjh.vercel.app/missionjeet",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET 💡"
      },
      {
        "id": "mj-streamfiles-batch",
        "title": "Mission Jeet ⭐",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Mission Jeet",
          "Streamfiles"
        ],
        "subject": "Batches & Courses",
        "description": "Mission Jeet streamfiles portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mj.streamfiles.eu.org/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Mission Jeet ⭐"
      },
      {
        "id": "mj-studybison-batch",
        "title": "StudyBison MissionJEET 🏆",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "StudyBison",
          "JEE Main"
        ],
        "subject": "Batches & Courses",
        "description": "StudyBison MissionJEET engineering entrance coaching portal and batch player.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mj.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison MissionJEET 🏆"
      },
      {
        "id": "edufreek-mj-batch",
        "title": "EduFreek MissionJEET ⚡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "EduFreek",
          "Generator"
        ],
        "subject": "Batches & Courses",
        "description": "EduFreek MissionJEET batch link generator and lecture access platform.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edufreek.ct.ws/generate.php?platform=mj",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "EduFreek MissionJEET ⚡"
      },
      {
        "id": "missionjeet-studyspark-batch",
        "title": "MissionJEET StudySpark",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "StudySpark"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET resources by StudySpark.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://jeet.studyspark.pro/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET StudySpark"
      },
      {
        "id": "missionjeet-learnxpw-batch",
        "title": "MissionJEET LearnX Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "LearnX",
          "JEE Prep"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET batch courses and preparation material on LearnX.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.learnxpw.site/study/missionjeet",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET LearnX Portal"
      },
      {
        "id": "mj-learnex-batch",
        "title": "MissionJEET LearnEx 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "LearnEx",
          "Vercel"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET engineering exam preparation portal on LearnEx Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnex.vercel.app/MJ",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET LearnEx 🚀"
      },
      {
        "id": "mission-jeet-1-batch",
        "title": "Mission Jeet",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Mission Jeet",
          "StudyParcham"
        ],
        "subject": "Batches & Courses",
        "description": "Mission Jeet by StudyParcham",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://platform.studyparcham.in/missionjeet",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Mission Jeet"
      },
      {
        "id": "missionjeet-studyhulk-vercel-batch",
        "title": "MissionJEET StudyHulk",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "StudyHulk",
          "JEE"
        ],
        "subject": "Batches & Courses",
        "description": "MissionJEET engineering entrance preparation portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mjstudyhulk.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET StudyHulk"
      },
      {
        "id": "missionjeet-keygenerate-batch",
        "title": "MissionJEET Key Generate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Engineering Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "Key Generate",
          "Batches"
        ],
        "subject": "Engineering Coaching",
        "description": "MissionJEET key generation and access gateway for engineering coaching.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mj.testuk.org/keygenerate",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET Key Generate"
      },
      {
        "id": "missionjeet-nextmate-batch",
        "title": "MissionJEET NextMate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Engineering Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "NextMate",
          "Batches"
        ],
        "subject": "Engineering Coaching",
        "description": "MissionJEET engineering batches and live lecture platform on NextMate.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://missionjeet.nextmate.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET NextMate"
      },
      {
        "id": "missionjeet-lrnt-ccwu-batch",
        "title": "MissionJEET LRNT",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Engineering Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "LRNT",
          "Study Portal"
        ],
        "subject": "Engineering Coaching",
        "description": "MissionJEET digital learning batches and study resources on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mj.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET LRNT"
      },
      {
        "id": "missionjeet-deltaverse-batch",
        "title": "MissionJEET DeltaVerse",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXhmAX6UC18CYhwU2a6f7gn9E5WE0g4hzSQK2zyH_nVA&s",
        "targetExam": "Engineering Coaching",
        "targetYear": "2025-2026",
        "facultyNames": [
          "MissionJEET",
          "DeltaVerse",
          "Batches"
        ],
        "subject": "Engineering Coaching",
        "description": "MissionJEET engineering batches and competitive study portal on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltaverse.site/missionjeet",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "MissionJEET DeltaVerse"
      }
    ],
    "resources": [
      {
        "id": "missionjeet-res-1",
        "title": "MissionJEET Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for MissionJEET.",
        "url": "https://missionjeet.in/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "next-toppers",
    "name": "Next Toppers",
    "slug": "next-toppers",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
    "tagline": "Next Toppers Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "CBSE & State Boards",
    "exams": [
      "Class 10th Boards",
      "Class 12th Boards",
      "All Subjects"
    ],
    "brandColor": "#059669",
    "badgeText": "Next Toppers",
    "description": "Exam preparation and academic guidance portal helping students excel in school and board examinations.",
    "officialWebsite": "https://nexttoppers.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://nexttoppers.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 43,
    "portals": [
      {
        "id": "official-next-toppers",
        "name": "Next Toppers OFFICIAL ✅",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttoppers.com",
        "urlVerified": true,
        "description": "Official Next Toppers portal for exam preparation and academic guidance.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-1",
        "name": "Next Toppers 🚀",
        "logo": "https://i.ibb.co/v4k8LdYN/nexthope.png",
        "portalUrl": "https://nexthope.pages.dev/nt/",
        "urlVerified": true,
        "description": "Next Toppers Hope portal for interactive study materials and board preparation.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-2",
        "name": "Next Toppers 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://eduvibe-nt.pages.dev/",
        "urlVerified": true,
        "description": "Eduvibe Next Toppers learning platform and lecture series.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-3",
        "name": "Next Toppers 🌟",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://deltastudy.fun/nexttoppers",
        "urlVerified": true,
        "description": "Delta Study Next Toppers revision portal and course batches.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-4",
        "name": "Next Toppers ✨",
        "logo": "https://i.ibb.co/Lzkbgnhz/IMG-4138.png",
        "portalUrl": "https://nt.studybeepro.site/",
        "urlVerified": true,
        "description": "StudyBeePro Next Toppers auth and study dashboard.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-5",
        "name": "Next Toppers 💥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://studyparcham.in/nt/",
        "urlVerified": true,
        "description": "StudyParcham Next Toppers batch portal and study notes.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-6",
        "name": "Next Toppers ⚡",
        "logo": "https://i.ibb.co/pBzfccMX/studypanda-nexttopers.png",
        "portalUrl": "https://studypanda.live/nexttoppers",
        "urlVerified": true,
        "description": "StudyPanda Next Toppers batch access and learning hub.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-7",
        "name": "Next Toppers 💎",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttopper.primestudy.live/",
        "urlVerified": true,
        "description": "PrimeStudy Next Toppers portal and course dashboard.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-9",
        "name": "Next Toppers 🎯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt1.learntopper.in/",
        "urlVerified": true,
        "description": "Next Toppers portal and learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-10",
        "name": "Next Toppers 📚",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttoppers.asmultiverse.in/",
        "urlVerified": true,
        "description": "Next Toppers portal and learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-11",
        "name": "Next Toppers 🎓",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://eduvibe-nt.pages.dev/old-batches/",
        "urlVerified": true,
        "description": "Next Toppers Eduvibe old batches portal and archive.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mystudybuddy-nt",
        "name": "Next Toppers 💡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://www.mystudybuddy.in/Next-toppers/index.html",
        "urlVerified": true,
        "description": "Next Toppers portal by My Study Buddy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nexttoppersheked",
        "name": "Next Toppers ⭐",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttoppersheked.netlify.app/",
        "urlVerified": true,
        "description": "Next Toppers batches by Heked.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "padhaikaadda-nt",
        "name": "Next Toppers 💯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://padhaikaadda.in/next-toppers/",
        "urlVerified": true,
        "description": "Next Toppers resources at Padhai Ka Adda.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nextedu-official",
        "name": "Next Toppers 👑",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nextedu-official.netlify.app/nexttoppers",
        "urlVerified": true,
        "description": "Next Toppers portal by Next Edu Official.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppersnt-vercel",
        "name": "Next Toppers 🌈",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://next-toppersnt.vercel.app/",
        "urlVerified": true,
        "description": "Vercel hosted Next Toppers portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "learnjh-nt",
        "name": "Next Toppers 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://learnjh.vercel.app/nexttoppers",
        "urlVerified": true,
        "description": "Next Toppers resources by LearnJH.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edunext-base44",
        "name": "Next Toppers 💻",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://edunext.base44.app/",
        "urlVerified": true,
        "description": "Next Toppers alternative portal by EduNext.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "trms-nt",
        "name": "Next Toppers 📱",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://trms-nt.vercel.app/",
        "urlVerified": true,
        "description": "TRMS hosted Next Toppers portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nexttoppersharsh",
        "name": "Next Toppers 😎",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttoppersharsh.netlify.app/",
        "urlVerified": true,
        "description": "Next Toppers portal by Harsh.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-streamfiles",
        "name": "Next Toppers 🎉",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt.streamfiles.eu.org",
        "urlVerified": true,
        "description": "Next Toppers streamfiles portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-studybison",
        "name": "StudyBison Next Toppers 🦬",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison Next Toppers 10th and 12th board batches and lecture portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edufreek-nt-pages",
        "name": "EduFreek Next Toppers 🎯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://edufreeknt.pages.dev/",
        "urlVerified": true,
        "description": "EduFreek Next Toppers Cloudflare portal with high-speed video lectures.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-rolexcoderz",
        "name": "Next Toppers Rolex Coderz",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://rolexcoderz.com/NT",
        "urlVerified": true,
        "description": "Next Toppers resources by Rolex Coderz.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-studyspark",
        "name": "Next Toppers StudySpark",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt.studyspark.pro/",
        "urlVerified": true,
        "description": "Next Toppers resources by StudySpark.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-videocrypt",
        "name": "Next Toppers VideoCrypt",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttoppers.videocrypt.in/",
        "urlVerified": true,
        "description": "Next Toppers VideoCrypt platform.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-verify-key",
        "name": "Next Toppers Verify Key",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://next-toppersnt.vercel.app/verify-key",
        "urlVerified": true,
        "description": "Next Toppers verification portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-official-vercel",
        "name": "Next Toppers Official Vercel",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttoppers-official.vercel.app/",
        "urlVerified": true,
        "description": "Next Toppers official Vercel portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-spidy",
        "name": "Next Toppers Spidy Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://spidytopper.vercel.app/",
        "urlVerified": true,
        "description": "Next Toppers Spidy portal for board exam lectures and study materials.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-topper-workers-bat",
        "name": "Next Topper BAT Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://bat.nexttopper.workers.dev/",
        "urlVerified": true,
        "description": "Next Topper fast batch portal on Cloudflare workers.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-learnxpw",
        "name": "Next Toppers LearnX Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://www.learnxpw.site/study/nexttoppers",
        "urlVerified": true,
        "description": "Next Toppers study batches and portal on LearnX.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-learntopper",
        "name": "Next Toppers LearnTopper 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt.learntopper.in/",
        "urlVerified": true,
        "description": "Next Toppers board preparation and lecture portal on LearnTopper.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nt-learnex",
        "name": "Next Toppers LearnEx ⚡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://learnex.vercel.app/NT",
        "urlVerified": true,
        "description": "Next Toppers exam preparation and notes portal on LearnEx Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-topper-pro-portal",
        "name": "Next Topper Pro 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttopperpro.vercel.app/",
        "urlVerified": true,
        "description": "Next Toppers board preparation, high school lectures, and academic guidance portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-1",
        "name": "Next Toppers",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://thescholarverse.site/study/nexttoppers",
        "urlVerified": true,
        "description": "Next Toppers by TheScholarVerse",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-2",
        "name": "Next Toppers",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://platform.studyparcham.in/key-generate?redirect=%2Fstudy%2Fnexttoppers&type=full",
        "urlVerified": true,
        "description": "Next Toppers by StudyParcham",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-nexthope",
        "name": "Next Toppers NextHope",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt.nexthope.site/",
        "urlVerified": true,
        "description": "Next Toppers online batch portal and study resource access on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-studyhulk-ai",
        "name": "Next Toppers StudyHulk AI",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://studyhulk-ntt.ai.studio/",
        "urlVerified": true,
        "description": "Next Toppers StudyHulk AI Studio learning portal and batch access.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-keygenerate",
        "name": "Next Toppers Key Generate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt.testuk.org/keygenerate",
        "urlVerified": true,
        "description": "Next Toppers key generator and batch authentication portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-nextmate",
        "name": "Next Toppers NextMate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nexttoppers.nextmate.site/",
        "urlVerified": true,
        "description": "Next Toppers digital study portal and learning platform on NextMate.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-lrnt-ccwu",
        "name": "Next Toppers LRNT",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://nt.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "Next Toppers online course materials and batch portal on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-deltaverse",
        "name": "Next Toppers DeltaVerse",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://deltaverse.site/nexttoppers",
        "urlVerified": true,
        "description": "Next Toppers academic batches, courses, and exam preparation on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "next-toppers-nexusstudy-vercel",
        "name": "Next Toppers Nexus Study",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "portalUrl": "https://ntnexusstudy.vercel.app/",
        "urlVerified": true,
        "description": "Next Toppers board preparation, lectures, and revision batches on Nexus Study Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 43,
    "rating": 5,
    "reviewCount": 6660,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Class 10th Boards",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-next-toppers-batch",
        "title": "Next Toppers OFFICIAL ✅",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Official",
          "Boards"
        ],
        "subject": "Official Platform",
        "description": "Official Next Toppers portal for exam preparation and academic guidance.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttoppers.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers OFFICIAL ✅"
      },
      {
        "id": "nt-1-batch",
        "title": "Next Toppers 🚀",
        "logo": "https://i.ibb.co/v4k8LdYN/nexthope.png",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT HOPE",
          "Study Portal"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers Hope portal for interactive study materials and board preparation.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/nt/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🚀"
      },
      {
        "id": "nt-2-batch",
        "title": "Next Toppers 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT EDUVIBE",
          "Lectures"
        ],
        "subject": "Board & Exam Prep",
        "description": "Eduvibe Next Toppers learning platform and lecture series.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://eduvibe-nt.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🔥"
      },
      {
        "id": "nt-3-batch",
        "title": "Next Toppers 🌟",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT DELTA",
          "Revision"
        ],
        "subject": "Board & Exam Prep",
        "description": "Delta Study Next Toppers revision portal and course batches.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/nexttoppers",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🌟"
      },
      {
        "id": "nt-4-batch",
        "title": "Next Toppers ✨",
        "logo": "https://i.ibb.co/Lzkbgnhz/IMG-4138.png",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT BEE",
          "Dashboard"
        ],
        "subject": "Board & Exam Prep",
        "description": "StudyBeePro Next Toppers auth and study dashboard.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers ✨"
      },
      {
        "id": "nt-5-batch",
        "title": "Next Toppers 💥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT PARCHAM",
          "Notes"
        ],
        "subject": "Board & Exam Prep",
        "description": "StudyParcham Next Toppers batch portal and study notes.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyparcham.in/nt/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 💥"
      },
      {
        "id": "nt-6-batch",
        "title": "Next Toppers ⚡",
        "logo": "https://i.ibb.co/pBzfccMX/studypanda-nexttopers.png",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT PANDA",
          "Learning Hub"
        ],
        "subject": "Board & Exam Prep",
        "description": "StudyPanda Next Toppers batch access and learning hub.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studypanda.live/nexttoppers",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers ⚡"
      },
      {
        "id": "nt-7-batch",
        "title": "Next Toppers 💎",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT PRIME",
          "PrimeStudy"
        ],
        "subject": "Board & Exam Prep",
        "description": "PrimeStudy Next Toppers portal and course dashboard.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttopper.primestudy.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 💎"
      },
      {
        "id": "nt-9-batch",
        "title": "Next Toppers 🎯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT Learntopper",
          "Study Portal"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers portal and learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt1.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🎯"
      },
      {
        "id": "nt-10-batch",
        "title": "Next Toppers 📚",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT Multiverse",
          "Study Portal"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers portal and learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttoppers.asmultiverse.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 📚"
      },
      {
        "id": "nt-11-batch",
        "title": "Next Toppers 🎓",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NT Eduvibe",
          "Old Batches"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers Eduvibe old batches portal and archive.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://eduvibe-nt.pages.dev/old-batches/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🎓"
      },
      {
        "id": "mystudybuddy-nt-batch",
        "title": "Next Toppers 💡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Study Buddy"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers portal by My Study Buddy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.mystudybuddy.in/Next-toppers/index.html",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 💡"
      },
      {
        "id": "nexttoppersheked-batch",
        "title": "Next Toppers ⭐",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Heked"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers batches by Heked.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttoppersheked.netlify.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers ⭐"
      },
      {
        "id": "padhaikaadda-nt-batch",
        "title": "Next Toppers 💯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Padhai Ka Adda"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers resources at Padhai Ka Adda.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://padhaikaadda.in/next-toppers/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 💯"
      },
      {
        "id": "nextedu-official-batch",
        "title": "Next Toppers 👑",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Next Edu"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers portal by Next Edu Official.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nextedu-official.netlify.app/nexttoppers",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 👑"
      },
      {
        "id": "next-toppersnt-vercel-batch",
        "title": "Next Toppers 🌈",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Vercel"
        ],
        "subject": "Batches & Courses",
        "description": "Vercel hosted Next Toppers portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://next-toppersnt.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🌈"
      },
      {
        "id": "learnjh-nt-batch",
        "title": "Next Toppers 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "LearnJH"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers resources by LearnJH.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnjh.vercel.app/nexttoppers",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🔥"
      },
      {
        "id": "edunext-base44-batch",
        "title": "Next Toppers 💻",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "EduNext"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers alternative portal by EduNext.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edunext.base44.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 💻"
      },
      {
        "id": "trms-nt-batch",
        "title": "Next Toppers 📱",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "TRMS"
        ],
        "subject": "Batches & Courses",
        "description": "TRMS hosted Next Toppers portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://trms-nt.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 📱"
      },
      {
        "id": "nexttoppersharsh-batch",
        "title": "Next Toppers 😎",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Harsh"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers portal by Harsh.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttoppersharsh.netlify.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 😎"
      },
      {
        "id": "nt-streamfiles-batch",
        "title": "Next Toppers 🎉",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Streamfiles"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers streamfiles portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.streamfiles.eu.org",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers 🎉"
      },
      {
        "id": "nt-studybison-batch",
        "title": "StudyBison Next Toppers 🦬",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "StudyBison",
          "Boards"
        ],
        "subject": "Board & Exam Prep",
        "description": "StudyBison Next Toppers 10th and 12th board batches and lecture portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison Next Toppers 🦬"
      },
      {
        "id": "edufreek-nt-pages-batch",
        "title": "EduFreek Next Toppers 🎯",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "EduFreek",
          "Pages Dev"
        ],
        "subject": "Board & Exam Prep",
        "description": "EduFreek Next Toppers Cloudflare portal with high-speed video lectures.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edufreeknt.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "EduFreek Next Toppers 🎯"
      },
      {
        "id": "nt-rolexcoderz-batch",
        "title": "Next Toppers Rolex Coderz",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Rolex Coderz"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers resources by Rolex Coderz.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rolexcoderz.com/NT",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers Rolex Coderz"
      },
      {
        "id": "nt-studyspark-batch",
        "title": "Next Toppers StudySpark",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "StudySpark"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers resources by StudySpark.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.studyspark.pro/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers StudySpark"
      },
      {
        "id": "nt-videocrypt-batch",
        "title": "Next Toppers VideoCrypt",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "VideoCrypt"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers VideoCrypt platform.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttoppers.videocrypt.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers VideoCrypt"
      },
      {
        "id": "nt-verify-key-batch",
        "title": "Next Toppers Verify Key",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Verify Key"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers verification portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://next-toppersnt.vercel.app/verify-key",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers Verify Key"
      },
      {
        "id": "nt-official-vercel-batch",
        "title": "Next Toppers Official Vercel",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Official"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers official Vercel portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttoppers-official.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers Official Vercel"
      },
      {
        "id": "next-toppers-spidy-batch",
        "title": "Next Toppers Spidy Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Spidy",
          "Board Exams"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers Spidy portal for board exam lectures and study materials.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://spidytopper.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers Spidy Portal"
      },
      {
        "id": "next-topper-workers-bat-batch",
        "title": "Next Topper BAT Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Topper",
          "BAT",
          "Board Exams"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Topper fast batch portal on Cloudflare workers.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bat.nexttopper.workers.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Topper BAT Portal"
      },
      {
        "id": "next-toppers-learnxpw-batch",
        "title": "Next Toppers LearnX Portal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "LearnX",
          "Board Exams"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers study batches and portal on LearnX.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.learnxpw.site/study/nexttoppers",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers LearnX Portal"
      },
      {
        "id": "nt-learntopper-batch",
        "title": "Next Toppers LearnTopper 🚀",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "LearnTopper",
          "Boards"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers board preparation and lecture portal on LearnTopper.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers LearnTopper 🚀"
      },
      {
        "id": "nt-learnex-batch",
        "title": "Next Toppers LearnEx ⚡",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "LearnEx",
          "Vercel"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers exam preparation and notes portal on LearnEx Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnex.vercel.app/NT",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers LearnEx ⚡"
      },
      {
        "id": "next-topper-pro-portal-batch",
        "title": "Next Topper Pro 🔥",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Board & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Next Topper Pro",
          "Vercel"
        ],
        "subject": "Board & Exam Prep",
        "description": "Next Toppers board preparation, high school lectures, and academic guidance portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttopperpro.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Topper Pro 🔥"
      },
      {
        "id": "next-toppers-1-batch",
        "title": "Next Toppers",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "TheScholarVerse"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers by TheScholarVerse",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://thescholarverse.site/study/nexttoppers",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers"
      },
      {
        "id": "next-toppers-2-batch",
        "title": "Next Toppers",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "StudyParcham"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers by StudyParcham",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://platform.studyparcham.in/key-generate?redirect=%2Fstudy%2Fnexttoppers&type=full",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers"
      },
      {
        "id": "next-toppers-nexthope-batch",
        "title": "Next Toppers NextHope",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NextHope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers online batch portal and study resource access on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers NextHope"
      },
      {
        "id": "next-toppers-studyhulk-ai-batch",
        "title": "Next Toppers StudyHulk AI",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "StudyHulk",
          "AI Studio"
        ],
        "subject": "Batches & Courses",
        "description": "Next Toppers StudyHulk AI Studio learning portal and batch access.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyhulk-ntt.ai.studio/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers StudyHulk AI"
      },
      {
        "id": "next-toppers-keygenerate-batch",
        "title": "Next Toppers Key Generate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Study Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Key Generate",
          "Portal"
        ],
        "subject": "Batches & Study Material",
        "description": "Next Toppers key generator and batch authentication portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.testuk.org/keygenerate",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers Key Generate"
      },
      {
        "id": "next-toppers-nextmate-batch",
        "title": "Next Toppers NextMate",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Study Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "NextMate",
          "Study Portal"
        ],
        "subject": "Batches & Study Material",
        "description": "Next Toppers digital study portal and learning platform on NextMate.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexttoppers.nextmate.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers NextMate"
      },
      {
        "id": "next-toppers-lrnt-ccwu-batch",
        "title": "Next Toppers LRNT",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Study Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "LRNT",
          "Batches"
        ],
        "subject": "Batches & Study Material",
        "description": "Next Toppers online course materials and batch portal on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nt.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers LRNT"
      },
      {
        "id": "next-toppers-deltaverse-batch",
        "title": "Next Toppers DeltaVerse",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Study Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "DeltaVerse",
          "Batches"
        ],
        "subject": "Batches & Study Material",
        "description": "Next Toppers academic batches, courses, and exam preparation on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltaverse.site/nexttoppers",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers DeltaVerse"
      },
      {
        "id": "next-toppers-nexusstudy-vercel-batch",
        "title": "Next Toppers Nexus Study",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1mUiY27Zw1lOwzgyGbwpdWlVgzDEZGmrfjfZqT0XGew&s",
        "targetExam": "Batches & Study Material",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Next Toppers",
          "Nexus Study",
          "Vercel"
        ],
        "subject": "Batches & Study Material",
        "description": "Next Toppers board preparation, lectures, and revision batches on Nexus Study Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://ntnexusstudy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Next Toppers Nexus Study"
      }
    ],
    "resources": [
      {
        "id": "next-toppers-res-1",
        "title": "Next Toppers Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Next Toppers.",
        "url": "https://nexttoppers.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "khan-global-studies",
    "name": "Khan Global Studies",
    "slug": "khan-global-studies",
    "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
    "tagline": "KGS Learning Hub",
    "establishedYear": 2021,
    "category": "upsc",
    "categoryLabel": "Khan GS & Civil Services",
    "exams": [
      "UPSC CSE",
      "BPSC",
      "UPPSC",
      "Railway",
      "SSC"
    ],
    "brandColor": "#ea580c",
    "badgeText": "KGS",
    "description": "Expert guidance and widespread preparation courses for all major competitive exams.",
    "officialWebsite": "https://khanglobalstudies.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://khanglobalstudies.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 10,
    "portals": [
      {
        "id": "official-kgs",
        "name": "KGS OFFICIAL ✅",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://khanglobalstudies.com",
        "urlVerified": true,
        "description": "Official Khan Global Studies guidance and preparation courses.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-1",
        "name": "KGS 🚀",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://asmultiverse.in/details?id=Khan%20Global%20Studies",
        "urlVerified": true,
        "description": "Khan Global Studies courses and batch details on AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-2",
        "name": "KGS 🔥",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://studyapkmodkgs.vercel.app/",
        "urlVerified": true,
        "description": "Khan Global Studies course material portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-3",
        "name": "KGS 🌟",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://sahukgs.vercel.app/batches",
        "urlVerified": true,
        "description": "Khan Global Studies batch navigation portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "khan-global-studies-workers-bat",
        "name": "Khan GS BAT Portal",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://bat.kgss.workers.dev/",
        "urlVerified": true,
        "description": "Khan Global Studies (KGS) fast batch portal for GS and competitive exams.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-vidyaverse",
        "name": "KGS Vidyaverse 🌟",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://vidyaverse-kgs.vercel.app/",
        "urlVerified": true,
        "description": "Khan Global Studies batch access and study portal on Vidyaverse Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-vercel-portal",
        "name": "Khan Global Studies KGS 🎓",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://khanglobal.vercel.app/",
        "urlVerified": true,
        "description": "Khan Global Studies batches, live lectures, and competitive exam preparation portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-spidyuniverse-in",
        "name": "Khan Global Studies Spidy 🎓",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://kgs.spidyuniverse.in/",
        "urlVerified": true,
        "description": "Khan Global Studies batches, live lectures, and competitive exam preparation on Spidy Universe.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-sangam-new",
        "name": "Khan Global Studies Sangam",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://sangam.free.nf/KGSNEW/",
        "urlVerified": true,
        "description": "Khan Global Studies competitive exam batch portal and courses on Sangam.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "kgs-unuverse-app",
        "name": "Khan Global Studies Universe App",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "portalUrl": "https://bat.unuverse.workers.dev/app/ba535b18-1070-404c-8160-808b6ecb7040",
        "urlVerified": true,
        "description": "Khan Global Studies batch portal and interactive learning application on Universe Workers.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 10,
    "rating": 5,
    "reviewCount": 2700,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "UPSC CSE",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-kgs-batch",
        "title": "KGS OFFICIAL ✅",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KGS",
          "Official",
          "Khan Sir"
        ],
        "subject": "Official Platform",
        "description": "Official Khan Global Studies guidance and preparation courses.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://khanglobalstudies.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "KGS OFFICIAL ✅"
      },
      {
        "id": "kgs-1-batch",
        "title": "KGS 🚀",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KGS",
          "Khan Global Studies",
          "AS Multiverse"
        ],
        "subject": "Batches & Courses",
        "description": "Khan Global Studies courses and batch details on AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.in/details?id=Khan%20Global%20Studies",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "KGS 🚀"
      },
      {
        "id": "kgs-2-batch",
        "title": "KGS 🔥",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KGS",
          "Khan Global Studies",
          "Vercel"
        ],
        "subject": "Batches & Courses",
        "description": "Khan Global Studies course material portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmodkgs.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "KGS 🔥"
      },
      {
        "id": "kgs-3-batch",
        "title": "KGS 🌟",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KGS",
          "Khan Global Studies",
          "Sahu"
        ],
        "subject": "Batches & Courses",
        "description": "Khan Global Studies batch navigation portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sahukgs.vercel.app/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "KGS 🌟"
      },
      {
        "id": "khan-global-studies-workers-bat-batch",
        "title": "Khan GS BAT Portal",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "General Studies & Civil Services",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Khan Global Studies",
          "KGS",
          "Khan Sir"
        ],
        "subject": "General Studies & Civil Services",
        "description": "Khan Global Studies (KGS) fast batch portal for GS and competitive exams.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bat.kgss.workers.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Khan GS BAT Portal"
      },
      {
        "id": "kgs-vidyaverse-batch",
        "title": "KGS Vidyaverse 🌟",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KGS",
          "Khan Global Studies",
          "Vidyaverse"
        ],
        "subject": "Batches & Courses",
        "description": "Khan Global Studies batch access and study portal on Vidyaverse Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vidyaverse-kgs.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "KGS Vidyaverse 🌟"
      },
      {
        "id": "kgs-vercel-portal-batch",
        "title": "Khan Global Studies KGS 🎓",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KGS",
          "Khan Global Studies",
          "Khan Sir"
        ],
        "subject": "Batches & Courses",
        "description": "Khan Global Studies batches, live lectures, and competitive exam preparation portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://khanglobal.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Khan Global Studies KGS 🎓"
      },
      {
        "id": "kgs-spidyuniverse-in-batch",
        "title": "Khan Global Studies Spidy 🎓",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "KGS",
          "Khan Global Studies",
          "Khan Sir"
        ],
        "subject": "Batches & Courses",
        "description": "Khan Global Studies batches, live lectures, and competitive exam preparation on Spidy Universe.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://kgs.spidyuniverse.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Khan Global Studies Spidy 🎓"
      },
      {
        "id": "kgs-sangam-new-batch",
        "title": "Khan Global Studies Sangam",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Competitive Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Khan Global Studies",
          "KGS",
          "Sangam"
        ],
        "subject": "Competitive Exams",
        "description": "Khan Global Studies competitive exam batch portal and courses on Sangam.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sangam.free.nf/KGSNEW/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Khan Global Studies Sangam"
      },
      {
        "id": "kgs-unuverse-app-batch",
        "title": "Khan Global Studies Universe App",
        "logo": "https://i.postimg.cc/zXnQX9Bc/images-2026-07-06T121712-741.jpg",
        "targetExam": "Competitive Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Khan Global Studies",
          "KGS",
          "Universe Workers"
        ],
        "subject": "Competitive Exams",
        "description": "Khan Global Studies batch portal and interactive learning application on Universe Workers.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bat.unuverse.workers.dev/app/ba535b18-1070-404c-8160-808b6ecb7040",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Khan Global Studies Universe App"
      }
    ],
    "resources": [
      {
        "id": "khan-global-studies-res-1",
        "title": "Khan Global Studies Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Khan Global Studies.",
        "url": "https://khanglobalstudies.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "sachin-academy",
    "name": "Sachin Academy",
    "slug": "sachin-academy",
    "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
    "tagline": "Sachin Academy Learning Hub",
    "establishedYear": 2021,
    "category": "teaching",
    "categoryLabel": "Teaching Eligibility CTET",
    "exams": [
      "CTET Paper 1 & 2",
      "UPTET",
      "Super TET",
      "KVS / DSSSB"
    ],
    "brandColor": "#16a34a",
    "badgeText": "Sachin Academy",
    "description": "Trusted online education portal dedicated to maximizing student potential.",
    "officialWebsite": "https://sachinacademy.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://sachinacademy.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 6,
    "portals": [
      {
        "id": "official-sachin-academy",
        "name": "Sachin Academy OFFICIAL ✅",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "portalUrl": "https://sachinacademy.com",
        "urlVerified": true,
        "description": "Official Sachin Academy online education portal.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sa-1",
        "name": "Sachin Academy 🚀",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "portalUrl": "https://sachinclassex1.vercel.app/",
        "urlVerified": true,
        "description": "Sachin Academy online classes and study portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sachin-academy-web-pages",
        "name": "Sachin Academy Web 🎓",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "portalUrl": "https://sachinweb.pages.dev/",
        "urlVerified": true,
        "description": "Sachin Academy teaching eligibility test (CTET, State TET) courses and lecture portal on Cloudflare Pages.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sachin-academy-1",
        "name": "Sachin Academy",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "portalUrl": "https://sachin.studybeepro.site/",
        "urlVerified": true,
        "description": "Sachin Academy by StudyBeePro",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sachin-academy-sangam",
        "name": "Sachin Academy Sangam",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "portalUrl": "https://sangam.free.nf/SCN/sachin1.php",
        "urlVerified": true,
        "description": "Sachin Academy CTET and teaching exam batch access on Sangam.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sachin-academy-nexthope",
        "name": "Sachin Academy NextHope",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "portalUrl": "https://sachin.nexthope.site/",
        "urlVerified": true,
        "description": "Sachin Academy CTET and teaching exam learning portal on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 6,
    "rating": 5,
    "reviewCount": 2220,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "CTET Paper 1 & 2",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-sachin-academy-batch",
        "title": "Sachin Academy OFFICIAL ✅",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Sachin Academy",
          "Official",
          "Education"
        ],
        "subject": "Official Platform",
        "description": "Official Sachin Academy online education portal.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://sachinacademy.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Sachin Academy OFFICIAL ✅"
      },
      {
        "id": "sa-1-batch",
        "title": "Sachin Academy 🚀",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "targetExam": "Teaching & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Sachin Academy",
          "Vercel",
          "Classes"
        ],
        "subject": "Teaching & Exam Prep",
        "description": "Sachin Academy online classes and study portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sachinclassex1.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Sachin Academy 🚀"
      },
      {
        "id": "sachin-academy-web-pages-batch",
        "title": "Sachin Academy Web 🎓",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "targetExam": "Teaching & Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Sachin Academy",
          "Cloudflare Pages",
          "CTET"
        ],
        "subject": "Teaching & Exam Prep",
        "description": "Sachin Academy teaching eligibility test (CTET, State TET) courses and lecture portal on Cloudflare Pages.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sachinweb.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Sachin Academy Web 🎓"
      },
      {
        "id": "sachin-academy-1-batch",
        "title": "Sachin Academy",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Sachin Academy",
          "StudyBeePro"
        ],
        "subject": "Batches & Courses",
        "description": "Sachin Academy by StudyBeePro",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://sachin.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Sachin Academy"
      },
      {
        "id": "sachin-academy-sangam-batch",
        "title": "Sachin Academy Sangam",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "targetExam": "Teaching & CTET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Sachin Academy",
          "Sangam",
          "CTET"
        ],
        "subject": "Teaching & CTET",
        "description": "Sachin Academy CTET and teaching exam batch access on Sangam.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sangam.free.nf/SCN/sachin1.php",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Sachin Academy Sangam"
      },
      {
        "id": "sachin-academy-nexthope-batch",
        "title": "Sachin Academy NextHope",
        "logo": "https://i.postimg.cc/HkTLk8ZY/images-2026-07-14T141545-975.jpg",
        "targetExam": "Teaching & CTET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Sachin Academy",
          "NextHope",
          "CTET"
        ],
        "subject": "Teaching & CTET",
        "description": "Sachin Academy CTET and teaching exam learning portal on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sachin.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Sachin Academy NextHope"
      }
    ],
    "resources": [
      {
        "id": "sachin-academy-res-1",
        "title": "Sachin Academy Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Sachin Academy.",
        "url": "https://sachinacademy.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "parmar-ssc",
    "name": "Parmar SSC",
    "slug": "parmar-ssc",
    "logo": "https://i.postimg.cc/J7vtBh33/2022-08-15-0-05315769411989324.webp",
    "tagline": "Parmar SSC Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Parmar SSC General Studies",
    "exams": [
      "SSC CGL GS",
      "CHSL",
      "CPO",
      "Static GK"
    ],
    "brandColor": "#b91c1c",
    "badgeText": "Parmar SSC",
    "description": "Comprehensive preparation portal, batches, notes, and test series for SSC CGL, CHSL, MTS, and competitive government exams by Parmar SSC.",
    "officialWebsite": "https://vividellorvii.vercel.app/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://vividellorvii.vercel.app/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "parmar-ssc",
        "name": "Parmar SSC",
        "logo": "https://i.postimg.cc/J7vtBh33/2022-08-15-0-05315769411989324.webp",
        "portalUrl": "https://vividellorvii.vercel.app/",
        "urlVerified": true,
        "description": "Official portal for Parmar SSC study batches, courses, video lectures, and exam preparation resources.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.9,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SSC CGL GS",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "parmar-ssc-batch",
        "title": "Parmar SSC",
        "logo": "https://i.postimg.cc/J7vtBh33/2022-08-15-0-05315769411989324.webp",
        "targetExam": "SSC & Government Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Parmar SSC",
          "SSC CGL",
          "CHSL"
        ],
        "subject": "SSC & Government Exams",
        "description": "Official portal for Parmar SSC study batches, courses, video lectures, and exam preparation resources.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://vividellorvii.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Parmar SSC"
      }
    ],
    "resources": [
      {
        "id": "parmar-ssc-res-1",
        "title": "Parmar SSC Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Parmar SSC.",
        "url": "https://vividellorvii.vercel.app/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "pw-ott-pi-pro",
    "name": "PW OTT - Pi Pro",
    "slug": "pw-ott-pi-pro",
    "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
    "tagline": "PW OTT Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "PW Video Streams & OTT",
    "exams": [
      "Recorded Lectures",
      "Fast-track Revision",
      "Concept Booster"
    ],
    "brandColor": "#9333ea",
    "badgeText": "PW OTT",
    "description": "Premium streaming and interactive learning portal for Physics Wallah OTT and Pi Pro video lectures.",
    "officialWebsite": "https://pw.live",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://pw.live",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 5,
    "portals": [
      {
        "id": "official-pw-ott",
        "name": "PW OTT OFFICIAL ✅",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "portalUrl": "https://pw.live",
        "urlVerified": true,
        "description": "Official PW OTT streaming and interactive learning portal.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-ott-1",
        "name": "PW OTT 🚀",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "portalUrl": "https://pipro.deltastudy.fun/",
        "urlVerified": true,
        "description": "Pi Pro Delta streaming and interactive learning portal for Physics Wallah OTT lectures.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pipro-studyspark",
        "name": "Pi Pro StudySpark",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "portalUrl": "https://pi.studyspark.study/",
        "urlVerified": true,
        "description": "Pi Pro learning resources by StudySpark.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-ott-pi-pro-learnxpw",
        "name": "Pi Pro LearnX Portal",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "portalUrl": "https://www.learnxpw.site/study/pi",
        "urlVerified": true,
        "description": "PW OTT and Pi Pro video lecture streaming on LearnX.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pi-pro-deltaverse",
        "name": "Pi Pro DeltaVerse",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "portalUrl": "https://deltaverse.site/pipro",
        "urlVerified": true,
        "description": "Pi Pro streaming and interactive learning portal on DeltaVerse for Physics Wallah OTT lectures.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 5,
    "rating": 5,
    "reviewCount": 2100,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Recorded Lectures",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-pw-ott-batch",
        "title": "PW OTT OFFICIAL ✅",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "PW OTT",
          "Official",
          "Streaming"
        ],
        "subject": "Official Platform",
        "description": "Official PW OTT streaming and interactive learning portal.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.live",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW OTT OFFICIAL ✅"
      },
      {
        "id": "pw-ott-1-batch",
        "title": "PW OTT 🚀",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "targetExam": "Video Lectures & OTT",
        "targetYear": "2025-2026",
        "facultyNames": [
          "PW OTT",
          "Pi Pro",
          "Delta Study"
        ],
        "subject": "Video Lectures & OTT",
        "description": "Pi Pro Delta streaming and interactive learning portal for Physics Wallah OTT lectures.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pipro.deltastudy.fun/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW OTT 🚀"
      },
      {
        "id": "pipro-studyspark-batch",
        "title": "Pi Pro StudySpark",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "targetExam": "Video Lectures & OTT",
        "targetYear": "2025-2026",
        "facultyNames": [
          "PW OTT",
          "Pi Pro",
          "StudySpark"
        ],
        "subject": "Video Lectures & OTT",
        "description": "Pi Pro learning resources by StudySpark.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pi.studyspark.study/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Pi Pro StudySpark"
      },
      {
        "id": "pw-ott-pi-pro-learnxpw-batch",
        "title": "Pi Pro LearnX Portal",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "targetExam": "OTT & Streaming",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Pi Pro",
          "PW OTT",
          "LearnX"
        ],
        "subject": "OTT & Streaming",
        "description": "PW OTT and Pi Pro video lecture streaming on LearnX.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.learnxpw.site/study/pi",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Pi Pro LearnX Portal"
      },
      {
        "id": "pi-pro-deltaverse-batch",
        "title": "Pi Pro DeltaVerse",
        "logo": "https://i.ibb.co/FRDwFWc/20260613-082831.jpg",
        "targetExam": "Video Lectures & OTT",
        "targetYear": "2025-2026",
        "facultyNames": [
          "PW OTT",
          "Pi Pro",
          "DeltaVerse"
        ],
        "subject": "Video Lectures & OTT",
        "description": "Pi Pro streaming and interactive learning portal on DeltaVerse for Physics Wallah OTT lectures.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltaverse.site/pipro",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Pi Pro DeltaVerse"
      }
    ],
    "resources": [
      {
        "id": "pw-ott-pi-pro-res-1",
        "title": "PW OTT - Pi Pro Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for PW OTT - Pi Pro.",
        "url": "https://pw.live",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "sarvam-kota",
    "name": "Sarvam Kota",
    "slug": "sarvam-kota",
    "logo": "https://i.ibb.co/dJ7mkpHX/images-2026-07-27-T135940-243.png",
    "tagline": "Sarvam Kota Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "Sarvam Kota JEE & NEET",
    "exams": [
      "Kota JEE",
      "NEET Medical",
      "Foundation PCM"
    ],
    "brandColor": "#0891b2",
    "badgeText": "Sarvam Kota",
    "description": "Premier IIT-JEE, NEET, and foundation coaching portal and batch learning resources by Sarvam Kota.",
    "officialWebsite": "https://baloch-king.vercel.app/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://baloch-king.vercel.app/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 1,
    "portals": [
      {
        "id": "sarvam-kota-portal",
        "name": "Sarvam Kota",
        "logo": "https://i.ibb.co/dJ7mkpHX/images-2026-07-27-T135940-243.png",
        "portalUrl": "https://baloch-king.vercel.app/",
        "urlVerified": true,
        "description": "Sarvam Kota online study portal for competitive exams, JEE, NEET, and foundation batches.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 1,
    "rating": 4.9,
    "reviewCount": 1620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Kota JEE",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "sarvam-kota-portal-batch",
        "title": "Sarvam Kota",
        "logo": "https://i.ibb.co/dJ7mkpHX/images-2026-07-27-T135940-243.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Sarvam Kota",
          "Kota Coaching",
          "IIT-JEE"
        ],
        "subject": "Batches & Courses",
        "description": "Sarvam Kota online study portal for competitive exams, JEE, NEET, and foundation batches.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://baloch-king.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Sarvam Kota"
      }
    ],
    "resources": [
      {
        "id": "sarvam-kota-res-1",
        "title": "Sarvam Kota Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Sarvam Kota.",
        "url": "https://baloch-king.vercel.app/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "padhle-akshay",
    "name": "Padhle Akshay",
    "slug": "padhle-akshay",
    "logo": "https://framerusercontent.com/images/N5AlmRNRnQQa7FnlvrGcUzUhZGY.png?scale-down-to=512",
    "tagline": "Padhle Akshay Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "Class 9th & 10th Boards",
    "exams": [
      "Class 10 CBSE",
      "Science & Maths",
      "Social Science"
    ],
    "brandColor": "#0284c7",
    "badgeText": "Padhle Akshay",
    "description": "Official portal for Padhle Akshay study resources, notes, and batches.",
    "officialWebsite": "https://eduzex.is-great.org/padhleakshay/batches.php",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://eduzex.is-great.org/padhleakshay/batches.php",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "padhle-akshay-official",
        "name": "Padhle Akshay OFFICIAL ✅",
        "logo": "https://framerusercontent.com/images/N5AlmRNRnQQa7FnlvrGcUzUhZGY.png?scale-down-to=512",
        "portalUrl": "https://eduzex.is-great.org/padhleakshay/batches.php",
        "urlVerified": true,
        "description": "Official portal for Padhle Akshay study resources, notes, and batches.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "nextedu-padhle-akshay",
        "name": "Padhle Akshay 🚀",
        "logo": "https://framerusercontent.com/images/N5AlmRNRnQQa7FnlvrGcUzUhZGY.png?scale-down-to=512",
        "portalUrl": "https://nextedu-official.netlify.app/padhle-akshay/",
        "urlVerified": true,
        "description": "Padhle Akshay resources by Next Edu.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 4.9,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Class 10 CBSE",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "padhle-akshay-official-batch",
        "title": "Padhle Akshay OFFICIAL ✅",
        "logo": "https://framerusercontent.com/images/N5AlmRNRnQQa7FnlvrGcUzUhZGY.png?scale-down-to=512",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Padhle Akshay",
          "Batches",
          "Notes"
        ],
        "subject": "Batches & Courses",
        "description": "Official portal for Padhle Akshay study resources, notes, and batches.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://eduzex.is-great.org/padhleakshay/batches.php",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Padhle Akshay OFFICIAL ✅"
      },
      {
        "id": "nextedu-padhle-akshay-batch",
        "title": "Padhle Akshay 🚀",
        "logo": "https://framerusercontent.com/images/N5AlmRNRnQQa7FnlvrGcUzUhZGY.png?scale-down-to=512",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Padhle Akshay",
          "Next Edu"
        ],
        "subject": "Batches & Courses",
        "description": "Padhle Akshay resources by Next Edu.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nextedu-official.netlify.app/padhle-akshay/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Padhle Akshay 🚀"
      }
    ],
    "resources": [
      {
        "id": "padhle-akshay-res-1",
        "title": "Padhle Akshay Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Padhle Akshay.",
        "url": "https://eduzex.is-great.org/padhleakshay/batches.php",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "rg-vikramjeet",
    "name": "RG Vikram Jeet",
    "slug": "rg-vikramjeet",
    "logo": "https://appx-wsb-gcp.akamai.net.in/subject/2022-06-10-0.016661521804902213.webp",
    "tagline": "RG Vikram Jeet Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Maths & Reasoning Special",
    "exams": [
      "SSC CGL Maths",
      "Reasoning Special",
      "State Police"
    ],
    "brandColor": "#ea580c",
    "badgeText": "RG Vikram Jeet",
    "description": "Comprehensive preparation portal for SSC, CGL, CHSL, Railway, and state competitive exams by RG Vikramjeet & Rankers Gurukul team.",
    "officialWebsite": "https://rgvikramjeet.nextmate.site/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://rgvikramjeet.nextmate.site/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "rg-vikramjeet-nextmate",
        "name": "RG Vikram Jeet NextMate",
        "logo": "https://appx-wsb-gcp.akamai.net.in/subject/2022-06-10-0.016661521804902213.webp",
        "portalUrl": "https://rgvikramjeet.nextmate.site/",
        "urlVerified": true,
        "description": "RG Vikram Jeet study materials, live batches, and video lectures on NextMate.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rg-vikramjeet-netlify",
        "name": "RG Vikram Jeet Netlify",
        "logo": "https://appx-wsb-gcp.akamai.net.in/subject/2022-06-10-0.016661521804902213.webp",
        "portalUrl": "https://rg-vikramjeet.netlify.app/",
        "urlVerified": true,
        "description": "RG Vikram Jeet batches, video lectures, and competitive exam preparation portal on Netlify.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 4.8,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SSC CGL Maths",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "rg-vikramjeet-nextmate-batch",
        "title": "RG Vikram Jeet NextMate",
        "logo": "https://appx-wsb-gcp.akamai.net.in/subject/2022-06-10-0.016661521804902213.webp",
        "targetExam": "SSC & Government Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RG Vikram Jeet",
          "Rankers Gurukul",
          "NextMate"
        ],
        "subject": "SSC & Government Exams",
        "description": "RG Vikram Jeet study materials, live batches, and video lectures on NextMate.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rgvikramjeet.nextmate.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RG Vikram Jeet NextMate"
      },
      {
        "id": "rg-vikramjeet-netlify-batch",
        "title": "RG Vikram Jeet Netlify",
        "logo": "https://appx-wsb-gcp.akamai.net.in/subject/2022-06-10-0.016661521804902213.webp",
        "targetExam": "SSC & Government Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RG Vikram Jeet",
          "Rankers Gurukul",
          "Netlify"
        ],
        "subject": "SSC & Government Exams",
        "description": "RG Vikram Jeet batches, video lectures, and competitive exam preparation portal on Netlify.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rg-vikramjeet.netlify.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RG Vikram Jeet Netlify"
      }
    ],
    "resources": [
      {
        "id": "rg-vikramjeet-res-1",
        "title": "RG Vikram Jeet Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for RG Vikram Jeet.",
        "url": "https://rgvikramjeet.nextmate.site/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "rojgar-with-ankit",
    "name": "Rojgar With Ankit",
    "slug": "rojgar-with-ankit",
    "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
    "tagline": "RWA Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Rojgar With Ankit RWA",
    "exams": [
      "UP Police",
      "SSC GD",
      "Delhi Police",
      "Army GD",
      "BSSC"
    ],
    "brandColor": "#2563eb",
    "badgeText": "RWA",
    "description": "Preparation platform for government jobs, SSC, Police, Railway, and competitive recruitment exams.",
    "officialWebsite": "https://rojgarwithankit.co.in/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://rojgarwithankit.co.in/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 17,
    "portals": [
      {
        "id": "rwa-1",
        "name": "RWA OFFICIAL ✅",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rojgarwithankit.co.in/",
        "urlVerified": true,
        "description": "Official portal for Rojgar With Ankit courses and test series.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-2",
        "name": "RWA 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa.studybeepro.site/rwax/",
        "urlVerified": true,
        "description": "RWA batch access and learning resources by Study Bee Pro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-3",
        "name": "RWA 🔥",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa.studypanda.live/",
        "urlVerified": true,
        "description": "RWA courses and study material by Study Panda.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-4",
        "name": "RWA 🌟",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://deltastudy.fun/rojgarwithankit",
        "urlVerified": true,
        "description": "RWA batch access and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-5",
        "name": "RWA ✨",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa-dreamstudy.pages.dev/",
        "urlVerified": true,
        "description": "RWA batch access and learning resources by Dream Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-6",
        "name": "RWA 💥",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://nexthope.pages.dev/rwa/",
        "urlVerified": true,
        "description": "RWA portal and resources by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-7",
        "name": "RWA ⚡",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://learnbyakp.site/rwa/batch",
        "urlVerified": true,
        "description": "RWA learning gateway by Learn By AKP.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-8",
        "name": "RWA 💎",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://spidy-rwa.vercel.app/",
        "urlVerified": true,
        "description": "RWA batch access and resources by Spidy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-9",
        "name": "RWA 🏆",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa.edustream.indevs.in/",
        "urlVerified": true,
        "description": "Rojgar With Ankit live streaming portal and batch learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-sumit-qzz",
        "name": "RWA 📚",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa.sumit.qzz.io/",
        "urlVerified": true,
        "description": "Rojgar With Ankit batches by Sumit.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-streamfiles",
        "name": "RWA 🎓",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa.streamfiles.eu.org/#all",
        "urlVerified": true,
        "description": "RWA streamfiles portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rojgar-with-ankit-workers-bat",
        "name": "Rojgar With Ankit BAT Portal",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://bat.rwaa.workers.dev/",
        "urlVerified": true,
        "description": "Rojgar With Ankit (RWA) fast batch and study material portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-primestudy",
        "name": "RWA PrimeStudy 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa.primestudy.live/",
        "urlVerified": true,
        "description": "Rojgar With Ankit live batches and lecture portal on PrimeStudy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-vercel-portal",
        "name": "Rojgar With Ankit Web 👨‍🏫",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rojgarwithankitt.vercel.app/",
        "urlVerified": true,
        "description": "Rojgar With Ankit official web portal for SSC, Police, Railway, and government exams on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-spidyuniverse-in",
        "name": "Rojgar With Ankit Spidy 👨‍🏫",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://rwa.spidyuniverse.in/",
        "urlVerified": true,
        "description": "Rojgar With Ankit portal on Spidy Universe for SSC, Police, Railway, and government exam batches.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-sangam-live",
        "name": "Rojgar With Ankit Sangam Live",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://sangam.free.nf/RWALIVE/",
        "urlVerified": true,
        "description": "Rojgar With Ankit live batch access and study resources on Sangam.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "rwa-deltaverse",
        "name": "Rojgar With Ankit DeltaVerse",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "portalUrl": "https://deltaverse.site/rwa",
        "urlVerified": true,
        "description": "Rojgar With Ankit live batches and government recruitment exam preparation on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 17,
    "rating": 4.9,
    "reviewCount": 3540,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "UP Police",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "rwa-1-batch",
        "title": "RWA OFFICIAL ✅",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Official"
        ],
        "subject": "Batches & Courses",
        "description": "Official portal for Rojgar With Ankit courses and test series.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://rojgarwithankit.co.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA OFFICIAL ✅"
      },
      {
        "id": "rwa-2-batch",
        "title": "RWA 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Study Bee Pro"
        ],
        "subject": "Batches & Courses",
        "description": "RWA batch access and learning resources by Study Bee Pro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa.studybeepro.site/rwax/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 🚀"
      },
      {
        "id": "rwa-3-batch",
        "title": "RWA 🔥",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Study Panda"
        ],
        "subject": "Batches & Courses",
        "description": "RWA courses and study material by Study Panda.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa.studypanda.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 🔥"
      },
      {
        "id": "rwa-4-batch",
        "title": "RWA 🌟",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Delta Study"
        ],
        "subject": "Batches & Courses",
        "description": "RWA batch access and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/rojgarwithankit",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 🌟"
      },
      {
        "id": "rwa-5-batch",
        "title": "RWA ✨",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Dream Study"
        ],
        "subject": "Batches & Courses",
        "description": "RWA batch access and learning resources by Dream Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa-dreamstudy.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA ✨"
      },
      {
        "id": "rwa-6-batch",
        "title": "RWA 💥",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Next Hope"
        ],
        "subject": "Batches & Courses",
        "description": "RWA portal and resources by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/rwa/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 💥"
      },
      {
        "id": "rwa-7-batch",
        "title": "RWA ⚡",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Learn By AKP"
        ],
        "subject": "Batches & Courses",
        "description": "RWA learning gateway by Learn By AKP.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnbyakp.site/rwa/batch",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA ⚡"
      },
      {
        "id": "rwa-8-batch",
        "title": "RWA 💎",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Spidy"
        ],
        "subject": "Batches & Courses",
        "description": "RWA batch access and resources by Spidy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://spidy-rwa.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 💎"
      },
      {
        "id": "rwa-9-batch",
        "title": "RWA 🏆",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Edustream"
        ],
        "subject": "Batches & Courses",
        "description": "Rojgar With Ankit live streaming portal and batch learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa.edustream.indevs.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 🏆"
      },
      {
        "id": "rwa-sumit-qzz-batch",
        "title": "RWA 📚",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Sumit"
        ],
        "subject": "Batches & Courses",
        "description": "Rojgar With Ankit batches by Sumit.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa.sumit.qzz.io/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 📚"
      },
      {
        "id": "rwa-streamfiles-batch",
        "title": "RWA 🎓",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Streamfiles"
        ],
        "subject": "Batches & Courses",
        "description": "RWA streamfiles portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa.streamfiles.eu.org/#all",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA 🎓"
      },
      {
        "id": "rojgar-with-ankit-workers-bat-batch",
        "title": "Rojgar With Ankit BAT Portal",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Govt Job Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Rojgar With Ankit",
          "RWA",
          "Govt Jobs"
        ],
        "subject": "Govt Job Exams",
        "description": "Rojgar With Ankit (RWA) fast batch and study material portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bat.rwaa.workers.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Rojgar With Ankit BAT Portal"
      },
      {
        "id": "rwa-primestudy-batch",
        "title": "RWA PrimeStudy 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "PrimeStudy",
          "Govt Jobs"
        ],
        "subject": "Batches & Courses",
        "description": "Rojgar With Ankit live batches and lecture portal on PrimeStudy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa.primestudy.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "RWA PrimeStudy 🚀"
      },
      {
        "id": "rwa-vercel-portal-batch",
        "title": "Rojgar With Ankit Web 👨‍🏫",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Vercel"
        ],
        "subject": "Batches & Courses",
        "description": "Rojgar With Ankit official web portal for SSC, Police, Railway, and government exams on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rojgarwithankitt.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Rojgar With Ankit Web 👨‍🏫"
      },
      {
        "id": "rwa-spidyuniverse-in-batch",
        "title": "Rojgar With Ankit Spidy 👨‍🏫",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "RWA",
          "Rojgar With Ankit",
          "Spidy Universe"
        ],
        "subject": "Batches & Courses",
        "description": "Rojgar With Ankit portal on Spidy Universe for SSC, Police, Railway, and government exam batches.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rwa.spidyuniverse.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Rojgar With Ankit Spidy 👨‍🏫"
      },
      {
        "id": "rwa-sangam-live-batch",
        "title": "Rojgar With Ankit Sangam Live",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Government Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Rojgar With Ankit",
          "RWA",
          "Sangam"
        ],
        "subject": "Government Exams",
        "description": "Rojgar With Ankit live batch access and study resources on Sangam.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sangam.free.nf/RWALIVE/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Rojgar With Ankit Sangam Live"
      },
      {
        "id": "rwa-deltaverse-batch",
        "title": "Rojgar With Ankit DeltaVerse",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2025-02-10-0.12268714003029602.jpeg",
        "targetExam": "Government Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Rojgar With Ankit",
          "RWA",
          "DeltaVerse"
        ],
        "subject": "Government Exams",
        "description": "Rojgar With Ankit live batches and government recruitment exam preparation on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltaverse.site/rwa",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Rojgar With Ankit DeltaVerse"
      }
    ],
    "resources": [
      {
        "id": "rojgar-with-ankit-res-1",
        "title": "Rojgar With Ankit Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Rojgar With Ankit.",
        "url": "https://rojgarwithankit.co.in/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "physics-wallah",
    "name": "Physics Wallah",
    "slug": "physics-wallah",
    "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
    "tagline": "Physics Wallah Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "PW JEE, NEET & Foundation",
    "exams": [
      "JEE Main & Adv",
      "NEET UG",
      "UPSC",
      "State Boards",
      "GATE"
    ],
    "brandColor": "#dc2626",
    "badgeText": "Physics Wallah",
    "description": "Comprehensive courses, interactive learning materials, and competitive exam coaching for JEE, NEET, and boards.",
    "officialWebsite": "https://www.pw.live/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.pw.live/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 51,
    "portals": [
      {
        "id": "pw-0",
        "name": "Physics Wallah OFFICIAL ✅",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://www.pw.live/",
        "urlVerified": true,
        "description": "Physics Wallah study portal batch access and learning resources.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-1",
        "name": "Physics Wallah 🚀",
        "logo": "https://i.postimg.cc/dQ75LH4X/image.png",
        "portalUrl": "https://deltastudy.fun/study-v2/batches",
        "urlVerified": true,
        "description": "Physics Wallah study portal batch access and learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-2",
        "name": "Physics Wallah 🔥",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://solaris-gateway-copy-f8171f72.base44.app/",
        "urlVerified": true,
        "description": "Physics Wallah learning gateway and batch portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-4",
        "name": "Physics Wallah ✨",
        "logo": "https://pwthor.live/logo.png",
        "portalUrl": "https://pwthor.live/study/batches",
        "urlVerified": true,
        "description": "Physics Wallah study batches and live lecture portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-5",
        "name": "Physics Wallah 💥",
        "logo": "https://eduzex.is-great.org/pw.png",
        "portalUrl": "https://eduzex-pw.pages.dev/batches",
        "urlVerified": true,
        "description": "Eduzex PW study portal and batch navigation.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-6",
        "name": "Physics Wallah ⚡",
        "logo": "https://i.ibb.co/NnTM9ZwF/studypanda-pw.png",
        "portalUrl": "https://physicswalla.studypanda.live/auth",
        "urlVerified": true,
        "description": "StudyPanda PW batch portal and study resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-7",
        "name": "Physics Wallah 💎",
        "logo": "https://i.ibb.co/h1YdY795/IMG-4134.png",
        "portalUrl": "https://pw.studybeepro.site/auth",
        "urlVerified": true,
        "description": "StudyBeePro Physics Wallah auth portal and student portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-8",
        "name": "Physics Wallah 🏆",
        "logo": "https://i.ibb.co/JRm7BVV3/file-00000000e590820b902af6a255a06b59.png",
        "portalUrl": "https://pw.studyparcham.in/#home-view",
        "urlVerified": true,
        "description": "StudyParcham Physics Wallah batch home view and portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-9",
        "name": "Physics Wallah 🎯",
        "logo": "https://files.catbox.moe/oqcdfv.png",
        "portalUrl": "https://pw.primestudy.live/auth",
        "urlVerified": true,
        "description": "PrimeStudy Physics Wallah portal and course dashboard.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-10",
        "name": "Physics Wallah 📚",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://nexthope.pages.dev/pw/",
        "urlVerified": true,
        "description": "Hope Study Physics Wallah portal and course dashboard.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-11",
        "name": "Physics Wallah 🎓",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://s4-cdn.samfygros.com/",
        "urlVerified": true,
        "description": "Physics Wallah study portal and learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-12",
        "name": "Physics Wallah 💡",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.learntopper.in/",
        "urlVerified": true,
        "description": "Physics Wallah study portal and learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-13",
        "name": "Physics Wallah 👑",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://vdk2-main-navy.vercel.app/",
        "urlVerified": true,
        "description": "Physics Wallah study portal and learning resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw4free",
        "name": "Physics Wallah 🌈",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw4free.in/study/batches",
        "urlVerified": true,
        "description": "Free study batches and resources for Physics Wallah.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vidcloud-eu",
        "name": "Physics Wallah 🔥",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://vidcloud.eu.org/#batches",
        "urlVerified": true,
        "description": "Video resources and batches for Physics Wallah.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-lectures-vercel",
        "name": "Physics Wallah 💻",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw-lectures.vercel.app/",
        "urlVerified": true,
        "description": "Access PW lectures and study materials via Vercel portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "mystudybuddy-pw",
        "name": "Physics Wallah 📱",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://www.mystudybuddy.in/batches.php",
        "urlVerified": true,
        "description": "Study Buddy batches and portal for Physics Wallah.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pwxlearnjh2",
        "name": "Physics Wallah 😎",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pwxlearnjh2.vercel.app/login?redirect=%2Fbatches",
        "urlVerified": true,
        "description": "PW resources by LearnJH alternate portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pwx-pages-dev",
        "name": "PWX Study Portal ⚡",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pwx.pages.dev/pw",
        "urlVerified": true,
        "description": "PWX Pages Dev instant batch access and Physics Wallah lecture player.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-muftukmall",
        "name": "PW Muftukmall 🛒",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.muftukmall.in/",
        "urlVerified": true,
        "description": "PW Muftukmall open educational batch portal and test series resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-studybison",
        "name": "StudyBison PW 🦬",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison Physics Wallah batches, notes, and lecture gateway.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "akki-studyx-batches",
        "name": "Akki StudyX Batches 🚀",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://akkistudyx.in/batches",
        "urlVerified": true,
        "description": "Akki StudyX direct PW batch access portal with lecture streaming.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edufreek-pw-generate",
        "name": "EduFreek PW Generator ⚡",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://edufreekpw.infinityfreeapp.com/generate.php",
        "urlVerified": true,
        "description": "EduFreek PW stream link generator and batch lecture unlocking tool.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edufreek-main",
        "name": "EduFreek Portal 🌟",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://edufreek.infinityfreeapp.com/?i=1",
        "urlVerified": true,
        "description": "EduFreek centralized free study portal and multi-platform batch directory.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "studyratna-s2-cdn",
        "name": "StudyRatna CDN 💎",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://s2-cdn.studyratna.cc/",
        "urlVerified": true,
        "description": "StudyRatna high-speed CDN streaming server for Physics Wallah lectures and resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-rolexcoderz",
        "name": "PW Rolex Coderz",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://rolexcoderz.com/PW/",
        "urlVerified": true,
        "description": "Physics Wallah resources by Rolex Coderz.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-marco",
        "name": "PW Marco",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://www.pwmarco.site/study/batches",
        "urlVerified": true,
        "description": "Physics Wallah batch portal by PW Marco.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-testmain",
        "name": "PW Test Main",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pwtestmainnewsite.vercel.app/auth",
        "urlVerified": true,
        "description": "Physics Wallah auth portal.",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-studyspark",
        "name": "PW StudySpark Verify",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://studyspark.study/verify",
        "urlVerified": true,
        "description": "StudySpark verification portal for Physics Wallah.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-learnxpw-batches",
        "name": "PW LearnX Batches",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://www.learnxpw.site/study/batches",
        "urlVerified": true,
        "description": "Physics Wallah batches and study portal on LearnX.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-marco-study",
        "name": "PW Marco Study",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://www.pwmarco.site/study",
        "urlVerified": true,
        "description": "Physics Wallah Marco study batches, lecture video player and learning material.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-studyhulk",
        "name": "StudyHulk PW Portal",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://studyhulk.primestudy.live/auth",
        "urlVerified": true,
        "description": "Physics Wallah StudyHulk portal for batch access and test series.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-universe-workers",
        "name": "Universe PW Portal",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://bat.unuversepw.workers.dev/",
        "urlVerified": true,
        "description": "Universe PW high-speed Cloudflare worker batch portal and lecture streams.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-eduzex",
        "name": "Eduzex PW Portal",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://eduzex-pw.pages.dev/",
        "urlVerified": true,
        "description": "Eduzex PW Cloudflare Pages student portal for Physics Wallah lectures and notes.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-sumit-qzz",
        "name": "Physics Wallah Sumit 🚀",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.sumit.qzz.io/",
        "urlVerified": true,
        "description": "Physics Wallah study portal and batch lectures access by Sumit.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-studyapkmod",
        "name": "Physics Wallah Mod Portal 🌟",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://studyapkmodpw.vercel.app/",
        "urlVerified": true,
        "description": "Physics Wallah batch learning portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-learnex",
        "name": "Physics Wallah LearnEx 🚀",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://learnex.vercel.app/PW",
        "urlVerified": true,
        "description": "Physics Wallah courses and batch learning portal on LearnEx Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-14",
        "name": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://physicswallah.studybeepro.site/auth",
        "urlVerified": true,
        "description": "Physics Wallah by StudyBeePro",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-15",
        "name": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://thescholarverse.site/study/pw/batches",
        "urlVerified": true,
        "description": "Physics Wallah by TheScholarVerse",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-16",
        "name": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.gemtara.in/study/batches",
        "urlVerified": true,
        "description": "Physics Wallah by Gemtara",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-17",
        "name": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pwx.pages.dev/access",
        "urlVerified": true,
        "description": "Physics Wallah by PWX",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-nexthope-auth",
        "name": "Physics Wallah NextHope",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.nexthope.site/auth",
        "urlVerified": true,
        "description": "Physics Wallah student batch portal and authentication access on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-studyhulk-primestudy",
        "name": "StudyHulk PW PrimeStudy",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://studyhulk.primestudy.live",
        "urlVerified": true,
        "description": "Physics Wallah PrimeStudy live portal for batch access and test series.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-preppro-network",
        "name": "PW PrepPro Network",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://preppronetwork.vercel.app/pw",
        "urlVerified": true,
        "description": "Physics Wallah study portal, video lectures, and batch access on PrepPro Network.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-rarestudy-batches",
        "name": "PW RareStudy Batches",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://rarestudy.testuk.org/batches",
        "urlVerified": true,
        "description": "Physics Wallah competitive examination batches and study portal on RareStudy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-studyrays",
        "name": "PW StudyRays",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://studyrays.cc/",
        "urlVerified": true,
        "description": "Physics Wallah study batches, video lectures, and learning resources on StudyRays.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-deltaverse-batches",
        "name": "PW DeltaVerse Batches",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.deltaverse.site/study/batches",
        "urlVerified": true,
        "description": "Physics Wallah comprehensive study batches and portal on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-deltastudy-in",
        "name": "Physics Wallah Delta Study",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://www.deltastudy.in/",
        "urlVerified": true,
        "description": "Physics Wallah batches, notes, and study resources on Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-nexusstudy-primestudy",
        "name": "Physics Wallah Nexus Study",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://nexusstudy.primestudy.live/auth",
        "urlVerified": true,
        "description": "Physics Wallah authentication portal and course batches on Nexus Study PrimeStudy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-lrnt-ccwu",
        "name": "Physics Wallah LRNT",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://pw.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "Physics Wallah digital learning batches and study material on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "pw-lrnt-us-ci",
        "name": "Physics Wallah LRNT Auth",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "portalUrl": "https://lrnt.us.ci/auth",
        "urlVerified": true,
        "description": "Physics Wallah authentication and batch access portal on LRNT US CI.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 51,
    "rating": 4.9,
    "reviewCount": 7620,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "JEE Main & Adv",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "pw-0-batch",
        "title": "Physics Wallah OFFICIAL ✅",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 0",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study portal batch access and learning resources.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.pw.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah OFFICIAL ✅"
      },
      {
        "id": "pw-1-batch",
        "title": "Physics Wallah 🚀",
        "logo": "https://i.postimg.cc/dQ75LH4X/image.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 1",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study portal batch access and learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/study-v2/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 🚀"
      },
      {
        "id": "pw-2-batch",
        "title": "Physics Wallah 🔥",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 2",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah learning gateway and batch portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://solaris-gateway-copy-f8171f72.base44.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 🔥"
      },
      {
        "id": "pw-4-batch",
        "title": "Physics Wallah ✨",
        "logo": "https://pwthor.live/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 4",
          "Live Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study batches and live lecture portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pwthor.live/study/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah ✨"
      },
      {
        "id": "pw-5-batch",
        "title": "Physics Wallah 💥",
        "logo": "https://eduzex.is-great.org/pw.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 5",
          "Eduzex"
        ],
        "subject": "Batches & Courses",
        "description": "Eduzex PW study portal and batch navigation.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://eduzex-pw.pages.dev/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 💥"
      },
      {
        "id": "pw-6-batch",
        "title": "Physics Wallah ⚡",
        "logo": "https://i.ibb.co/NnTM9ZwF/studypanda-pw.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 6",
          "StudyPanda"
        ],
        "subject": "Batches & Courses",
        "description": "StudyPanda PW batch portal and study resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://physicswalla.studypanda.live/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah ⚡"
      },
      {
        "id": "pw-7-batch",
        "title": "Physics Wallah 💎",
        "logo": "https://i.ibb.co/h1YdY795/IMG-4134.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 7",
          "StudyBeePro"
        ],
        "subject": "Batches & Courses",
        "description": "StudyBeePro Physics Wallah auth portal and student portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.studybeepro.site/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 💎"
      },
      {
        "id": "pw-8-batch",
        "title": "Physics Wallah 🏆",
        "logo": "https://i.ibb.co/JRm7BVV3/file-00000000e590820b902af6a255a06b59.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 8",
          "StudyParcham"
        ],
        "subject": "Batches & Courses",
        "description": "StudyParcham Physics Wallah batch home view and portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.studyparcham.in/#home-view",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 🏆"
      },
      {
        "id": "pw-9-batch",
        "title": "Physics Wallah 🎯",
        "logo": "https://files.catbox.moe/oqcdfv.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 9",
          "PrimeStudy"
        ],
        "subject": "Batches & Courses",
        "description": "PrimeStudy Physics Wallah portal and course dashboard.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.primestudy.live/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 🎯"
      },
      {
        "id": "pw-10-batch",
        "title": "Physics Wallah 📚",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 10",
          "HopeStudy"
        ],
        "subject": "Batches & Courses",
        "description": "Hope Study Physics Wallah portal and course dashboard.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/pw/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 📚"
      },
      {
        "id": "pw-11-batch",
        "title": "Physics Wallah 🎓",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 11",
          "Samfygros"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study portal and learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://s4-cdn.samfygros.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 🎓"
      },
      {
        "id": "pw-12-batch",
        "title": "Physics Wallah 💡",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 12",
          "Learntopper"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study portal and learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 💡"
      },
      {
        "id": "pw-13-batch",
        "title": "Physics Wallah 👑",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW 13",
          "VDK2"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study portal and learning resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vdk2-main-navy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 👑"
      },
      {
        "id": "pw4free-batch",
        "title": "Physics Wallah 🌈",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Batches",
          "Free"
        ],
        "subject": "Batches & Courses",
        "description": "Free study batches and resources for Physics Wallah.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw4free.in/study/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 🌈"
      },
      {
        "id": "vidcloud-eu-batch",
        "title": "Physics Wallah 🔥",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Video Lectures",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Lectures",
          "Video"
        ],
        "subject": "Video Lectures",
        "description": "Video resources and batches for Physics Wallah.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vidcloud.eu.org/#batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 🔥"
      },
      {
        "id": "pw-lectures-vercel-batch",
        "title": "Physics Wallah 💻",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Video Lectures",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Lectures",
          "Portal"
        ],
        "subject": "Video Lectures",
        "description": "Access PW lectures and study materials via Vercel portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw-lectures.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 💻"
      },
      {
        "id": "mystudybuddy-pw-batch",
        "title": "Physics Wallah 📱",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Batches",
          "Study Buddy"
        ],
        "subject": "Batches & Courses",
        "description": "Study Buddy batches and portal for Physics Wallah.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.mystudybuddy.in/batches.php",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 📱"
      },
      {
        "id": "pwxlearnjh2-batch",
        "title": "Physics Wallah 😎",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "LearnJH",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "PW resources by LearnJH alternate portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pwxlearnjh2.vercel.app/login?redirect=%2Fbatches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah 😎"
      },
      {
        "id": "pwx-pages-dev-batch",
        "title": "PWX Study Portal ⚡",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PWX",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "PWX Pages Dev instant batch access and Physics Wallah lecture player.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pwx.pages.dev/pw",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PWX Study Portal ⚡"
      },
      {
        "id": "pw-muftukmall-batch",
        "title": "PW Muftukmall 🛒",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Muftukmall",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "PW Muftukmall open educational batch portal and test series resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.muftukmall.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW Muftukmall 🛒"
      },
      {
        "id": "pw-studybison-batch",
        "title": "StudyBison PW 🦬",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "StudyBison",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "StudyBison Physics Wallah batches, notes, and lecture gateway.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison PW 🦬"
      },
      {
        "id": "akki-studyx-batches-batch",
        "title": "Akki StudyX Batches 🚀",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Akki StudyX",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Akki StudyX direct PW batch access portal with lecture streaming.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://akkistudyx.in/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Akki StudyX Batches 🚀"
      },
      {
        "id": "edufreek-pw-generate-batch",
        "title": "EduFreek PW Generator ⚡",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "EduFreek",
          "Generator"
        ],
        "subject": "Batches & Courses",
        "description": "EduFreek PW stream link generator and batch lecture unlocking tool.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edufreekpw.infinityfreeapp.com/generate.php",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "EduFreek PW Generator ⚡"
      },
      {
        "id": "edufreek-main-batch",
        "title": "EduFreek Portal 🌟",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "EduFreek",
          "Free Batches"
        ],
        "subject": "Batches & Courses",
        "description": "EduFreek centralized free study portal and multi-platform batch directory.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edufreek.infinityfreeapp.com/?i=1",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "EduFreek Portal 🌟"
      },
      {
        "id": "studyratna-s2-cdn-batch",
        "title": "StudyRatna CDN 💎",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Video Lectures",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "StudyRatna",
          "CDN"
        ],
        "subject": "Video Lectures",
        "description": "StudyRatna high-speed CDN streaming server for Physics Wallah lectures and resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://s2-cdn.studyratna.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyRatna CDN 💎"
      },
      {
        "id": "pw-rolexcoderz-batch",
        "title": "PW Rolex Coderz",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Batches",
          "Rolex Coderz"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah resources by Rolex Coderz.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rolexcoderz.com/PW/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW Rolex Coderz"
      },
      {
        "id": "pw-marco-batch",
        "title": "PW Marco",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Batches",
          "PW Marco"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah batch portal by PW Marco.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.pwmarco.site/study/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW Marco"
      },
      {
        "id": "pw-testmain-batch",
        "title": "PW Test Main",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Auth",
          "Portal"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah auth portal.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://pwtestmainnewsite.vercel.app/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW Test Main"
      },
      {
        "id": "pw-studyspark-batch",
        "title": "PW StudySpark Verify",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "StudySpark",
          "Verify"
        ],
        "subject": "Batches & Courses",
        "description": "StudySpark verification portal for Physics Wallah.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyspark.study/verify",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW StudySpark Verify"
      },
      {
        "id": "pw-learnxpw-batches-batch",
        "title": "PW LearnX Batches",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "JEE & NEET Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "LearnX"
        ],
        "subject": "JEE & NEET Prep",
        "description": "Physics Wallah batches and study portal on LearnX.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.learnxpw.site/study/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW LearnX Batches"
      },
      {
        "id": "pw-marco-study-batch",
        "title": "PW Marco Study",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW Marco",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah Marco study batches, lecture video player and learning material.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.pwmarco.site/study",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW Marco Study"
      },
      {
        "id": "pw-studyhulk-batch",
        "title": "StudyHulk PW Portal",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "StudyHulk",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah StudyHulk portal for batch access and test series.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyhulk.primestudy.live/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyHulk PW Portal"
      },
      {
        "id": "pw-universe-workers-batch",
        "title": "Universe PW Portal",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Universe PW",
          "Workers"
        ],
        "subject": "Batches & Courses",
        "description": "Universe PW high-speed Cloudflare worker batch portal and lecture streams.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bat.unuversepw.workers.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Universe PW Portal"
      },
      {
        "id": "pw-eduzex-batch",
        "title": "Eduzex PW Portal",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Eduzex",
          "Cloudflare Pages"
        ],
        "subject": "Batches & Courses",
        "description": "Eduzex PW Cloudflare Pages student portal for Physics Wallah lectures and notes.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://eduzex-pw.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Eduzex PW Portal"
      },
      {
        "id": "pw-sumit-qzz-batch",
        "title": "Physics Wallah Sumit 🚀",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "Sumit"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study portal and batch lectures access by Sumit.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.sumit.qzz.io/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah Sumit 🚀"
      },
      {
        "id": "pw-studyapkmod-batch",
        "title": "Physics Wallah Mod Portal 🌟",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "Vercel"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah batch learning portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmodpw.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah Mod Portal 🌟"
      },
      {
        "id": "pw-learnex-batch",
        "title": "Physics Wallah LearnEx 🚀",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "LearnEx"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah courses and batch learning portal on LearnEx Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnex.vercel.app/PW",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah LearnEx 🚀"
      },
      {
        "id": "pw-14-batch",
        "title": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "StudyBeePro"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah by StudyBeePro",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://physicswallah.studybeepro.site/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah"
      },
      {
        "id": "pw-15-batch",
        "title": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "TheScholarVerse"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah by TheScholarVerse",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://thescholarverse.site/study/pw/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah"
      },
      {
        "id": "pw-16-batch",
        "title": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "Gemtara"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah by Gemtara",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.gemtara.in/study/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah"
      },
      {
        "id": "pw-17-batch",
        "title": "Physics Wallah",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PWX"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah by PWX",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://pwx.pages.dev/access",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah"
      },
      {
        "id": "pw-nexthope-auth-batch",
        "title": "Physics Wallah NextHope",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "NextHope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah student batch portal and authentication access on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.nexthope.site/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah NextHope"
      },
      {
        "id": "pw-studyhulk-primestudy-batch",
        "title": "StudyHulk PW PrimeStudy",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "StudyHulk",
          "PrimeStudy"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah PrimeStudy live portal for batch access and test series.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyhulk.primestudy.live",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyHulk PW PrimeStudy"
      },
      {
        "id": "pw-preppro-network-batch",
        "title": "PW PrepPro Network",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "PrepPro"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study portal, video lectures, and batch access on PrepPro Network.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://preppronetwork.vercel.app/pw",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW PrepPro Network"
      },
      {
        "id": "pw-rarestudy-batches-batch",
        "title": "PW RareStudy Batches",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "RareStudy"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah competitive examination batches and study portal on RareStudy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rarestudy.testuk.org/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW RareStudy Batches"
      },
      {
        "id": "pw-studyrays-batch",
        "title": "PW StudyRays",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "StudyRays"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah study batches, video lectures, and learning resources on StudyRays.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyrays.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW StudyRays"
      },
      {
        "id": "pw-deltaverse-batches-batch",
        "title": "PW DeltaVerse Batches",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "DeltaVerse"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah comprehensive study batches and portal on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.deltaverse.site/study/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "PW DeltaVerse Batches"
      },
      {
        "id": "pw-deltastudy-in-batch",
        "title": "Physics Wallah Delta Study",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "Delta Study"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah batches, notes, and study resources on Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.deltastudy.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah Delta Study"
      },
      {
        "id": "pw-nexusstudy-primestudy-batch",
        "title": "Physics Wallah Nexus Study",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "Nexus Study"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah authentication portal and course batches on Nexus Study PrimeStudy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexusstudy.primestudy.live/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah Nexus Study"
      },
      {
        "id": "pw-lrnt-ccwu-batch",
        "title": "Physics Wallah LRNT",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "LRNT"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah digital learning batches and study material on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://pw.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah LRNT"
      },
      {
        "id": "pw-lrnt-us-ci-batch",
        "title": "Physics Wallah LRNT Auth",
        "logo": "https://static.pw.live/5eb393ee95fab7468a79d189/GLOBAL_CMS/f10eb934-422b-448f-aa2c-157078acb032.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Physics Wallah",
          "PW",
          "LRNT"
        ],
        "subject": "Batches & Courses",
        "description": "Physics Wallah authentication and batch access portal on LRNT US CI.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://lrnt.us.ci/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Physics Wallah LRNT Auth"
      }
    ],
    "resources": [
      {
        "id": "physics-wallah-res-1",
        "title": "Physics Wallah Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Physics Wallah.",
        "url": "https://www.pw.live/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "target-board",
    "name": "Target Board",
    "slug": "target-board",
    "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
    "tagline": "Target Board Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "Target Board Matric & Inter",
    "exams": [
      "Bihar Board Matric",
      "Class 12th Arts/Science",
      "Toppers Batch"
    ],
    "brandColor": "#dc2626",
    "badgeText": "Target Board",
    "description": "Dedicated preparation for board exams.",
    "officialWebsite": "https://targetboard.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://targetboard.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 5,
    "portals": [
      {
        "id": "official-target-board",
        "name": "Target Board OFFICIAL ✅",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "portalUrl": "https://targetboard.com",
        "urlVerified": true,
        "description": "Official Target Board preparation portal.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "tgb-1",
        "name": "Target Board 🚀",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "portalUrl": "https://nexthope.pages.dev/targetboard/",
        "urlVerified": true,
        "description": "Target Board exam preparation and lecture portal by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "tgb-2",
        "name": "Target Board App (AS Multiverse) 📱",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "portalUrl": "https://asmultiverse.com/?tab=apps&app=694690cbe1df5128eacc5caa",
        "urlVerified": true,
        "description": "Target Board web app and learning portal access via AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "target-board-1",
        "name": "Target Board",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "portalUrl": "https://tb.studybeepro.site/",
        "urlVerified": true,
        "description": "Target Board by StudyBeePro",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "target-board-nexthope",
        "name": "Target Board NextHope",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "portalUrl": "https://tb.nexthope.site/",
        "urlVerified": true,
        "description": "Target Board state board exam preparation portal on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 5,
    "rating": 5,
    "reviewCount": 2100,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Bihar Board Matric",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-target-board-batch",
        "title": "Target Board OFFICIAL ✅",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Target Board",
          "Official",
          "Board Exams"
        ],
        "subject": "Official Platform",
        "description": "Official Target Board preparation portal.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://targetboard.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Target Board OFFICIAL ✅"
      },
      {
        "id": "tgb-1-batch",
        "title": "Target Board 🚀",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "targetExam": "Board Exam Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Target Board",
          "Next Hope",
          "Board Prep"
        ],
        "subject": "Board Exam Prep",
        "description": "Target Board exam preparation and lecture portal by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/targetboard/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Target Board 🚀"
      },
      {
        "id": "tgb-2-batch",
        "title": "Target Board App (AS Multiverse) 📱",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "targetExam": "Web App & Portal",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Target Board",
          "AS Multiverse",
          "Board Prep"
        ],
        "subject": "Web App & Portal",
        "description": "Target Board web app and learning portal access via AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.com/?tab=apps&app=694690cbe1df5128eacc5caa",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Target Board App (AS Multiverse) 📱"
      },
      {
        "id": "target-board-1-batch",
        "title": "Target Board",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Target Board",
          "StudyBeePro"
        ],
        "subject": "Batches & Courses",
        "description": "Target Board by StudyBeePro",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://tb.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Target Board"
      },
      {
        "id": "target-board-nexthope-batch",
        "title": "Target Board NextHope",
        "logo": "https://i.postimg.cc/MZy8cDF6/download.jpg",
        "targetExam": "Board Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Target Board",
          "NextHope",
          "Matric"
        ],
        "subject": "Board Exams",
        "description": "Target Board state board exam preparation portal on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://tb.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Target Board NextHope"
      }
    ],
    "resources": [
      {
        "id": "target-board-res-1",
        "title": "Target Board Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Target Board.",
        "url": "https://targetboard.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "test-book",
    "name": "Test Book",
    "slug": "test-book",
    "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
    "tagline": "Test Book Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Testbook Pass & Mock Tests",
    "exams": [
      "SSC Mock Tests",
      "Railway Tests",
      "Banking Pass",
      "State Tests"
    ],
    "brandColor": "#059669",
    "badgeText": "Test Book",
    "description": "Comprehensive test preparation and mock exams for competitive exams.",
    "officialWebsite": "https://testbook.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://testbook.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 5,
    "portals": [
      {
        "id": "official-test-book",
        "name": "Test Book OFFICIAL ✅",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "portalUrl": "https://testbook.com",
        "urlVerified": true,
        "description": "Official Test Book comprehensive test preparation platform.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "tb-1",
        "name": "Test Book 🚀",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "portalUrl": "https://test.pwthor.live/",
        "urlVerified": true,
        "description": "Test Book online practice tests and mock examination series.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "tb-2",
        "name": "Test Book 🔥",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "portalUrl": "https://repeatermock.com/",
        "urlVerified": true,
        "description": "Test Book practice portal for repeaters and competitive exams.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "testbook-sumit-qzz",
        "name": "Test Book Sumit 🚀",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "portalUrl": "https://test.sumit.qzz.io/",
        "urlVerified": true,
        "description": "Test Book mock tests and practice question portal by Sumit.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "testbook-sdvmock",
        "name": "Test Book SDV Mock",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "portalUrl": "https://sdvmock.page.gd/?i=1",
        "urlVerified": true,
        "description": "Test Book test series, mock exams, and practice tests portal on SDV Mock.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 5,
    "rating": 5,
    "reviewCount": 2100,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SSC Mock Tests",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-test-book-batch",
        "title": "Test Book OFFICIAL ✅",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Book",
          "Official",
          "Mock Exams"
        ],
        "subject": "Official Platform",
        "description": "Official Test Book comprehensive test preparation platform.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://testbook.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Book OFFICIAL ✅"
      },
      {
        "id": "tb-1-batch",
        "title": "Test Book 🚀",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "targetExam": "Test Series & Mocks",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Book",
          "PW Thor",
          "Mock Tests"
        ],
        "subject": "Test Series & Mocks",
        "description": "Test Book online practice tests and mock examination series.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://test.pwthor.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Book 🚀"
      },
      {
        "id": "tb-2-batch",
        "title": "Test Book 🔥",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "targetExam": "Test Series & Mocks",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Book",
          "Repeater Mock",
          "Practice"
        ],
        "subject": "Test Series & Mocks",
        "description": "Test Book practice portal for repeaters and competitive exams.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://repeatermock.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Book 🔥"
      },
      {
        "id": "testbook-sumit-qzz-batch",
        "title": "Test Book Sumit 🚀",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "targetExam": "Mock Tests & Practice",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Book",
          "Testbook",
          "Sumit"
        ],
        "subject": "Mock Tests & Practice",
        "description": "Test Book mock tests and practice question portal by Sumit.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://test.sumit.qzz.io/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Book Sumit 🚀"
      },
      {
        "id": "testbook-sdvmock-batch",
        "title": "Test Book SDV Mock",
        "logo": "https://i.postimg.cc/bvrQ7HjG/images-(3).png",
        "targetExam": "Test Series & Mock Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Book",
          "SDV Mock",
          "Mock Tests"
        ],
        "subject": "Test Series & Mock Exams",
        "description": "Test Book test series, mock exams, and practice tests portal on SDV Mock.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sdvmock.page.gd/?i=1",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Book SDV Mock"
      }
    ],
    "resources": [
      {
        "id": "test-book-res-1",
        "title": "Test Book Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Test Book.",
        "url": "https://testbook.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "test-ranker",
    "name": "Test Ranker",
    "slug": "test-ranker",
    "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
    "tagline": "Test Ranker Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Test Series & Rank Booster",
    "exams": [
      "National Mock Tests",
      "Rank Analytics",
      "Previous Papers"
    ],
    "brandColor": "#7c3aed",
    "badgeText": "Test Ranker",
    "description": "Boost your rank with exclusive test series.",
    "officialWebsite": "https://www.testranking.in/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.testranking.in/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 4,
    "portals": [
      {
        "id": "official-test-ranker",
        "name": "Test Ranker OFFICIAL ✅",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "portalUrl": "https://www.testranking.in/",
        "urlVerified": true,
        "description": "Official Test Ranker exclusive test series platform.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "tr-1",
        "name": "Test Ranker 🚀",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "portalUrl": "https://testranking.examsaathi.site/",
        "urlVerified": true,
        "description": "Test Ranker test series and online ranking platform.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "test-ranker-sumit-qzz",
        "name": "Test Ranker Sumit 🚀",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "portalUrl": "https://testranking.sumit.qzz.io/",
        "urlVerified": true,
        "description": "Test Ranker test series and ranking assessment portal by Sumit.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "test-ranker-free-vercel",
        "name": "Test Ranker Free Portal 🌟",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "portalUrl": "https://testrankingfree.vercel.app/",
        "urlVerified": true,
        "description": "Free test series and competitive ranking platform on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 4,
    "rating": 5,
    "reviewCount": 1980,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "National Mock Tests",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-test-ranker-batch",
        "title": "Test Ranker OFFICIAL ✅",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Ranker",
          "Official",
          "Test Series"
        ],
        "subject": "Official Platform",
        "description": "Official Test Ranker exclusive test series platform.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.testranking.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Ranker OFFICIAL ✅"
      },
      {
        "id": "tr-1-batch",
        "title": "Test Ranker 🚀",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "targetExam": "Test Series & Ranking",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Ranker",
          "Examsaathi",
          "Tests"
        ],
        "subject": "Test Series & Ranking",
        "description": "Test Ranker test series and online ranking platform.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://testranking.examsaathi.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Ranker 🚀"
      },
      {
        "id": "test-ranker-sumit-qzz-batch",
        "title": "Test Ranker Sumit 🚀",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "targetExam": "Rank & Test Series",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Ranker",
          "Sumit",
          "Test Series"
        ],
        "subject": "Rank & Test Series",
        "description": "Test Ranker test series and ranking assessment portal by Sumit.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://testranking.sumit.qzz.io/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Ranker Sumit 🚀"
      },
      {
        "id": "test-ranker-free-vercel-batch",
        "title": "Test Ranker Free Portal 🌟",
        "logo": "https://i.postimg.cc/1XBncYSw/images-(5).jpg",
        "targetExam": "Rank & Test Series",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Test Ranker",
          "Vercel",
          "Free Tests"
        ],
        "subject": "Rank & Test Series",
        "description": "Free test series and competitive ranking platform on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://testrankingfree.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Test Ranker Free Portal 🌟"
      }
    ],
    "resources": [
      {
        "id": "test-ranker-res-1",
        "title": "Test Ranker Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Test Ranker.",
        "url": "https://www.testranking.in/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "taiyari-karlo",
    "name": "Taiyari Karlo",
    "slug": "taiyari-karlo",
    "logo": "https://www.taiyarikarlo.com/tenants/taiyarikarlo/logo.jpeg",
    "tagline": "Taiyari Karlo Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Rajasthan & State Competitions",
    "exams": [
      "Rajasthan Police",
      "REET",
      "CET",
      "Patwar"
    ],
    "brandColor": "#ea580c",
    "badgeText": "Taiyari Karlo",
    "description": "Online preparation portal and learning platform for government recruitment and competitive exams.",
    "officialWebsite": "https://www.taiyarikarlo.com/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.taiyarikarlo.com/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "official-taiyari-karlo",
        "name": "Taiyari Karlo OFFICIAL ✅",
        "logo": "https://www.taiyarikarlo.com/tenants/taiyarikarlo/logo.jpeg",
        "portalUrl": "https://www.taiyarikarlo.com/",
        "urlVerified": true,
        "description": "Official Taiyari Karlo learning portal for government and competitive exams.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "taiyari-karlo-mod",
        "name": "Taiyari Karlo Portal 🚀",
        "logo": "https://www.taiyarikarlo.com/tenants/taiyarikarlo/logo.jpeg",
        "portalUrl": "https://studyapkmod-taiyari.vercel.app/login",
        "urlVerified": true,
        "description": "Taiyari Karlo batch access and student login portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 5,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Rajasthan Police",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-taiyari-karlo-batch",
        "title": "Taiyari Karlo OFFICIAL ✅",
        "logo": "https://www.taiyarikarlo.com/tenants/taiyarikarlo/logo.jpeg",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Taiyari Karlo",
          "Official",
          "Govt Exams"
        ],
        "subject": "Official Platform",
        "description": "Official Taiyari Karlo learning portal for government and competitive exams.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.taiyarikarlo.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Taiyari Karlo OFFICIAL ✅"
      },
      {
        "id": "taiyari-karlo-mod-batch",
        "title": "Taiyari Karlo Portal 🚀",
        "logo": "https://www.taiyarikarlo.com/tenants/taiyarikarlo/logo.jpeg",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Taiyari Karlo",
          "Vercel",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Taiyari Karlo batch access and student login portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmod-taiyari.vercel.app/login",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Taiyari Karlo Portal 🚀"
      }
    ],
    "resources": [
      {
        "id": "taiyari-karlo-res-1",
        "title": "Taiyari Karlo Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Taiyari Karlo.",
        "url": "https://www.taiyarikarlo.com/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "science-and-fun",
    "name": "Science And Fun",
    "slug": "science-and-fun",
    "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
    "tagline": "Science & Fun Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "Science & Fun Foundation",
    "exams": [
      "Class 9th",
      "Class 10th",
      "Class 11th & 12th Science"
    ],
    "brandColor": "#d97706",
    "badgeText": "Science & Fun",
    "description": "Practical and engaging science learning platform making physics, chemistry, and biology intuitive for students.",
    "officialWebsite": "https://scienceandfun.live/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://scienceandfun.live/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 6,
    "portals": [
      {
        "id": "sf-1",
        "name": "Science And Fun OFFICIAL ✅",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "portalUrl": "https://scienceandfun.live/",
        "urlVerified": true,
        "description": "Official portal for Science and Fun batches and resources.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sf-2",
        "name": "Science And Fun 🚀",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "portalUrl": "https://deltastudy.fun/scienceandfun",
        "urlVerified": true,
        "description": "Science and Fun batch access and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "science-and-fun-1",
        "name": "Science and Fun",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "portalUrl": "https://scienceandfun.studybeepro.site/",
        "urlVerified": true,
        "description": "Science and Fun by StudyBeePro",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "science-and-fun-2",
        "name": "Science and Fun",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "portalUrl": "https://studypanda.live/scienceandfun",
        "urlVerified": true,
        "description": "Science and Fun by StudyPanda",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "science-and-fun-nexthope",
        "name": "Science and Fun NextHope",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "portalUrl": "https://scienceandfun.nexthope.site/",
        "urlVerified": true,
        "description": "Science and Fun interactive learning and batch portal on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "science-and-fun-deltaverse",
        "name": "Science and Fun DeltaVerse",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "portalUrl": "https://deltaverse.site/scienceandfun",
        "urlVerified": true,
        "description": "Science and Fun interactive learning and batch portal on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 6,
    "rating": 4.9,
    "reviewCount": 2220,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Class 9th",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "sf-1-batch",
        "title": "Science And Fun OFFICIAL ✅",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Science And Fun",
          "Science & Fun",
          "Official"
        ],
        "subject": "Batches & Courses",
        "description": "Official portal for Science and Fun batches and resources.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://scienceandfun.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Science And Fun OFFICIAL ✅"
      },
      {
        "id": "sf-2-batch",
        "title": "Science And Fun 🚀",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Science And Fun",
          "Science & Fun",
          "Delta Study"
        ],
        "subject": "Batches & Courses",
        "description": "Science and Fun batch access and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/scienceandfun",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Science And Fun 🚀"
      },
      {
        "id": "science-and-fun-1-batch",
        "title": "Science and Fun",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Science and Fun",
          "StudyBeePro"
        ],
        "subject": "Batches & Courses",
        "description": "Science and Fun by StudyBeePro",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://scienceandfun.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Science and Fun"
      },
      {
        "id": "science-and-fun-2-batch",
        "title": "Science and Fun",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Science and Fun",
          "StudyPanda"
        ],
        "subject": "Batches & Courses",
        "description": "Science and Fun by StudyPanda",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://studypanda.live/scienceandfun",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Science and Fun"
      },
      {
        "id": "science-and-fun-nexthope-batch",
        "title": "Science and Fun NextHope",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Science and Fun",
          "NextHope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Science and Fun interactive learning and batch portal on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://scienceandfun.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Science and Fun NextHope"
      },
      {
        "id": "science-and-fun-deltaverse-batch",
        "title": "Science and Fun DeltaVerse",
        "logo": "https://appx-wsb-gcp-mcdn.akamai.net.in/subject/2022-11-09-0.46231084813575274.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Science and Fun",
          "DeltaVerse",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Science and Fun interactive learning and batch portal on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltaverse.site/scienceandfun",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Science and Fun DeltaVerse"
      }
    ],
    "resources": [
      {
        "id": "science-and-fun-res-1",
        "title": "Science And Fun Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Science And Fun.",
        "url": "https://scienceandfun.live/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "toppers-wisdom",
    "name": "Topper's Wisdom",
    "slug": "toppers-wisdom",
    "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
    "tagline": "Topper's Wisdom Learning Hub",
    "establishedYear": 2021,
    "category": "medical-pg",
    "categoryLabel": "Nursing & Medical Entrance",
    "exams": [
      "NORCET Nursing",
      "CHO",
      "Medical Entrance",
      "Paramedical"
    ],
    "brandColor": "#e11d48",
    "badgeText": "Topper's Wisdom",
    "description": "Learn strategies, insights, and study techniques straight from top achievers.",
    "officialWebsite": "https://topperswisdom.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://topperswisdom.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 4,
    "portals": [
      {
        "id": "official-toppers-wisdom",
        "name": "Topper's Wisdom OFFICIAL ✅",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "portalUrl": "https://topperswisdom.com",
        "urlVerified": true,
        "description": "Official Topper's Wisdom platform for strategies and study techniques.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "tw-1",
        "name": "Topper's Wisdom 🚀",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "portalUrl": "https://studyapkmod-toperwis.vercel.app/",
        "urlVerified": true,
        "description": "Topper's Wisdom study guidance and course portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "tw-learntopper",
        "name": "Topper's Wisdom LearnTopper 🚀",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "portalUrl": "https://tw.learntopper.in/",
        "urlVerified": true,
        "description": "Topper's Wisdom study guidance and exam resources on LearnTopper.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "toppers-wisdom-nexthope",
        "name": "Toppers Wisdom NextHope",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "portalUrl": "https://tw.nexthope.site/",
        "urlVerified": true,
        "description": "Toppers Wisdom exam study strategies and courses on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 4,
    "rating": 5,
    "reviewCount": 1980,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "NORCET Nursing",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-toppers-wisdom-batch",
        "title": "Topper's Wisdom OFFICIAL ✅",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Topper's Wisdom",
          "Official",
          "Strategies"
        ],
        "subject": "Official Platform",
        "description": "Official Topper's Wisdom platform for strategies and study techniques.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://topperswisdom.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Topper's Wisdom OFFICIAL ✅"
      },
      {
        "id": "tw-1-batch",
        "title": "Topper's Wisdom 🚀",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "targetExam": "Study Notes & Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Topper's Wisdom",
          "Vercel",
          "Guidance"
        ],
        "subject": "Study Notes & Guidance",
        "description": "Topper's Wisdom study guidance and course portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmod-toperwis.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Topper's Wisdom 🚀"
      },
      {
        "id": "tw-learntopper-batch",
        "title": "Topper's Wisdom LearnTopper 🚀",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "targetExam": "Study Notes & Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Topper's Wisdom",
          "LearnTopper",
          "Guidance"
        ],
        "subject": "Study Notes & Guidance",
        "description": "Topper's Wisdom study guidance and exam resources on LearnTopper.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://tw.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Topper's Wisdom LearnTopper 🚀"
      },
      {
        "id": "toppers-wisdom-nexthope-batch",
        "title": "Toppers Wisdom NextHope",
        "logo": "https://i.postimg.cc/NGSDG8B9/logo.png",
        "targetExam": "Preparation Strategy",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Toppers Wisdom",
          "NextHope",
          "Batches"
        ],
        "subject": "Preparation Strategy",
        "description": "Toppers Wisdom exam study strategies and courses on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://tw.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Toppers Wisdom NextHope"
      }
    ],
    "resources": [
      {
        "id": "toppers-wisdom-res-1",
        "title": "Topper's Wisdom Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Topper's Wisdom.",
        "url": "https://topperswisdom.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "study-iq",
    "name": "Study IQ",
    "slug": "study-iq",
    "logo": "https://i.postimg.cc/yNGghPfd/download.png",
    "tagline": "Study IQ Learning Hub",
    "establishedYear": 2021,
    "category": "upsc",
    "categoryLabel": "Study IQ Civil Services",
    "exams": [
      "UPSC CSE",
      "State PSC",
      "Current Affairs",
      "Judiciary"
    ],
    "brandColor": "#0284c7",
    "badgeText": "Study IQ",
    "description": "High-quality video courses and current affairs for civil services and government exams.",
    "officialWebsite": "https://studyiq.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://studyiq.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 8,
    "portals": [
      {
        "id": "official-study-iq",
        "name": "Study IQ OFFICIAL ✅",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://studyiq.com",
        "urlVerified": true,
        "description": "Official Study IQ video courses and current affairs.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "siq-1",
        "name": "Study IQ 🚀",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://asmultiverse.in/details?id=study-iq",
        "urlVerified": true,
        "description": "Study IQ course details and video materials on AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "siq-2",
        "name": "Study IQ 🔥",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://madxt2z.liveblog365.com/studyiq/?i=2",
        "urlVerified": true,
        "description": "Study IQ interactive study lectures and current affairs hub.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "siq-3",
        "name": "Study IQ 🌟",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://studyiq.thescholarverse.site/auth",
        "urlVerified": true,
        "description": "Study IQ auth portal and competitive exam preparation hub.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "studyiq-streamfiles",
        "name": "Study IQ ✨",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://studyiq.streamfiles.eu.org/",
        "urlVerified": true,
        "description": "Study IQ streamfiles portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "studyiq-spidy",
        "name": "Study IQ Spidy Portal",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://spidyiq.vercel.app/",
        "urlVerified": true,
        "description": "Study IQ Spidy portal for free competitive exam resources and video lectures.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "studyiq-vercel",
        "name": "Study IQ Vercel Portal 🌟",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://studyiqq.vercel.app/",
        "urlVerified": true,
        "description": "Study IQ courses, video lectures and current affairs portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "study-iq-sangam",
        "name": "Study IQ Sangam",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "portalUrl": "https://sangam.free.nf/studyiq/?i=1",
        "urlVerified": true,
        "description": "Study IQ civil services and competitive exam batch access on Sangam.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 8,
    "rating": 5,
    "reviewCount": 2460,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "UPSC CSE",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-study-iq-batch",
        "title": "Study IQ OFFICIAL ✅",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "Official",
          "Civil Services"
        ],
        "subject": "Official Platform",
        "description": "Official Study IQ video courses and current affairs.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyiq.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ OFFICIAL ✅"
      },
      {
        "id": "siq-1-batch",
        "title": "Study IQ 🚀",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "Video Courses & UPSC",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "AS Multiverse",
          "UPSC"
        ],
        "subject": "Video Courses & UPSC",
        "description": "Study IQ course details and video materials on AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.in/details?id=study-iq",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ 🚀"
      },
      {
        "id": "siq-2-batch",
        "title": "Study IQ 🔥",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "Video Courses & UPSC",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "Liveblog",
          "Current Affairs"
        ],
        "subject": "Video Courses & UPSC",
        "description": "Study IQ interactive study lectures and current affairs hub.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://madxt2z.liveblog365.com/studyiq/?i=2",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ 🔥"
      },
      {
        "id": "siq-3-batch",
        "title": "Study IQ 🌟",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "Video Courses & UPSC",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "Scholarverse",
          "Auth"
        ],
        "subject": "Video Courses & UPSC",
        "description": "Study IQ auth portal and competitive exam preparation hub.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyiq.thescholarverse.site/auth",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ 🌟"
      },
      {
        "id": "studyiq-streamfiles-batch",
        "title": "Study IQ ✨",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "Streamfiles"
        ],
        "subject": "Batches & Courses",
        "description": "Study IQ streamfiles portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyiq.streamfiles.eu.org/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ ✨"
      },
      {
        "id": "studyiq-spidy-batch",
        "title": "Study IQ Spidy Portal",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "Civil Services & State PSC",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "Spidy",
          "UPSC"
        ],
        "subject": "Civil Services & State PSC",
        "description": "Study IQ Spidy portal for free competitive exam resources and video lectures.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://spidyiq.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ Spidy Portal"
      },
      {
        "id": "studyiq-vercel-batch",
        "title": "Study IQ Vercel Portal 🌟",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "Civil Services & Current Affairs",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "Vercel",
          "Civil Services"
        ],
        "subject": "Civil Services & Current Affairs",
        "description": "Study IQ courses, video lectures and current affairs portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyiqq.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ Vercel Portal 🌟"
      },
      {
        "id": "study-iq-sangam-batch",
        "title": "Study IQ Sangam",
        "logo": "https://i.postimg.cc/yNGghPfd/download.png",
        "targetExam": "UPSC & State PSC",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Study IQ",
          "Sangam",
          "UPSC"
        ],
        "subject": "UPSC & State PSC",
        "description": "Study IQ civil services and competitive exam batch access on Sangam.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sangam.free.nf/studyiq/?i=1",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Study IQ Sangam"
      }
    ],
    "resources": [
      {
        "id": "study-iq-res-1",
        "title": "Study IQ Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Study IQ.",
        "url": "https://studyiq.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "selection-way",
    "name": "Selection Way",
    "slug": "selection-way",
    "logo": "https://www.selectionway.com/next_images/logo.png",
    "tagline": "Selection Way Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Selection Way Recruitment",
    "exams": [
      "SSC Exams",
      "State Competitions",
      "Railway",
      "Police"
    ],
    "brandColor": "#4f46e5",
    "badgeText": "Selection Way",
    "description": "Career and competitive exam preparation portal dedicated to guiding students toward official selection.",
    "officialWebsite": "https://www.selectionway.com/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://www.selectionway.com/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 25,
    "portals": [
      {
        "id": "sw-1",
        "name": "Selection Way OFFICIAL ✅",
        "logo": "/images/logo.webp",
        "portalUrl": "https://www.selectionway.com/",
        "urlVerified": true,
        "description": "Official portal for Selection Way batches and resources.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-live-vercel",
        "name": "Selection Way 🚀",
        "logo": "/images/logo.webp",
        "portalUrl": "https://selectionwaylive.vercel.app/",
        "urlVerified": true,
        "description": "Selection Way live batches, study materials and portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-2",
        "name": "Selection Way 🔥",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://deltastudy.fun/sway",
        "urlVerified": true,
        "description": "Selection Way batch access and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-3",
        "name": "Selection Way 🌟",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://studybeepro.site/selectionbee/",
        "urlVerified": true,
        "description": "Selection Way learning gateway by Study Bee Pro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-4",
        "name": "Selection Way ✨",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://nexthope.pages.dev/sw/",
        "urlVerified": true,
        "description": "Selection Way portal and resources by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-5",
        "name": "Selection Way 💥",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://sw.learntopper.in/",
        "urlVerified": true,
        "description": "Selection Way portal and resources by Learntopper.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-6",
        "name": "Selection Way ⚡",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://asmultiverse.in/details?id=selection-way",
        "urlVerified": true,
        "description": "Selection Way course details and batch access on AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-7",
        "name": "Selection Way 💎",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://nexthope.pages.dev/sw/all-batches",
        "urlVerified": true,
        "description": "Selection Way complete batch index and learning resources by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-8",
        "name": "Selection Way 🏆",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://selectionwayy.vercel.app/",
        "urlVerified": true,
        "description": "Selection Way learning portal and revision material on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-streamfiles",
        "name": "Selection Way 📚",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://selectionway.streamfiles.eu.org/",
        "urlVerified": true,
        "description": "Selection Way streamfiles portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-pages",
        "name": "Selection Way 3DX Portal",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://newsw-3dx.pages.dev/",
        "urlVerified": true,
        "description": "Selection Way online test and course platform for competitive exams.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-learnxpw",
        "name": "Selection Way LearnX Portal",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://www.learnxpw.site/study/sway",
        "urlVerified": true,
        "description": "Selection Way courses, tests and batch resources on LearnX.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-studyhulk",
        "name": "Selection Way StudyHulk",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://studyhulk-sw.edgeone.dev/",
        "urlVerified": true,
        "description": "Selection Way courses, exam guidance and batch access on EdgeOne.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-sumit-qzz",
        "name": "Selection Way Sumit 🚀",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://sw.sumit.qzz.io/",
        "urlVerified": true,
        "description": "Selection Way course batches and study material access by Sumit.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-studyapkmod",
        "name": "Selection Way Mod Portal 🌟",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://studyapkmodsway.vercel.app/",
        "urlVerified": true,
        "description": "Selection Way student batch portal on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-primestudy",
        "name": "Selection Way PrimeStudy ⚡",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://sw.primestudy.live/",
        "urlVerified": true,
        "description": "Selection Way fast course batches and study portal on PrimeStudy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "sw-learnex",
        "name": "Selection Way LearnEx 🚀",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://learnex.vercel.app/SW",
        "urlVerified": true,
        "description": "Selection Way competitive courses and batch portal on LearnEx Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-2",
        "name": "Selection Way",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://platform.studyparcham.in/sway",
        "urlVerified": true,
        "description": "Selection Way by StudyParcham",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-vivid-edgeone",
        "name": "Selection Way Vivid",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://selectionwayvivid.edgeone.dev/",
        "urlVerified": true,
        "description": "Selection Way Vivid EdgeOne online batch portal and guidance.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-sangam-test",
        "name": "Selection Way Sangam",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://sangam.free.nf/SW/test1.php",
        "urlVerified": true,
        "description": "Selection Way competitive batch access and test series on Sangam.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-studyhulk-vercel",
        "name": "Selection Way StudyHulk",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "http://swstudyhulk.vercel.app/",
        "urlVerified": true,
        "description": "Selection Way StudyHulk portal on Vercel for exam batches.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-nextmate",
        "name": "Selection Way NextMate",
        "logo": "/images/logo.webp",
        "portalUrl": "https://sw.nextmate.site/",
        "urlVerified": true,
        "description": "Selection Way government competitive exam batches and portal on NextMate.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-lrnt-ccwu",
        "name": "Selection Way LRNT",
        "logo": "/images/logo.webp",
        "portalUrl": "https://sw.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "Selection Way digital study materials and live course portal on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selection-way-vividellorvii",
        "name": "Selection Way Vividellorvii",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "portalUrl": "https://vividellorvii.vercel.app/pages/sw.html",
        "urlVerified": true,
        "description": "Selection Way competitive exam batches and learning portal on Vividellorvii.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "selectionway-nexusstudy-vercel",
        "name": "Selection Way Nexus Study",
        "logo": "/images/logo.webp",
        "portalUrl": "https://swnexusstudy.vercel.app/",
        "urlVerified": true,
        "description": "Selection Way competitive exam preparation portal and batch access on Nexus Study Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 25,
    "rating": 4.9,
    "reviewCount": 4500,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SSC Exams",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "sw-1-batch",
        "title": "Selection Way OFFICIAL ✅",
        "logo": "/images/logo.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Official",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Official portal for Selection Way batches and resources.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.selectionway.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way OFFICIAL ✅"
      },
      {
        "id": "sw-live-vercel-batch",
        "title": "Selection Way 🚀",
        "logo": "/images/logo.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Live",
          "Vercel"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way live batches, study materials and portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://selectionwaylive.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 🚀"
      },
      {
        "id": "sw-2-batch",
        "title": "Selection Way 🔥",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Delta Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way batch access and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/sway",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 🔥"
      },
      {
        "id": "sw-3-batch",
        "title": "Selection Way 🌟",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Study Bee Pro",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way learning gateway by Study Bee Pro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studybeepro.site/selectionbee/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 🌟"
      },
      {
        "id": "sw-4-batch",
        "title": "Selection Way ✨",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Next Hope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way portal and resources by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/sw/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way ✨"
      },
      {
        "id": "sw-5-batch",
        "title": "Selection Way 💥",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Learntopper",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way portal and resources by Learntopper.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sw.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 💥"
      },
      {
        "id": "sw-6-batch",
        "title": "Selection Way ⚡",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "AS Multiverse",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way course details and batch access on AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.in/details?id=selection-way",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way ⚡"
      },
      {
        "id": "sw-7-batch",
        "title": "Selection Way 💎",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Next Hope",
          "All Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way complete batch index and learning resources by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/sw/all-batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 💎"
      },
      {
        "id": "sw-8-batch",
        "title": "Selection Way 🏆",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Vercel",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way learning portal and revision material on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://selectionwayy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 🏆"
      },
      {
        "id": "selection-way-streamfiles-batch",
        "title": "Selection Way 📚",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Streamfiles"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way streamfiles portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://selectionway.streamfiles.eu.org/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 📚"
      },
      {
        "id": "selection-way-pages-batch",
        "title": "Selection Way 3DX Portal",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Exam Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Free Batches",
          "Mock Tests"
        ],
        "subject": "Exam Guidance",
        "description": "Selection Way online test and course platform for competitive exams.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://newsw-3dx.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way 3DX Portal"
      },
      {
        "id": "selection-way-learnxpw-batch",
        "title": "Selection Way LearnX Portal",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Exam Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "LearnX",
          "Sway"
        ],
        "subject": "Exam Guidance",
        "description": "Selection Way courses, tests and batch resources on LearnX.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.learnxpw.site/study/sway",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way LearnX Portal"
      },
      {
        "id": "sw-studyhulk-batch",
        "title": "Selection Way StudyHulk",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Exam Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "StudyHulk",
          "EdgeOne"
        ],
        "subject": "Exam Guidance",
        "description": "Selection Way courses, exam guidance and batch access on EdgeOne.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyhulk-sw.edgeone.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way StudyHulk"
      },
      {
        "id": "sw-sumit-qzz-batch",
        "title": "Selection Way Sumit 🚀",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "SW",
          "Sumit"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way course batches and study material access by Sumit.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sw.sumit.qzz.io/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way Sumit 🚀"
      },
      {
        "id": "sw-studyapkmod-batch",
        "title": "Selection Way Mod Portal 🌟",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "SW",
          "Vercel"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way student batch portal on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyapkmodsway.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way Mod Portal 🌟"
      },
      {
        "id": "sw-primestudy-batch",
        "title": "Selection Way PrimeStudy ⚡",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "SW",
          "PrimeStudy"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way fast course batches and study portal on PrimeStudy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sw.primestudy.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way PrimeStudy ⚡"
      },
      {
        "id": "sw-learnex-batch",
        "title": "Selection Way LearnEx 🚀",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "SW",
          "LearnEx"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way competitive courses and batch portal on LearnEx Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnex.vercel.app/SW",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way LearnEx 🚀"
      },
      {
        "id": "selection-way-2-batch",
        "title": "Selection Way",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "StudyParcham"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way by StudyParcham",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://platform.studyparcham.in/sway",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way"
      },
      {
        "id": "selection-way-vivid-edgeone-batch",
        "title": "Selection Way Vivid",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Exam Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "EdgeOne",
          "Vivid"
        ],
        "subject": "Exam Guidance",
        "description": "Selection Way Vivid EdgeOne online batch portal and guidance.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://selectionwayvivid.edgeone.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way Vivid"
      },
      {
        "id": "selection-way-sangam-test-batch",
        "title": "Selection Way Sangam",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Exam Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Sangam",
          "Batches"
        ],
        "subject": "Exam Guidance",
        "description": "Selection Way competitive batch access and test series on Sangam.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sangam.free.nf/SW/test1.php",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way Sangam"
      },
      {
        "id": "selection-way-studyhulk-vercel-batch",
        "title": "Selection Way StudyHulk",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Exam Guidance",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "StudyHulk",
          "Vercel"
        ],
        "subject": "Exam Guidance",
        "description": "Selection Way StudyHulk portal on Vercel for exam batches.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "http://swstudyhulk.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way StudyHulk"
      },
      {
        "id": "selection-way-nextmate-batch",
        "title": "Selection Way NextMate",
        "logo": "/images/logo.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "NextMate",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way government competitive exam batches and portal on NextMate.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sw.nextmate.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way NextMate"
      },
      {
        "id": "selection-way-lrnt-ccwu-batch",
        "title": "Selection Way LRNT",
        "logo": "/images/logo.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "LRNT",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way digital study materials and live course portal on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://sw.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way LRNT"
      },
      {
        "id": "selection-way-vividellorvii-batch",
        "title": "Selection Way Vividellorvii",
        "logo": "https://www.selectionway.com/next_images/logo.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "Vividellorvii",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way competitive exam batches and learning portal on Vividellorvii.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vividellorvii.vercel.app/pages/sw.html",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way Vividellorvii"
      },
      {
        "id": "selectionway-nexusstudy-vercel-batch",
        "title": "Selection Way Nexus Study",
        "logo": "/images/logo.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Selection Way",
          "SW",
          "Nexus Study"
        ],
        "subject": "Batches & Courses",
        "description": "Selection Way competitive exam preparation portal and batch access on Nexus Study Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://swnexusstudy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Selection Way Nexus Study"
      }
    ],
    "resources": [
      {
        "id": "selection-way-res-1",
        "title": "Selection Way Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Selection Way.",
        "url": "https://www.selectionway.com/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "utkarsh-classes",
    "name": "Uttkarsh Classes",
    "slug": "utkarsh-classes",
    "logo": "https://dicb8ki8nr06d.cloudfront.net/webiste_public/images/utkarsh_logo.webp",
    "tagline": "Utkarsh Learning Hub",
    "establishedYear": 2021,
    "category": "ssc-govt",
    "categoryLabel": "Utkarsh Classes & Current Affairs",
    "exams": [
      "Phool Patti Class",
      "RAS",
      "Current Affairs",
      "State Exams"
    ],
    "brandColor": "#ea580c",
    "badgeText": "Utkarsh",
    "description": "Leading online platform for civil services and state competitive exams.",
    "officialWebsite": "https://utkarsh.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://utkarsh.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 2,
    "portals": [
      {
        "id": "official-utkarsh",
        "name": "Utkarsh OFFICIAL ✅",
        "logo": "https://dicb8ki8nr06d.cloudfront.net/webiste_public/images/utkarsh_logo.webp",
        "portalUrl": "https://utkarsh.com",
        "urlVerified": true,
        "description": "Official Uttkarsh Classes platform for civil services and state exams.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "utk-1",
        "name": "Utkarsh 🚀",
        "logo": "https://dicb8ki8nr06d.cloudfront.net/webiste_public/images/utkarsh_logo.webp",
        "portalUrl": "https://asmultiverse.in/details?id=Utkarsh%20Classes",
        "urlVerified": true,
        "description": "Utkarsh Classes course details and study material on AS Multiverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 2,
    "rating": 5,
    "reviewCount": 1740,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "Phool Patti Class",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-utkarsh-batch",
        "title": "Utkarsh OFFICIAL ✅",
        "logo": "https://dicb8ki8nr06d.cloudfront.net/webiste_public/images/utkarsh_logo.webp",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Utkarsh",
          "Official",
          "Civil Services"
        ],
        "subject": "Official Platform",
        "description": "Official Uttkarsh Classes platform for civil services and state exams.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://utkarsh.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Utkarsh OFFICIAL ✅"
      },
      {
        "id": "utk-1-batch",
        "title": "Utkarsh 🚀",
        "logo": "https://dicb8ki8nr06d.cloudfront.net/webiste_public/images/utkarsh_logo.webp",
        "targetExam": "Civil Services & State Exams",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Utkarsh",
          "Utkarsh Classes",
          "AS Multiverse"
        ],
        "subject": "Civil Services & State Exams",
        "description": "Utkarsh Classes course details and study material on AS Multiverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://asmultiverse.in/details?id=Utkarsh%20Classes",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Utkarsh 🚀"
      }
    ],
    "resources": [
      {
        "id": "utkarsh-classes-res-1",
        "title": "Uttkarsh Classes Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Uttkarsh Classes.",
        "url": "https://utkarsh.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "vidhyagram",
    "name": "Vidhyagram",
    "slug": "vidhyagram",
    "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
    "tagline": "Vidhyagram Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "Vidhyagram School & Board",
    "exams": [
      "High School",
      "Board Foundation",
      "Competitive Prep"
    ],
    "brandColor": "#047857",
    "badgeText": "Vidhyagram",
    "description": "Vidyagram online learning and competitive exam preparation.",
    "officialWebsite": "https://bat.vidyagram.workers.dev/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://bat.vidyagram.workers.dev/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 4,
    "portals": [
      {
        "id": "vidyagram-workers-bat",
        "name": "Vidyagram BAT Portal",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "portalUrl": "https://bat.vidyagram.workers.dev/",
        "urlVerified": true,
        "description": "Vidyagram  fast batch access portal on Cloudflare workers with state board and competitive batches.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vidhyagram-1",
        "name": "Vidhyagram",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "portalUrl": "https://vidya.studybeepro.site/",
        "urlVerified": true,
        "description": "Vidhyagram by StudyBeePro",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vidhyagram-official",
        "name": "Vidhyagram",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "portalUrl": "https://www.vidyagram.online/",
        "urlVerified": true,
        "description": "Vidyagram Official Website",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vidhyagram-nexthope",
        "name": "Vidhyagram NextHope",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "portalUrl": "https://vidya.nexthope.site/",
        "urlVerified": true,
        "description": "Vidhyagram online learning portal and batch access on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 4,
    "rating": 4.8,
    "reviewCount": 1980,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "High School",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "vidyagram-workers-bat-batch",
        "title": "Vidyagram BAT Portal",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "targetExam": "State Board & Vernacular",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vidyagram",
          "Vidhyagram",
          "Batches"
        ],
        "subject": "State Board & Vernacular",
        "description": "Vidyagram  fast batch access portal on Cloudflare workers with state board and competitive batches.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://bat.vidyagram.workers.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vidyagram BAT Portal"
      },
      {
        "id": "vidhyagram-1-batch",
        "title": "Vidhyagram",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vidhyagram",
          "StudyBeePro"
        ],
        "subject": "Batches & Courses",
        "description": "Vidhyagram by StudyBeePro",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://vidya.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vidhyagram"
      },
      {
        "id": "vidhyagram-official-batch",
        "title": "Vidhyagram",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vidhyagram",
          "Official",
          "Vidyagram"
        ],
        "subject": "Batches & Courses",
        "description": "Vidyagram Official Website",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.vidyagram.online/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vidhyagram"
      },
      {
        "id": "vidhyagram-nexthope-batch",
        "title": "Vidhyagram NextHope",
        "logo": "https://vidyagram.online/arvidyapeeth/vidyagram.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vidhyagram",
          "NextHope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Vidhyagram online learning portal and batch access on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vidya.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vidhyagram NextHope"
      }
    ],
    "resources": [
      {
        "id": "vidhyagram-res-1",
        "title": "Vidhyagram Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Vidhyagram.",
        "url": "https://bat.vidyagram.workers.dev/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "yes-officer",
    "name": "Yes Officer",
    "slug": "yes-officer",
    "logo": "https://i.ibb.co/8gVcx0RF/IMG-5939.webp",
    "tagline": "Yes Officer Learning Hub",
    "establishedYear": 2021,
    "category": "banking",
    "categoryLabel": "Yes Officer Banking & PO",
    "exams": [
      "SBI PO",
      "IBPS PO",
      "SBI Clerk",
      "RBI Grade B"
    ],
    "brandColor": "#7c3aed",
    "badgeText": "Yes Officer",
    "description": "Prepare for competitive exams with expert guidance.",
    "officialWebsite": "https://yesofficer.studybeepro.site/",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://yesofficer.studybeepro.site/",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 3,
    "portals": [
      {
        "id": "yes-officer-1",
        "name": "Yes Officer",
        "logo": "https://i.ibb.co/8gVcx0RF/IMG-5939.webp",
        "portalUrl": "https://yesofficer.studybeepro.site/",
        "urlVerified": true,
        "description": "Yes Officer by StudyBeePro",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "yes-officer-official",
        "name": "Yes Officer",
        "logo": "https://i.ibb.co/8gVcx0RF/IMG-5939.webp",
        "portalUrl": "https://www.yesofficer.com/",
        "urlVerified": true,
        "description": "Yes Officer Official Website",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "yes-officer-nexthope",
        "name": "Yes Officer NextHope",
        "logo": "https://i.ibb.co/8gVcx0RF/IMG-5939.webp",
        "portalUrl": "https://yesofficer.nexthope.site/",
        "urlVerified": true,
        "description": "Yes Officer banking and competitive exam prep batch access on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 3,
    "rating": 4.8,
    "reviewCount": 1860,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "SBI PO",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "yes-officer-1-batch",
        "title": "Yes Officer",
        "logo": "https://i.ibb.co/8gVcx0RF/IMG-5939.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Yes Officer",
          "StudyBeePro"
        ],
        "subject": "Batches & Courses",
        "description": "Yes Officer by StudyBeePro",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://yesofficer.studybeepro.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Yes Officer"
      },
      {
        "id": "yes-officer-official-batch",
        "title": "Yes Officer",
        "logo": "https://i.ibb.co/8gVcx0RF/IMG-5939.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Yes Officer",
          "Official"
        ],
        "subject": "Batches & Courses",
        "description": "Yes Officer Official Website",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.yesofficer.com/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Yes Officer"
      },
      {
        "id": "yes-officer-nexthope-batch",
        "title": "Yes Officer NextHope",
        "logo": "https://i.ibb.co/8gVcx0RF/IMG-5939.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Yes Officer",
          "NextHope",
          "Banking"
        ],
        "subject": "Batches & Courses",
        "description": "Yes Officer banking and competitive exam prep batch access on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://yesofficer.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Yes Officer NextHope"
      }
    ],
    "resources": [
      {
        "id": "yes-officer-res-1",
        "title": "Yes Officer Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Yes Officer.",
        "url": "https://yesofficer.studybeepro.site/",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "unacademy",
    "name": "UnAcademy",
    "slug": "unacademy",
    "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
    "tagline": "UnAcademy Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "Unacademy Top Educators",
    "exams": [
      "IIT JEE",
      "NEET UG",
      "UPSC CSE",
      "CAT",
      "CA Foundation"
    ],
    "brandColor": "#0284c7",
    "badgeText": "UnAcademy",
    "description": "India's largest learning platform offering online courses, test preparation, and live classes for various exams.",
    "officialWebsite": "https://unacademy.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://unacademy.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 18,
    "portals": [
      {
        "id": "official-unacademy",
        "name": "UnAcademy OFFICIAL ✅",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://unacademy.com",
        "urlVerified": true,
        "description": "Official UnAcademy learning platform for test preparation and live classes.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "un-1",
        "name": "Unacademy 🚀",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://studyuk.online/goal/index.php?change=1",
        "urlVerified": true,
        "description": "Unacademy UK portal for study resources and goal tracking.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "un-2",
        "name": "Unacademy 🌟",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://uncs.pages.dev/",
        "urlVerified": true,
        "description": "Unacademy UNCS portal and study resources.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "un-3",
        "name": "Unacademy ✨",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://unc.studybeepro.site/of-unc/",
        "urlVerified": true,
        "description": "Unacademy learning gateway by Study Bee Pro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "un-4",
        "name": "Unacademy 💥",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://unacademy.primestudy.live/",
        "urlVerified": true,
        "description": "Unacademy portal and resources by Prime Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "un-5",
        "name": "Unacademy ⚡",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://nexthope.pages.dev/unacademy/",
        "urlVerified": true,
        "description": "Unacademy study portal and course dashboard by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "un-6",
        "name": "Unacademy 💎",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://unacademy.thescholarverse.site/",
        "urlVerified": true,
        "description": "Unacademy courses and exam preparation resources by Scholarverse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "ua-studybison",
        "name": "StudyBison UnAcademy 🎓",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://ua.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison UnAcademy online courses, recorded sessions, and batch gateway.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edufreek-unacademy",
        "name": "EduFreek UnAcademy ⚡",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://edufreek.ct.ws/generate.php?platform=unacademy",
        "urlVerified": true,
        "description": "EduFreek UnAcademy online batch link generator and resource player.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edufreek-unacademy-offline",
        "name": "EduFreek UnAcademy Offline 🏢",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://edufreek.ct.ws/generate.php?platform=uncoffline",
        "urlVerified": true,
        "description": "EduFreek UnAcademy offline Kota center recorded lectures and Kota classroom portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-spidy",
        "name": "Unacademy Spidy Portal",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://spidyunacademy.vercel.app/",
        "urlVerified": true,
        "description": "Unacademy Spidy portal for competitive exam preparations and batch lectures.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-nexthope-offline",
        "name": "Unacademy NextHope Offline 🏢",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://nexthope.pages.dev/uncoffline/",
        "urlVerified": true,
        "description": "Unacademy offline center courses and lecture resources on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-vercel-portal",
        "name": "Unacademy Web 🚀",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://unacademyy.vercel.app/",
        "urlVerified": true,
        "description": "Unacademy courses, test series, and live batch access platform on Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-1",
        "name": "Unacademy",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://studypanda.live/ud",
        "urlVerified": true,
        "description": "Unacademy by StudyPanda",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-2",
        "name": "Unacademy",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://uncs-online.studybison.in/",
        "urlVerified": true,
        "description": "Unacademy by StudyBison",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-madxrohit",
        "name": "Unacademy MadxRohit",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://madxrohit.vercel.app/un.html",
        "urlVerified": true,
        "description": "Unacademy batch lectures and study portal by MadxRohit.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-uc-web-worker",
        "name": "UnAcademy UC Web Worker",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://uc-web.uc27.workers.dev/",
        "urlVerified": true,
        "description": "UnAcademy interactive web gateway and live batch learning portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "unacademy-deltaverse",
        "name": "UnAcademy DeltaVerse",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "portalUrl": "https://unacademy.deltaverse.site/",
        "urlVerified": true,
        "description": "UnAcademy online courses, live classes, and test preparation portal on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 18,
    "rating": 5,
    "reviewCount": 3660,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "IIT JEE",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-unacademy-batch",
        "title": "UnAcademy OFFICIAL ✅",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "UnAcademy",
          "Official",
          "Live Classes"
        ],
        "subject": "Official Platform",
        "description": "Official UnAcademy learning platform for test preparation and live classes.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://unacademy.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "UnAcademy OFFICIAL ✅"
      },
      {
        "id": "un-1-batch",
        "title": "Unacademy 🚀",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "UK",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy UK portal for study resources and goal tracking.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyuk.online/goal/index.php?change=1",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy 🚀"
      },
      {
        "id": "un-2-batch",
        "title": "Unacademy 🌟",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "UNCS",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy UNCS portal and study resources.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://uncs.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy 🌟"
      },
      {
        "id": "un-3-batch",
        "title": "Unacademy ✨",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "Study Bee Pro",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy learning gateway by Study Bee Pro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://unc.studybeepro.site/of-unc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy ✨"
      },
      {
        "id": "un-4-batch",
        "title": "Unacademy 💥",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "Prime Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy portal and resources by Prime Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://unacademy.primestudy.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy 💥"
      },
      {
        "id": "un-5-batch",
        "title": "Unacademy ⚡",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "Next Hope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy study portal and course dashboard by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/unacademy/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy ⚡"
      },
      {
        "id": "un-6-batch",
        "title": "Unacademy 💎",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "Scholarverse",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy courses and exam preparation resources by Scholarverse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://unacademy.thescholarverse.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy 💎"
      },
      {
        "id": "ua-studybison-batch",
        "title": "StudyBison UnAcademy 🎓",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "UnAcademy",
          "StudyBison",
          "Courses"
        ],
        "subject": "Batches & Courses",
        "description": "StudyBison UnAcademy online courses, recorded sessions, and batch gateway.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://ua.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison UnAcademy 🎓"
      },
      {
        "id": "edufreek-unacademy-batch",
        "title": "EduFreek UnAcademy ⚡",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "UnAcademy",
          "EduFreek",
          "Generator"
        ],
        "subject": "Batches & Courses",
        "description": "EduFreek UnAcademy online batch link generator and resource player.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edufreek.ct.ws/generate.php?platform=unacademy",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "EduFreek UnAcademy ⚡"
      },
      {
        "id": "edufreek-unacademy-offline-batch",
        "title": "EduFreek UnAcademy Offline 🏢",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "UnAcademy",
          "EduFreek",
          "Kota Center"
        ],
        "subject": "Batches & Courses",
        "description": "EduFreek UnAcademy offline Kota center recorded lectures and Kota classroom portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edufreek.ct.ws/generate.php?platform=uncoffline",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "EduFreek UnAcademy Offline 🏢"
      },
      {
        "id": "unacademy-spidy-batch",
        "title": "Unacademy Spidy Portal",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Comprehensive Learning",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "Spidy",
          "Free Batches"
        ],
        "subject": "Comprehensive Learning",
        "description": "Unacademy Spidy portal for competitive exam preparations and batch lectures.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://spidyunacademy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy Spidy Portal"
      },
      {
        "id": "unacademy-nexthope-offline-batch",
        "title": "Unacademy NextHope Offline 🏢",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Offline Center & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "NextHope",
          "Offline"
        ],
        "subject": "Offline Center & Courses",
        "description": "Unacademy offline center courses and lecture resources on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/uncoffline/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy NextHope Offline 🏢"
      },
      {
        "id": "unacademy-vercel-portal-batch",
        "title": "Unacademy Web 🚀",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "Vercel",
          "Online Learning"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy courses, test series, and live batch access platform on Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://unacademyy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy Web 🚀"
      },
      {
        "id": "unacademy-1-batch",
        "title": "Unacademy",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "StudyPanda"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy by StudyPanda",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://studypanda.live/ud",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy"
      },
      {
        "id": "unacademy-2-batch",
        "title": "Unacademy",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "StudyBison"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy by StudyBison",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://uncs-online.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy"
      },
      {
        "id": "unacademy-madxrohit-batch",
        "title": "Unacademy MadxRohit",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Unacademy",
          "MadxRohit",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Unacademy batch lectures and study portal by MadxRohit.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://madxrohit.vercel.app/un.html",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Unacademy MadxRohit"
      },
      {
        "id": "unacademy-uc-web-worker-batch",
        "title": "UnAcademy UC Web Worker",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Test Prep & Live Classes",
        "targetYear": "2025-2026",
        "facultyNames": [
          "UnAcademy",
          "UC Web",
          "Live Classes"
        ],
        "subject": "Test Prep & Live Classes",
        "description": "UnAcademy interactive web gateway and live batch learning portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://uc-web.uc27.workers.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "UnAcademy UC Web Worker"
      },
      {
        "id": "unacademy-deltaverse-batch",
        "title": "UnAcademy DeltaVerse",
        "logo": "https://i.postimg.cc/PJj1bKn9/images-2026-07-02T231828-233.png",
        "targetExam": "Test Prep & Live Classes",
        "targetYear": "2025-2026",
        "facultyNames": [
          "UnAcademy",
          "DeltaVerse",
          "Live Classes"
        ],
        "subject": "Test Prep & Live Classes",
        "description": "UnAcademy online courses, live classes, and test preparation portal on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://unacademy.deltaverse.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "UnAcademy DeltaVerse"
      }
    ],
    "resources": [
      {
        "id": "unacademy-res-1",
        "title": "UnAcademy Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for UnAcademy.",
        "url": "https://unacademy.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "vidhyakul",
    "name": "Vidhyakul",
    "slug": "vidhyakul",
    "logo": "https://cdn-1.webcatalog.io/catalog/vidyakul/vidyakul-icon-filled-256.webp?v=1714780458007",
    "tagline": "Vidhyakul Learning Hub",
    "establishedYear": 2021,
    "category": "boards",
    "categoryLabel": "State Board Hindi Medium",
    "exams": [
      "UP Board",
      "Bihar Board",
      "MP Board",
      "Class 10th & 12th"
    ],
    "brandColor": "#d97706",
    "badgeText": "Vidhyakul",
    "description": "Vernacular learning platform providing local language e-learning courses, Vidhakul, and Vidyagram free batches.",
    "officialWebsite": "https://vidyakul.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://vidyakul.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 3,
    "portals": [
      {
        "id": "official-vidhyakul",
        "name": "Vidhyakul OFFICIAL ✅",
        "logo": "https://cdn-1.webcatalog.io/catalog/vidyakul/vidyakul-icon-filled-256.webp?v=1714780458007",
        "portalUrl": "https://vidyakul.com",
        "urlVerified": true,
        "description": "Official Vidhyakul vernacular learning platform.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vk-1",
        "name": "Vidhyakul 🚀",
        "logo": "https://cdn-1.webcatalog.io/catalog/vidyakul/vidyakul-icon-filled-256.webp?v=1714780458007",
        "portalUrl": "https://vidyakool.streamfiles.eu.org/",
        "urlVerified": true,
        "description": "Vidhyakul video stream files and study resources portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vk-2",
        "name": "Vidhyakul App 📱",
        "logo": "https://cdn-1.webcatalog.io/catalog/vidyakul/vidyakul-icon-filled-256.webp?v=1714780458007",
        "portalUrl": "https://mega.nz/file/W4JSxYJY#VB1H7wZgqx5ZxUnCUq3o6RkOk8Xb8KuvD0fFbZ0aKi4",
        "urlVerified": true,
        "description": "Vidhyakul Android app package (v10.21.6) for mobile learning, video lectures, and study batches.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 3,
    "rating": 5,
    "reviewCount": 1860,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "UP Board",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-vidhyakul-batch",
        "title": "Vidhyakul OFFICIAL ✅",
        "logo": "https://cdn-1.webcatalog.io/catalog/vidyakul/vidyakul-icon-filled-256.webp?v=1714780458007",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vidhyakul",
          "Official",
          "Vernacular"
        ],
        "subject": "Official Platform",
        "description": "Official Vidhyakul vernacular learning platform.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://vidyakul.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vidhyakul OFFICIAL ✅"
      },
      {
        "id": "vk-1-batch",
        "title": "Vidhyakul 🚀",
        "logo": "https://cdn-1.webcatalog.io/catalog/vidyakul/vidyakul-icon-filled-256.webp?v=1714780458007",
        "targetExam": "Vernacular & Board Prep",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vidhyakul",
          "Streamfiles",
          "Videos"
        ],
        "subject": "Vernacular & Board Prep",
        "description": "Vidhyakul video stream files and study resources portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vidyakool.streamfiles.eu.org/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vidhyakul 🚀"
      },
      {
        "id": "vk-2-batch",
        "title": "Vidhyakul App 📱",
        "logo": "https://cdn-1.webcatalog.io/catalog/vidyakul/vidyakul-icon-filled-256.webp?v=1714780458007",
        "targetExam": "Mobile App & Batches",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vidhyakul",
          "App",
          "APK"
        ],
        "subject": "Mobile App & Batches",
        "description": "Vidhyakul Android app package (v10.21.6) for mobile learning, video lectures, and study batches.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://mega.nz/file/W4JSxYJY#VB1H7wZgqx5ZxUnCUq3o6RkOk8Xb8KuvD0fFbZ0aKi4",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vidhyakul App 📱"
      }
    ],
    "resources": [
      {
        "id": "vidhyakul-res-1",
        "title": "Vidhyakul Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Vidhyakul.",
        "url": "https://vidyakul.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  },
  {
    "id": "vibrant-academy",
    "name": "Vibrant Academy",
    "slug": "vibrant-academy",
    "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
    "tagline": "Vibrant Learning Hub",
    "establishedYear": 2021,
    "category": "iit-jee",
    "categoryLabel": "Vibrant Kota JEE Advanced",
    "exams": [
      "JEE Advanced",
      "JEE Main",
      "Class 12 Dropper Batch"
    ],
    "brandColor": "#2563eb",
    "badgeText": "Vibrant",
    "description": "Premier coaching institute platform for IIT-JEE, NEET, and competitive exam preparation.",
    "officialWebsite": "https://vibrantacademy.com",
    "officialYoutube": "https://www.youtube.com",
    "officialAppUrl": "https://vibrantacademy.com",
    "telegramChannel": "https://t.me/Voidxevra",
    "portalCount": 22,
    "portals": [
      {
        "id": "official-vibrant",
        "name": "Vibrant Academy OFFICIAL ✅",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vibrantacademy.com",
        "urlVerified": true,
        "description": "Official Vibrant Academy platform for IIT-JEE and NEET.",
        "status": "Official",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-1",
        "name": "Vibrant Academy 🚀",
        "logo": "/images/classx-subject.webp",
        "portalUrl": "https://nexthope.pages.dev/vb/",
        "urlVerified": true,
        "description": "Vibrant Academy batch access and learning resources by Next Hope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-2",
        "name": "Vibrant Academy 🔥",
        "logo": "/images/classx-subject.webp",
        "portalUrl": "https://vb-studysquad.pages.dev/",
        "urlVerified": true,
        "description": "Vibrant Academy portal and resources by Study Squad.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-3",
        "name": "Vibrant Academy 🌟",
        "logo": "/images/classx-subject.webp",
        "portalUrl": "https://studyparcham.in/vibrant/",
        "urlVerified": true,
        "description": "Vibrant Academy learning gateway by Study Parcham.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-4",
        "name": "Vibrant Academy ✨",
        "logo": "/images/classx-subject.webp",
        "portalUrl": "https://deltastudy.fun/vibrant",
        "urlVerified": true,
        "description": "Vibrant Academy batch access and courses by Delta Study.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-5",
        "name": "Vibrant Academy 💥",
        "logo": "/images/classx-subject.webp",
        "portalUrl": "https://studybeepro.site/vibrante/",
        "urlVerified": true,
        "description": "Vibrant Academy learning gateway by Study Bee Pro.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-6",
        "name": "Vibrant Academy ⚡",
        "logo": "/images/classx-subject.webp",
        "portalUrl": "https://studypanda.live/vibrant",
        "urlVerified": true,
        "description": "Vibrant Academy batch access and study resources by Study Panda.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-studybison",
        "name": "StudyBison Vibrant Academy 🏛️",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://va.studybison.in/",
        "urlVerified": true,
        "description": "StudyBison Vibrant Academy IIT-JEE and NEET Kota coaching portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "edufreek-vibrant",
        "name": "EduFreek Vibrant 🌟",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://edufreek.ct.ws/generate.php?platform=vb",
        "urlVerified": true,
        "description": "EduFreek Vibrant Academy batch stream generator and test portal.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-rolexcoderz",
        "name": "Vibrant Rolex Coderz",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://rolexcoderz.com/VT/",
        "urlVerified": true,
        "description": "Vibrant Academy resources by Rolex Coderz.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-studyspark",
        "name": "Vibrant StudySpark",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vt.studyspark.pro/",
        "urlVerified": true,
        "description": "Vibrant Academy resources by StudySpark.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-learnxpw",
        "name": "Vibrant Academy LearnX Portal",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://www.learnxpw.site/study/vibrant",
        "urlVerified": true,
        "description": "Vibrant Academy study lectures and batch portal on LearnX.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "va-eduzex",
        "name": "Vibrant Academy Eduzex",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vt.eduzex.indevs.in/",
        "urlVerified": true,
        "description": "Vibrant Academy coaching lectures, JEE and NEET batch materials on Eduzex.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-primestudy",
        "name": "Vibrant Academy PrimeStudy 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vibrante.primestudy.live/",
        "urlVerified": true,
        "description": "Vibrant Academy IIT-JEE and NEET coaching lecture platform on PrimeStudy.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-learntopper",
        "name": "Vibrant Academy LearnTopper 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vt.learntopper.in/",
        "urlVerified": true,
        "description": "Vibrant Academy IIT-JEE and NEET coaching lecture platform on LearnTopper.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-learnex",
        "name": "Vibrant Academy LearnEx ⚡",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://learnex.vercel.app/VA",
        "urlVerified": true,
        "description": "Vibrant Academy JEE and NEET batch resources on LearnEx Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-1",
        "name": "Vibrant",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://platform.studyparcham.in/vibrant",
        "urlVerified": true,
        "description": "Vibrant by StudyParcham",
        "status": "Verified",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-academy-nexthope",
        "name": "Vibrant Academy NextHope",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vb.nexthope.site/",
        "urlVerified": true,
        "description": "Vibrant Academy IIT-JEE and NEET coaching lecture portal on NextHope.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-academy-nextmate",
        "name": "Vibrant Academy NextMate",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vibrant.nextmate.site/",
        "urlVerified": true,
        "description": "Vibrant Academy IIT-JEE and NEET preparation portal on NextMate.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-academy-lrnt-ccwu",
        "name": "Vibrant Academy LRNT",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vt.lrnt.ccwu.cc/",
        "urlVerified": true,
        "description": "Vibrant Academy coaching materials and competitive exam batches on LRNT.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-academy-deltaverse-batches",
        "name": "Vibrant Academy DeltaVerse",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://deltaverse.site/vibrant/batches",
        "urlVerified": true,
        "description": "Vibrant Academy IIT-JEE and NEET preparation batches on DeltaVerse.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      },
      {
        "id": "vibrant-nexusstudy-vercel",
        "name": "Vibrant Academy Nexus Study",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "portalUrl": "https://vbnexusstudy.vercel.app/",
        "urlVerified": true,
        "description": "Vibrant Academy IIT-JEE and NEET coaching resources on Nexus Study Vercel.",
        "status": "Active",
        "batchCount": 1,
        "batches": []
      }
    ],
    "verifiedBatchCount": 22,
    "rating": 5,
    "reviewCount": 4140,
    "featured": true,
    "faculties": [
      {
        "name": "Senior Faculty Panel",
        "subject": "JEE Advanced",
        "experience": "10+ Years",
        "specialty": "Top Rank Producer"
      }
    ],
    "batches": [
      {
        "id": "official-vibrant-batch",
        "title": "Vibrant Academy OFFICIAL ✅",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "Official Platform",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Official",
          "JEE"
        ],
        "subject": "Official Platform",
        "description": "Official Vibrant Academy platform for IIT-JEE and NEET.",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://vibrantacademy.com",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy OFFICIAL ✅"
      },
      {
        "id": "va-1-batch",
        "title": "Vibrant Academy 🚀",
        "logo": "/images/classx-subject.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Next Hope",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy batch access and learning resources by Next Hope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://nexthope.pages.dev/vb/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy 🚀"
      },
      {
        "id": "va-2-batch",
        "title": "Vibrant Academy 🔥",
        "logo": "/images/classx-subject.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Study Squad",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy portal and resources by Study Squad.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vb-studysquad.pages.dev/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy 🔥"
      },
      {
        "id": "va-3-batch",
        "title": "Vibrant Academy 🌟",
        "logo": "/images/classx-subject.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Study Parcham",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy learning gateway by Study Parcham.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studyparcham.in/vibrant/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy 🌟"
      },
      {
        "id": "va-4-batch",
        "title": "Vibrant Academy ✨",
        "logo": "/images/classx-subject.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Delta Study",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy batch access and courses by Delta Study.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltastudy.fun/vibrant",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy ✨"
      },
      {
        "id": "va-5-batch",
        "title": "Vibrant Academy 💥",
        "logo": "/images/classx-subject.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Study Bee Pro",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy learning gateway by Study Bee Pro.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studybeepro.site/vibrante/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy 💥"
      },
      {
        "id": "va-6-batch",
        "title": "Vibrant Academy ⚡",
        "logo": "/images/classx-subject.webp",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Study Panda",
          "Batches"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy batch access and study resources by Study Panda.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://studypanda.live/vibrant",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy ⚡"
      },
      {
        "id": "va-studybison-batch",
        "title": "StudyBison Vibrant Academy 🏛️",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "StudyBison",
          "Kota Coaching"
        ],
        "subject": "Batches & Courses",
        "description": "StudyBison Vibrant Academy IIT-JEE and NEET Kota coaching portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://va.studybison.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "StudyBison Vibrant Academy 🏛️"
      },
      {
        "id": "edufreek-vibrant-batch",
        "title": "EduFreek Vibrant 🌟",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "EduFreek",
          "Generator"
        ],
        "subject": "Batches & Courses",
        "description": "EduFreek Vibrant Academy batch stream generator and test portal.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://edufreek.ct.ws/generate.php?platform=vb",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "EduFreek Vibrant 🌟"
      },
      {
        "id": "vibrant-rolexcoderz-batch",
        "title": "Vibrant Rolex Coderz",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Rolex Coderz"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy resources by Rolex Coderz.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://rolexcoderz.com/VT/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Rolex Coderz"
      },
      {
        "id": "vibrant-studyspark-batch",
        "title": "Vibrant StudySpark",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "StudySpark"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant Academy resources by StudySpark.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vt.studyspark.pro/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant StudySpark"
      },
      {
        "id": "vibrant-learnxpw-batch",
        "title": "Vibrant Academy LearnX Portal",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "LearnX",
          "IIT-JEE"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy study lectures and batch portal on LearnX.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://www.learnxpw.site/study/vibrant",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy LearnX Portal"
      },
      {
        "id": "va-eduzex-batch",
        "title": "Vibrant Academy Eduzex",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Eduzex",
          "IIT-JEE"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy coaching lectures, JEE and NEET batch materials on Eduzex.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vt.eduzex.indevs.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy Eduzex"
      },
      {
        "id": "vibrant-primestudy-batch",
        "title": "Vibrant Academy PrimeStudy 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Vibrant",
          "PrimeStudy"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy IIT-JEE and NEET coaching lecture platform on PrimeStudy.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vibrante.primestudy.live/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy PrimeStudy 🚀"
      },
      {
        "id": "vibrant-learntopper-batch",
        "title": "Vibrant Academy LearnTopper 🚀",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "LearnTopper",
          "IIT-JEE"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy IIT-JEE and NEET coaching lecture platform on LearnTopper.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vt.learntopper.in/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy LearnTopper 🚀"
      },
      {
        "id": "vibrant-learnex-batch",
        "title": "Vibrant Academy LearnEx ⚡",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "LearnEx",
          "Vercel"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy JEE and NEET batch resources on LearnEx Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://learnex.vercel.app/VA",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy LearnEx ⚡"
      },
      {
        "id": "vibrant-1-batch",
        "title": "Vibrant",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "Batches & Courses",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant",
          "StudyParcham"
        ],
        "subject": "Batches & Courses",
        "description": "Vibrant by StudyParcham",
        "status": "Active",
        "modulesCount": 45,
        "officialCourseUrl": "https://platform.studyparcham.in/vibrant",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant"
      },
      {
        "id": "vibrant-academy-nexthope-batch",
        "title": "Vibrant Academy NextHope",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "NextHope",
          "IIT-JEE"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy IIT-JEE and NEET coaching lecture portal on NextHope.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vb.nexthope.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy NextHope"
      },
      {
        "id": "vibrant-academy-nextmate-batch",
        "title": "Vibrant Academy NextMate",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "NextMate",
          "JEE"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy IIT-JEE and NEET preparation portal on NextMate.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vibrant.nextmate.site/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy NextMate"
      },
      {
        "id": "vibrant-academy-lrnt-ccwu-batch",
        "title": "Vibrant Academy LRNT",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "LRNT",
          "Batches"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy coaching materials and competitive exam batches on LRNT.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vt.lrnt.ccwu.cc/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy LRNT"
      },
      {
        "id": "vibrant-academy-deltaverse-batches-batch",
        "title": "Vibrant Academy DeltaVerse",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "DeltaVerse",
          "Batches"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy IIT-JEE and NEET preparation batches on DeltaVerse.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://deltaverse.site/vibrant/batches",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy DeltaVerse"
      },
      {
        "id": "vibrant-nexusstudy-vercel-batch",
        "title": "Vibrant Academy Nexus Study",
        "logo": "https://nocache-appxdb-v2.classx.co.in/subject/2026-02-24-0.8461171343418096.png",
        "targetExam": "IIT-JEE & NEET",
        "targetYear": "2025-2026",
        "facultyNames": [
          "Vibrant Academy",
          "Nexus Study",
          "Vercel"
        ],
        "subject": "IIT-JEE & NEET",
        "description": "Vibrant Academy IIT-JEE and NEET coaching resources on Nexus Study Vercel.",
        "status": "Popular",
        "modulesCount": 45,
        "officialCourseUrl": "https://vbnexusstudy.vercel.app/",
        "urlVerified": true,
        "notesAvailable": true,
        "dppAvailable": true,
        "testSeriesIncluded": true,
        "portalName": "Vibrant Academy Nexus Study"
      }
    ],
    "resources": [
      {
        "id": "vibrant-academy-res-1",
        "title": "Vibrant Academy Official Resource Portal",
        "type": "notes",
        "format": "Official Portal",
        "description": "Direct access to verified study material and batch notes for Vibrant Academy.",
        "url": "https://vibrantacademy.com",
        "isOfficial": true,
        "verifiedDate": "2026-10-09"
      }
    ]
  }
];

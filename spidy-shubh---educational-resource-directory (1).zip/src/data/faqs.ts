import { FAQItem } from '../types';

export const FAQS_DATA: FAQItem[] = [
  {
    id: 'what-is-spidy-shubh',
    question: 'What is SPIDY SHUBH and how does it help students?',
    answer: 'SPIDY SHUBH is an independent, non-commercial educational resource directory designed for competitive exam aspirants across India (IIT JEE, NEET, UPSC, SSC, Banking, and Boards). We systematically index official course curricula, faculty lineups, free DPPs, formula sheets, syllabus roadmaps, and verified educational portals all in one place so you never waste hours hunting for verified study information.',
    category: 'general'
  },
  {
    id: 'are-links-genuine',
    question: 'Are the platform and resource links safe and authentic?',
    answer: 'Yes, 100%. In strict adherence to our safety policy, SPIDY SHUBH does not host pirated streams or unauthorized video batches. Every link directs you either to genuine official platform portals (PW, Unacademy, Allen, Khan GS, Drishti IAS, Careerwill), official YouTube educational repositories, or legitimate public academic handbooks.',
    category: 'general'
  },
  {
    id: 'how-to-request-batch',
    question: 'How do I request a missing batch or study material?',
    answer: 'Simply click the "Request / Suggestion" button in the top navigation or banner. Fill out the quick form with the platform name, batch title, and exam type. Our team reviews submissions daily and updates the directory index accordingly.',
    category: 'batches'
  },
  {
    id: 'telegram-community',
    question: 'What benefits do I get by joining the SPIDY SHUBH Telegram channel?',
    answer: 'Our official Telegram channel provides real-time alerts when premier platforms launch new test series schedules, release free NCERT revision capsules, announce scholarship tests (like TALLENTEX, ANTHE, AIMT), or publish official exam notices from NTA and UPSC.',
    category: 'general'
  },
  {
    id: 'free-study-materials',
    question: 'Where can I find free notes, formula sheets, and DPPs?',
    answer: 'Click on any platform card (e.g. Physics Wallah, Drishti IAS, or Competishun) to open its dedicated resource viewer. Switch to the "Free DPPs & Notes" or "Official Portals" tab to find verified links to formula handbooks, previous year question archives, and subject mindmaps.',
    category: 'notes'
  },
  {
    id: 'dmca-and-copyright',
    question: 'What is SPIDY SHUBH’s policy on copyright and intellectual property?',
    answer: 'SPIDY SHUBH respects all intellectual property rights. All platform trademarks, brand names, and logos belong exclusively to their respective owners (such as Physics Wallah Private Ltd., Sorting Hat Technologies, Allen Career Institute, etc.). We act solely as a navigational index and informational catalog. If any copyright holder wishes to update or remove an index listing, please contact us via our Contact form or email.',
    category: 'dmca'
  },
  {
    id: 'mobile-app-or-preview',
    question: 'Can I use SPIDY SHUBH like a mobile app?',
    answer: 'Yes! SPIDY SHUBH is built with a mobile-first responsive architecture. On Chrome or Safari for mobile, tap "Share" or the three dots menu and select "Add to Home Screen". You can run it fullscreen with quick touch interactions without needing to download large APKs.',
    category: 'general'
  }
];
